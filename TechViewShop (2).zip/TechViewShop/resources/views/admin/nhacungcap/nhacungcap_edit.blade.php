@extends('admin.layout.layout')

@section('title', 'Sửa nhà cung cấp')

@section('content')

<form action="{{ route('nhacungcap.update', $nhacungcap->id) }}" method="POST" enctype="multipart/form-data">
    @csrf
    @method('PUT')

    @if ($errors->any())
    <div class="alert alert-danger">
        <ul class="mb-0">
            @foreach ($errors->all() as $error)
            <li>{{ $error }}</li>
            @endforeach
        </ul>
    </div>
    @endif

    <div class="container">
        <h4 class="fw-bold mt-4">Sửa nhà cung cấp</h4>
        <p><a href="/">Trang chủ</a> / <span class="text-primary">Sửa nhà cung cấp</span></p>
        <div class="add-product">
            <div class="row">
                <div class="col-md-12">
                    <div class="border rounded p-3">
                        <h5 class="fw-bold">Thông tin</h5>
                        <div class="row">
                            <div class="col-md-4 mt-3">
                                <label class="form-label">Tên nhà cung cấp</label>
                                <input type="text" name="tenncc" value="{{ old('tenncc', $nhacungcap->tenncc) }}" class="form-control" required>
                            </div>
                            <div class="col-md-4 mt-3">
                                <label class="form-label">Email</label>
                                <input type="email" name="email" value="{{ old('email', $nhacungcap->email) }}" class="form-control">
                            </div>
                            <div class="col-md-4 mt-3">
                                <label class="form-label">Số điện thoại</label>
                                <input type="text" name="sodienthoai" value="{{ old('sodienthoai', $nhacungcap->sodienthoai) }}" class="form-control">
                            </div>

                            <div class="col-md-4 mt-3">
                                <label class="form-label">Địa chỉ</label>
                                <input type="text" name="diachi" value="{{ old('diachi', $nhacungcap->diachi) }}" class="form-control">
                            </div>

                            <div class="col-md-4 mt-3">
                                <label class="form-label">Mô tả</label>
                                <input type="text" name="mota" value="{{ old('mota', $nhacungcap->mota) }}" class="form-control">
                            </div>

                            <div class="col-md-4 mt-3">
                                <label class="form-label">Thứ tự</label>
                                <input type="number" name="thutu" value="{{ old('thutu', $nhacungcap->thutu) }}" class="form-control">
                            </div>

                            <div class="col-md-4 mt-3">
                                <label class="form-label">Trạng thái hiển thị</label>
                                <div class="form-check">
                                    <input class="form-check-input" type="radio" name="anhien" id="hien" value="1" {{ $nhacungcap->anhien == 1 ? 'checked' : '' }}>
                                    <label class="form-check-label" for="hien">Hiển thị</label>
                                </div>
                                <div class="form-check">
                                    <input class="form-check-input" type="radio" name="anhien" id="an" value="0" {{ $nhacungcap->anhien == 0 ? 'checked' : '' }}>
                                    <label class="form-check-label" for="an">Ẩn</label>
                                </div>
                            </div>

                            <div class="border rounded p-4 text-center mt-2">
                                @if($nhacungcap->hinh)
                                    <img src="{{ asset('uploads/nhacungcap/' . $nhacungcap->hinh) }}" alt="Hình hiện tại" class="img-thumbnail mb-2" style="max-height: 200px;">
                                @endif
                                <p class="text-muted">Cập nhật ảnh </p>
                                <input type="file" name="hinh" class="form-control mt-2">
                            </div>

                            @if ($errors->has('hinh'))
                            <div class="alert alert-danger mt-2">
                                {{ $errors->first('hinh') }}
                            </div>
                            @endif

                        </div>
                    </div>
                </div>
            </div>

            <!-- Buttons -->
            <div class="d-flex justify-content-end mt-2">
                <button class="btn btn-primary me-2">Cập nhật</button>
                <a href="{{ route('nhacungcap') }}" class="btn btn-secondary">Hủy</a>
            </div>
        </div>
    </div>

</form>
@if(session('popup'))
    <script>
        document.addEventListener("DOMContentLoaded", function() {
            // Hiển thị hộp thoại confirm
            Swal.fire({
                icon: "{{ session('status', 'info') }}", // Loại thông báo
                title: '',  // Tiêu đề có thể để trống hoặc chỉnh lại
                text: "{{ session('message') }}",  // Nội dung thông báo
                showCancelButton: false, // Ẩn nút Cancel (nếu bạn chỉ muốn "OK")
                confirmButtonText: 'OK', // Nút xác nhận "OK"
            }).then((result) => {
                // Chỉ khi người dùng nhấn OK mới chuyển trang
                if (result.isConfirmed) {
                    window.location.href = "{{ session('route') }}"; // Chuyển hướng
                }
            });
        });
    </script>
@endif





@endsection
