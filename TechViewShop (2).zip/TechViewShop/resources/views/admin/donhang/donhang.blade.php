@extends('admin.layout.layout')

@section('title', 'Danh sách đơn hàng')

@section('content')
<div class="container mt-5">
    <div class="row justify-content-center">
        <div class="col-lg-12">
            <!-- Header -->
            <div class="d-flex justify-content-between align-items-center mb-4">
                <h2 class="fw-bold text-primary">Danh sách đơn hàng</h2>
            </div>

            <!-- Card chính -->
            <div class="card border-0 shadow-lg rounded-3">
                <div class="card-body p-4">
                    <!-- Tìm kiếm và sắp xếp -->
                    <div class="row mb-4">
                        <div class="col-md-6 mb-3 mb-md-0">
                            <form method="GET" action="{{ route('donhang') }}">
                                <div class="input-group">
                                    <input type="text" name="search" class="form-control" placeholder="Tìm kiếm đơn hàng" value="{{ request('search') }}">
                                    <button class="btn btn-primary" type="submit">
                                        <i class="bi bi-search"></i> Tìm kiếm
                                    </button>
                                </div>
                            </form>
                        </div>
                        <div class="col-md-6 text-md-end">
                            <div class="btn-group">
                                <a href="{{ route('donhang', ['sort' => 'id', 'direction' => request('direction', 'asc') == 'asc' ? 'desc' : 'asc']) }}"
                                   class="btn btn-outline-primary btn-sm">
                                    Theo ID
                                    <i class="bi {{ request('sort') == 'id' && request('direction') == 'asc' ? 'bi-sort-down' : 'bi-sort-up' }}"></i>
                                </a>
                                <a href="{{ route('donhang', ['sort' => 'ngaytao', 'direction' => request('direction', 'asc') == 'asc' ? 'desc' : 'asc']) }}"
                                   class="btn btn-outline-primary btn-sm">
                                    Theo Ngày tạo
                                    <i class="bi {{ request('sort') == 'ngaytao' && request('direction') == 'asc' ? 'bi-sort-down' : 'bi-sort-up' }}"></i>
                                </a>
                            </div>
                        </div>
                    </div>

                    <!-- Thông báo lỗi -->
                    @if ($errors->any())
                        <div class="alert alert-danger alert-dismissible fade show" role="alert">
                            <ul class="mb-0">
                                @foreach ($errors->all() as $error)
                                    <li>{{ $error }}</li>
                                @endforeach
                            </ul>
                            <button type="button" class="btn-close" data-bs-dismiss="alert" aria-label="Close"></button>
                        </div>
                    @endif

                    <!-- Bảng đơn hàng -->
                    <div class="table-responsive">
                        <table class="table table-hover align-middle">
                            <thead class="table-light">
                                <tr>
                                    <th>ID</th>
                                    <th>Mã đơn hàng</th>
                                    <th>Người nhận</th>
                                    <th>SĐT</th>
                                    <th>Tổng tiền</th>
                                    <th>Trạng thái</th>
                                    <th>Ngày tạo</th>
                                    <th>Thao tác</th>
                                </tr>
                            </thead>
                            <tbody>
                                @forelse($donhangs as $donhang)
                                    <tr>
                                        <td>{{ $donhang->id }}</td>
                                        <td>{{ $donhang->madonhang }}</td>
                                        <td>{{ $donhang->tennguoinhan }}</td>
                                        <td>{{ $donhang->sodienthoai }}</td>
                                        <td>{{ number_format($donhang->tongtien, 0, ',', '.') }} VNĐ</td>
                                        <td>
                                            @if ($donhang->trangthai == 'pending')
                                            <span class="badge bg-warning">Chờ xử lý</span>
                                            @elseif ($donhang->trangthai == 'completed')
                                            <span class="badge bg-success">Hoàn thành</span>
                                            @elseif ($donhang->trangthai == 'canceled')
                                            <span class="badge bg-danger">Đã hủy</span>
                                            @else
                                            <span class="badge bg-secondary">{{ $donhang->trangthai }}</span>
                                            @endif
                                        </td>
                                        <td>{{ date('d/m/Y H:i', strtotime($donhang->ngaytao)) }}</td>
                                        <td>
                                            <a href="{{ route('donhang.show', $donhang->id) }}" class="btn btn-info btn-sm">Chi tiết</a>
                                            @if ($donhang->trangthai != 'hoàn thành' && $donhang->trangthai != 'đã hủy')
                                            <button type="button" class="btn btn-primary" id="btnUpdate{{ $donhang->id }}">Cập nhật</button>

                                            <!-- Form ẩn, chỉ hiển thị khi click vào nút Cập nhật -->
                                            <div id="formUpdate{{ $donhang->id }}" style="display: none;">
                                                <form action="{{ route('donhang.update', $donhang->id) }}" method="POST">
                                                    @csrf
                                                    @method('PUT')

                                                    <div class="mb-3">
                                                        <label for="trangthai" class="form-label small text-muted">Trạng thái:</label>
                                                        <div class="d-flex align-items-center">
                                                            <select name="trangthai" id="trangthai" class="form-select me-1">
                                                                <option value="đang xử lý" {{ $donhang->trangthai == 'đang xử lý' ? 'selected' : '' }}>Đang xử lý</option>
                                                                <option value="đã xác nhận" {{ $donhang->trangthai == 'đã xác nhận' ? 'selected' : '' }}>Đã xác nhận</option>
                                                                <option value="hoàn thành" {{ $donhang->trangthai == 'hoàn thành' ? 'selected' : '' }}>Hoàn thành</option>
                                                                <option value="đã hủy" {{ $donhang->trangthai == 'đã hủy' ? 'selected' : '' }}>Đã hủy</option>
                                                            </select>
                                                            <button type="submit" class="small btn btn-primary btn-sm">Cập nhật</button>
                                                        </div>
                                                    </div>
                                                </form>
                                            </div>
                                            @endif

                                            @if ($donhang->trangthai != 'hoàn thành' && $donhang->trangthai != 'đã hủy')
                                            <form action="{{ route('donhang.huy', $donhang->id) }}" method="POST" style="display:inline;">
                                                @csrf
                                                @method('DELETE')
                                                <button type="submit" class="btn btn-danger btn-sm" onclick="return confirm('Bạn có chắc muốn xóa đơn hàng này?')">Hủy</button>
                                            </form>
                                            @endif
                                        </td>
                                    </tr>
                                @empty
                                    <tr>
                                        <td colspan="8" class="text-center text-muted py-4">
                                            <i class="bi bi-exclamation-circle me-2"></i> Không có đơn hàng nào.
                                        </td>
                                    </tr>
                                @endforelse
                            </tbody>
                        </table>
                    </div>

                    <!-- Phân trang -->
                    <div class="mt-4">
                        {{ $donhangs->appends(request()->query())->links('pagination::bootstrap-5') }}
                    </div>
                </div>
            </div>
        </div>
    </div>
</div>

<script>
    document.getElementById('btnUpdate{{ $donhang->id ?? 0 }}').addEventListener('click', function() {
        var formUpdate = document.getElementById('formUpdate{{ $donhang->id ?? 0 }}');
        var buttonUpdate = document.getElementById('btnUpdate{{ $donhang->id ?? 0 }}');
        formUpdate.style.display = 'block';
        buttonUpdate.style.display = 'none';
    });
</script>

@endsection
