@extends('admin.layout.layout')

@section('title', 'Danh sách đơn hàng')

@section('content')
<div class="container">
    <h4 class="fw-bold mt-4">Danh sách đơn hàng</h4>
    <p><a href="/">Trang chủ</a> / <span class="text-primary">Đơn hàng</span></p>

    <div class="border rounded p-3 shadow-sm bg-light">
        <h5 class="fw-bold">Tất cả đơn hàng</h5>
        <table class="table">
            <thead>
                <tr>
                    <th>#</th>
                    <th>Mã đơn hàng</th>
                    <th>Người nhận</th>
                    <th>SĐT</th>
                    <th>Tổng tiền</th>
                    <th>Trạng thái</th>
                    <th>Ngày tạo</th>
                    <th>Thao tác</th>
                </tr>
            </thead>
            <tbody>
                @foreach ($donhangs as $index => $donhang)
                <tr>
                    <td>{{ $index + 1 }}</td>
                    <td>{{ $donhang->madonhang }}</td>
                    <td>{{ $donhang->tennguoinhan }}</td>
                    <td>{{ $donhang->sodienthoai }}</td>
                    <td>{{ number_format($donhang->tongtien, 0, ',', '.') }} VNĐ</td>
                    <td>
                        @if ($donhang->trangthai == 'pending')
                        <span class="badge bg-warning">Chờ xử lý</span>
                        @elseif ($donhang->trangthai == 'completed')
                        <span class="badge bg-success">Hoàn thành</span>
                        @elseif ($donhang->trangthai == 'canceled')
                        <span class="badge bg-danger">Đã hủy</span>
                        @else
                        <span class="badge bg-secondary">{{ $donhang->trangthai }}</span>
                        @endif
                    </td>
                    <td>{{ date('d/m/Y H:i', strtotime($donhang->ngaytao)) }}</td>
                    <td>
                        <a href="{{ route('donhang.show', $donhang->id) }}" class="btn btn-info btn-sm">Chi tiết</a>
                        <!-- <a href="{{ route('donhang.update', $donhang->id) }}" class="btn btn-primary btn-sm">Xử lý</a> -->


                        <!-- Nút Cập nhật -->
                        @if ($donhang->trangthai != 'hoàn thành' && $donhang->trangthai != 'đã hủy')
                        <button type="button" class="btn btn-primary" id="btnUpdate{{ $donhang->id ?? 0 }}">Cập nhật</button>

                        <!-- Form ẩn, chỉ hiển thị khi click vào nút Cập nhật -->
                        <div id="formUpdate{{ $donhang->id }}" style="display: none;">
                            <form action="{{ route('donhang.update', $donhang->id) }}" method="POST">
                                @csrf
                                @method('PUT')

                                <div class="mb-3">
                                    <label for="trangthai" class="form-label small text-muted">Trạng thái:</label>
                                    <div class="d-flex align-items-center">
                                        <select name="trangthai" id="trangthai" class="form-select me-1">
                                            <option value="đang xử lý" {{ $donhang->trangthai == 'đang xử lý' ? 'selected' : '' }}>Đang xử lý</option>
                                            <option value="đã xác nhận" {{ $donhang->trangthai == 'đã xác nhận' ? 'selected' : '' }}>Đã xác nhận</option>
                                            <option value="hoàn thành" {{ $donhang->trangthai == 'hoàn thành' ? 'selected' : '' }}>Hoàn thành</option>
                                            <option value="đã hủy" {{ $donhang->trangthai == 'đã hủy' ? 'selected' : '' }}>Đã hủy</option>
                                        </select>
                                        <button type="submit" class="small btn btn-primary btn-sm">Cập nhật</button>
                                    </div>
                                </div>
                            </form>
                        </div>
                        @endif

                        @if ($donhang->trangthai != 'hoàn thành' && $donhang->trangthai != 'đã hủy')
                        <form action="{{ route('donhang.huy', $donhang->id) }}" method="POST" style="display:inline;">
                            @csrf
                            @method('DELETE')
                            <button type="submit" class="btn btn-danger btn-sm" onclick="return confirm('Bạn có chắc muốn xóa đơn hàng này?')">Hủy</button>
                        </form>
                        @endif
                    </td>
                </tr>
                @endforeach
            </tbody>
        </table>

        <!-- Phân trang -->
        <div class="d-flex justify-content-end mt-3">
            {{ $donhangs->links('pagination::bootstrap-5') }}
        </div>
    </div>
</div>
</div>



<script>
    // Lắng nghe sự kiện click trên nút Cập nhật
    document.getElementById('btnUpdate{{ $donhang->id ?? 0 }}').addEventListener('click', function() {
        var formUpdate = document.getElementById('formUpdate{{ $donhang->id ?? 0 }}');
        var buttonUpdate = document.getElementById('btnUpdate{{ $donhang->id ?? 0 }}');

        // Hiển thị form và ẩn nút Cập nhật khi click
        formUpdate.style.display = 'block';
        buttonUpdate.style.display = 'none';
    });

    // Lắng nghe sự kiện double click vào form
    document.getElementById('formUpdate{{ $donhang->id ?? 0 }}').addEventListener('dblclick', function() {
        var formUpdate = document.getElementById('formUpdate{{ $donhang->id ?? 0 }}');
        var buttonUpdate = document.getElementById('btnUpdate{{ $donhang->id ?? 0 }}');

        // Ẩn form và hiển thị lại nút Cập nhật khi double click
        formUpdate.style.display = 'none';
        buttonUpdate.style.display = 'inline-block';
    });
</script>
@endsection