<!DOCTYPE html>
<html lang="vi">

<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Thông báo đơn hàng hoàn thành</title>
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.3/dist/css/bootstrap.min.css" rel="stylesheet">
    <style>
        body {
            font-family: Arial, sans-serif;
            background-color: #f8f9fa;
            padding: 20px;
        }

        .email-container {
            background-color: #ffffff;
            border-radius: 8px;
            padding: 20px;
            box-shadow: 0 4px 6px rgba(0, 0, 0, 0.1);
        }

        h3 {
            color: #007bff;
        }

        .email-footer {
            margin-top: 20px;
            font-size: 14px;
            color: #6c757d;
        }

        .btn-link {
            color: #007bff;
            text-decoration: none;
        }

        .product-list {
            list-style-type: none;
            padding-left: 0;
        }

        .product-list li {
            border-bottom: 1px solid #e9ecef;
            padding: 8px 0;
        }

        .total-price {
            font-weight: bold;
        }
    </style>
</head>

<body>

@section('content')
    @if(session('message'))
        <div class="alert alert-success">
            {{ session('message') }}
        </div>
    @endif

    <!-- Nội dung khác của trang -->
@endsection

    <div class="email-container">
        <p>Xin chào <strong>{{ $tennguoinhan }}</strong>,</p>
        <p>Đơn hàng <strong>{{ $madonhang }}</strong> của bạn đã được giao thành công vào ngày <strong>{{ date('d/m/Y', strtotime($ngaytao)) }}</strong>.</p>
        <p>Vui lòng đăng nhập TechView để xác nhận bạn đã nhận hàng và hài lòng với sản phẩm. Sau khi bạn xác nhận, rất mong bạn để lại đánh giá cho dịch vụ và sản phẩm của chúng tôi.</p>
        <div class="text-center">
            <a class="btn btn-primary mt-3 me-1" href="{{ route('donhang.xacnhan', ['id' => $donhang->id]) }}">Đã nhận hàng</a>
        </div>

        <h3>THÔNG TIN ĐƠN HÀNG - DÀNH CHO NGƯỜI MUA</h3>
        <ul class="list-group">
            <li class="list-group-item"><strong>Mã đơn hàng:</strong> {{ $madonhang }}</li>
            <li class="list-group-item"><strong>Ngày đặt hàng:</strong> {{ date('d/m/Y H:i:s', strtotime($ngaytao)) }}</li>
            <li class="list-group-item"><strong>Người bán:</strong> snailey</li>
        </ul>

        <h3>Sản phẩm</h3>
        <ul class="product-list">
            @foreach ($chitietdonhang as $chitiet)
            <li>
                <strong>{{ $chitiet->sanpham->ten }}</strong> | Số lượng: {{ $chitiet->soluong }} | Giá: ₫{{ number_format($chitiet->gia, 0, ',', '.') }}
            </li>
            @endforeach
        </ul>

        <p class="total-price">Tổng tiền: ₫
        <p><strong>Tổng tiền:</strong> {{ $tongtien }}</p>
        </p>
        <p><strong>Mã giảm giá của Shop:</strong> SNAI2K</p>
        <p><strong>Phí vận chuyển:</strong> ₫0</p>
        <p><strong>Tổng thanh toán:</strong> ₫131,560</p>

        <h3>BƯỚC TIẾP THEO</h3>
        <p>Bạn không hài lòng về sản phẩm? Bạn có thể gửi yêu cầu trả hàng trên trang website của chúng tôi.</p>

        <div class="email-footer">
            <p>Trân trọng,</p>
            <p>Đội ngũ TechView</p>
        </div>
    </div>
</body>

</html>