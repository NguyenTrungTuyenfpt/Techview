@extends('admin.layout.layout')

@section('title', 'Add Product Category')

@section('content')
<!-- Nội dung chính của trang sẽ nằm ở đây -->

<form action="{{ route('danhmuc.store') }}" method="POST" enctype="multipart/form-data">
    @csrf


    @if ($errors->any())
    <div class="alert alert-danger">
        <ul class="mb-0">
            @foreach ($errors->all() as $error)
            <li>{{ $error }}</li>
            @endforeach
        </ul>
    </div>
    @endif

    <div class="container">
        <h4 class="fw-bold mt-4">Thêm danh mục</h4>
        <p><a href="/">Trang chủ</a> / <span class="text-primary">Thêm danh mục</span></p>
        <div class="add-product">
            <div class="row">
                <!-- Thông tin sản phẩm -->
                <div class="col-md-12">
                    <div class="border rounded p-3">
                        <h5 class="fw-bold">Thông tin danh muc</h5>
                        <div class="row">
                            <div class="col-md-4 mt-3">
                                <label class="form-label">Tên danh mục</label>
                                <input type="text" name="tendm" class="form-control" placeholder="Nhập tại đây">
                            </div>
                            <div class="col-md-4 mt-3">
                                <label class="form-label">Mô tả</label>
                                <input type="text" name="mota" class="form-control" placeholder="Nhập tại đây">
                            </div>
                            <div class="col-md-4 mt-3">
                                <label class="form-label">Thứ tự</label>
                                <input type="number" name="thutu" class="form-control" placeholder="Nhập tại đây">
                            </div>

                            <div class="col-md-4 mt-3">
                                <label class="form-label">Danh mục cha</label>
                                <select name="id_danhmuc_cha" class="form-control">
                                    <option value="">Chọn danh mục cha</option>
                                    @foreach($danhmuc as $dm)
                                    <option value="{{ $dm->id }}">{{ $dm->tendm }}</option>
                                    @endforeach
                                </select>
                            </div>

                            <div class="col-md-4 mt-3">
                                <label class="form-label">Trạng thái hiển thị</label>
                                <div class="form-check">
                                    <input class="form-check-input" type="radio" name="anhien" id="hien" value="1" checked>
                                    <label class="form-check-label" for="hien">Hiển thị</label>
                                </div>
                                <div class="form-check">
                                    <input class="form-check-input" type="radio" name="anhien" id="an" value="0">
                                    <label class="form-check-label" for="an">Ẩn</label>
                                </div>
                            </div>

                            <!-- <div class="col-md-4 mt-3">
                                <label class="form-label">Hình ảnh</label>
                                <input type="file" name="hinh" class="form-control" placeholder="Nhập tại đây">
                            </div> -->

                            <div class="border rounded p-4 text-center mt-2">
                                <i class="bi bi-image" style="font-size: 60px; color: #ccc;"></i>
                                <p class="text-muted">Ảnh </p>
                                <input type="file" name="hinh" class="form-control mt-2">
                            </div>

                            @if ($errors->has('hinh'))
                            <div class="alert alert-danger mt-2">
                                {{ $errors->first('hinh') }}
                            </div>
                            @endif

                        </div>
                    </div>
                </div>



            </div>

            <!-- Buttons -->
            <div class="d-flex justify-content-end mt-2">
                <button class="btn btn-primary me-2">Thêm</button>
                <button class="btn btn-danger"> <a  href="{{route('danhmuc')}}">Hủy</a></button>
            </div>
        </div>
    </div>

</form>

</div>
</div>


@if(session('popup'))
<script>
    window.onload = function() {
        if (confirm("{{ session('message') }}")) {
            window.location.href = "{{ route('danhmuc') }}";
        }
    };
</script>


@endif
<script>
    const fileInput = document.querySelector('input[name="hinh"]');
    fileInput.addEventListener('change', function (e) {
        const previewContainer = document.querySelector('.border.rounded.p-4.text-center.mt-2');
        const files = e.target.files;
        previewContainer.innerHTML = ''; // Clear any previous image preview

        for (let i = 0; i < files.length; i++) {
            const reader = new FileReader();
            reader.onload = function (e) {
                const img = document.createElement('img');
                img.src = e.target.result;
                img.classList.add('img-thumbnail', 'mt-2');
                previewContainer.appendChild(img);
            };
            reader.readAsDataURL(files[i]);
        }
    });
</script>
@endsection