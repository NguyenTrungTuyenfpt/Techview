@extends('admin.layout.layout')

@section('title', 'Sua Banner')

@section('content')
<!-- Nội dung chính của trang sẽ nằm ở đây -->

<p><a href="/">Trang chủ</a> / <span class="text-primary">Sửa Banner</span></p>

<form action="{{ route('banner.update', $banner->id) }}" method="POST" enctype="multipart/form-data">
    @csrf
    @method('PUT')
    
    <div class="add-product">
        <div class="row">
            <!-- Thông tin sản phẩm -->
            <div class="col-md-12">
                <div class="border rounded p-3">
                    <h5 class="fw-bold">Thông tin </h5>
                    <div class="row">
                        <!-- Tên sản phẩm -->
                        <div class="col-md-4 mt-3">
                            <label class="form-label">Tên </label>
                            <input type="text" name="ten" class="form-control" value="{{ $banner->ten }}" required>
                            @error('ten') <small class="text-danger">{{ $message }}</small> @enderror
                        </div>

                        <!-- Giá sản phẩm -->
                        <div class="col-md-4 mt-3">
                            <label class="form-label">Mo ta</label>
                            <input type="text" name="mota" class="form-control" value="{{ $banner->mota }}" required>
                            @error('gia') <small class="text-danger">{{ $message }}</small> @enderror
                        </div>

                        <!-- Giá khuyến mãi -->
                        <div class="col-md-4 mt-3">
                            <label class="form-label">Vi tri</label>
                            <input type="text" name="giagiam" class="form-control" value="{{ $banner->vitri }}">
                            @error('vitri') <small class="text-danger">{{ $message }}</small> @enderror
                        </div>

                        <!-- Mô tả -->
                        <div class="col-md-4 mt-3">
                            <label class="form-label">link</label>
                            <input type="text" name="link" class="form-control" value="{{ $banner->link }}">
                            @error('link') <small class="text-danger">{{ $message }}</small> @enderror
                        </div>

                        <!-- Thứ tự ưu tiên -->
                        <div class="col-md-4 mt-3">
                            <label class="form-label">Thứ tự</label>
                            <input type="number" name="thutu" class="form-control" value="{{ $banner->thutu }}" required>
                            @error('gia') <small class="text-danger">{{ $message }}</small> @enderror
                        </div>


                        <!-- Trạng thái hiển thị -->
                        <div class="col-md-4 mt-3">
                            <label class="form-label d-block">Trạng thái hiển thị</label>
                            <div class="form-check form-check-inline">
                                <input class="form-check-input" type="radio" name="anhien" value="1"
                                    {{ $banner->anhien == 1 ? 'checked' : '' }}>
                                <label class="form-check-label">Hiển thị</label>
                            </div>
                            <div class="form-check form-check-inline">
                                <input class="form-check-input" type="radio" name="anhien" value="0"
                                    {{ $banner->anhien == 0 ? 'checked' : '' }}>
                                <label class="form-check-label">Ẩn</label>
                            </div>
                            @error('trangthai') <small class="text-danger d-block">{{ $message }}</small> @enderror

                           
                        </div>


                    </div>
                </div>
            </div>
        </div>

        <!-- Ảnh chính hiện tại -->
        <div class="border rounded p-4 text-center mt-3">
            <p class="text-muted">Ảnh hiện tại</p>
            @if($banner->hinh)
                <img src="{{ asset('uploads/banner/' . $banner->hinh) }}" width="150" class="img-thumbnail" alt="Ảnh chính hiện tại">
            @else
                <p class="text-muted">Chưa có ảnh </p>
            @endif
            <p class="text-muted mt-2">Chọn ảnh mới </p>
            <input type="file" name="hinh" class="form-control mt-2">
            @error('hinh') <small class="text-danger">{{ $message }}</small> @enderror
        </div>

       

        <!-- Buttons -->
        <div class="d-flex justify-content-end mt-4">
            <button type="submit" class="btn btn-primary me-2">Cập nhật </button>
            <a href="{{ route('banner') }}" class="btn btn-danger">Hủy</a>
        </div>
    </div>
</form>





@if(session('popup'))
<script>
    window.onload = function() {
        if (confirm("{{ session('message') }}")) {
            window.location.href = "{{ route('banner') }}";
        }
    };
</script>
@endif

</div>
</div>

@endsection