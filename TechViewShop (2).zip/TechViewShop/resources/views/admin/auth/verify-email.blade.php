<!-- <!DOCTYPE html>
<html>
<head>
    <title>Xác thực Email</title>
</head>
<body>
    <h2>Xin chào, {{ $user->hoten }}</h2>
    <p>Bấm vào link dưới đây để xác thực email của bạn:</p>
    <a href="{{ route('auth.verifyemail', ['id' => $user->id]) }}">Xác thực email</a>
</body>
</html> -->


<!DOCTYPE html>
<html lang="vi">

<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Đăng ký</title>
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.3/dist/css/bootstrap.min.css" rel="stylesheet">
</head>

<body>

<!-- Begin page -->
<div class="account-page">
            <div class="container-fluid p-0">
                <div class="row align-items-center g-0">

                    <div class="col-md-5">
                        <div class="row">
                            <div class="col-md-8 mx-auto">
                                <div class="card p-3 mb-0 mb-0">
                                    <div class="card-body">
                                        <div class="mb-0 border-0 p-md-5 p-lg-0 p-4">

                                            <div class="mb-4 p-0 text-center">
                                                <a class='auth-logo' href='index.html'>
                                                    <img src="assets/images/logo-dark.png" alt="logo-dark" class="mx-auto" height="28" />
                                                </a>
                                            </div>

                                            <div class="auth-title-section mb-3 text-center mt-2">
                                            <h2>Xin chào, {{ $user->hoten }}</h2>
                                                <h3 class="text-dark fs-20 fw-medium mb-2">Email Confirmation</h3>
                                                <p class="text-muted fs-15">Bấm vào link dưới đây để xác thực email của bạn. <br>Click link </p>
                                            </div>

                                            <div class="text-center">
                                                <a class="btn btn-primary mt-3 me-1" href="{{ route('auth.verifyemail', ['id' => $user->id]) }}">Xác thực email</a>
                                            </div>

                                            <div class="text-center pt-4">
                                                <div class="maintenance-img">
                                                    <img src="{{ asset('img/onfirmation-email.svg') }}" height="200" alt="svg-logo">
                                                </div>
                                            </div>

                                        </div>
                                    </div>
                                </div>
                            </div>
                        </div>
                    </div>

                    

                </div>
            </div>
        </div>
        
        <!-- END wrapper -->


        </body>

</html>