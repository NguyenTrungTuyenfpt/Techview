@extends('admin.layout.layout')

@section('title', 'Thống kê tổng quan')

@section('content')
<div class="container-fluid mt-5">
    <!-- Header -->
    <div class="d-flex justify-content-between align-items-center mb-4">
        <h2 class="fw-bold text-primary">Thống kê tổng quan</h2>
        <div class="btn-group">
            <button class="btn btn-outline-primary dropdown-toggle" type="button" id="filterDropdown" data-bs-toggle="dropdown" aria-expanded="false">
                <i class="bi bi-funnel"></i> Lọc theo thời gian
            </button>
            <ul class="dropdown-menu" aria-labelledby="filterDropdown">
                <li><a class="dropdown-item" href="{{ route('thongke.index', ['filter' => 'today']) }}">Hôm nay</a></li>
                <li><a class="dropdown-item" href="{{ route('thongke.index', ['filter' => 'week']) }}">Tuần này</a></li>
                <li><a class="dropdown-item" href="{{ route('thongke.index', ['filter' => 'month']) }}">Tháng này</a></li>
                <li><a class="dropdown-item" href="{{ route('thongke.index', ['filter' => 'year']) }}">Năm nay</a></li>
            </ul>
        </div>
    </div>

    <!-- Tổng quan thống kê -->
    <div class="row mb-4">
        <!-- Doanh thu -->
        <div class="col-md-3 col-sm-6 mb-3">
            <div class="card shadow-sm border-0">
                <div class="card-body d-flex align-items-center">
                    <span class="icon bg-primary text-white rounded-circle p-3 me-3">
                        <i class="bi bi-currency-dollar fs-4"></i>
                    </span>
                    <div>
                        <h5 class="card-title mb-1">Doanh thu</h5>
                        <p class="card-text fw-bold text-primary">{{ number_format($doanhThu, 0, ',', '.') }} VNĐ</p>
                    </div>
                </div>
            </div>
        </div>

        <!-- Số đơn hàng -->
        <div class="col-md-3 col-sm-6 mb-3">
            <div class="card shadow-sm border-0">
                <div class="card-body d-flex align-items-center">
                    <span class="icon bg-success text-white rounded-circle p-3 me-3">
                        <i class="bi bi-bag-check fs-4"></i>
                    </span>
                    <div>
                        <h5 class="card-title mb-1">Số đơn hàng</h5>
                        <p class="card-text fw-bold text-success">{{ $soDonHang }}</p>
                    </div>
                </div>
            </div>
        </div>

        <!-- Lượng khách hàng -->
        <div class="col-md-3 col-sm-6 mb-3">
            <div class="card shadow-sm border-0">
                <div class="card-body d-flex align-items-center">
                    <span class="icon bg-info text-white rounded-circle p-3 me-3">
                        <i class="bi bi-people fs-4"></i>
                    </span>
                    <div>
                        <h5 class="card-title mb-1">Lượng khách hàng</h5>
                        <p class="card-text fw-bold text-info">{{ $soKhachHang }}</p>
                    </div>
                </div>
            </div>
        </div>

        <!-- Lượng đánh giá -->
        <div class="col-md-3 col-sm-6 mb-3">
            <div class="card shadow-sm border-0">
                <div class="card-body d-flex align-items-center">
                    <span class="icon bg-warning text-white rounded-circle p-3 me-3">
                        <i class="bi bi-star fs-4"></i>
                    </span>
                    <div>
                        <h5 class="card-title mb-1">Lượng đánh giá</h5>
                        <p class="card-text fw-bold text-warning">{{ $soDanhGia }}</p>
                    </div>
                </div>
            </div>
        </div>

        <!-- Số bài viết mới -->
        <div class="col-md-3 col-sm-6 mb-3">
            <div class="card shadow-sm border-0">
                <div class="card-body d-flex align-items-center">
                    <span class="icon bg-secondary text-white rounded-circle p-3 me-3">
                        <i class="bi bi-file-earmark-text fs-4"></i>
                    </span>
                    <div>
                        <h5 class="card-title mb-1">Bài viết mới</h5>
                        <p class="card-text fw-bold text-secondary">{{ $soBaiVietMoi }}</p>
                    </div>
                </div>
            </div>
        </div>

        <!-- Sản phẩm nổi bật -->
        <div class="col-md-3 col-sm-6 mb-3">
            <div class="card shadow-sm border-0">
                <div class="card-body d-flex align-items-center">
                    <span class="icon bg-danger text-white rounded-circle p-3 me-3">
                        <i class="bi bi-fire fs-4"></i>
                    </span>
                    <div>
                        <h5 class="card-title mb-1">Sản phẩm nổi bật</h5>
                        <p class="card-text fw-bold text-danger">{{ $soSanPhamNoiBat }}</p>
                    </div>
                </div>
            </div>
        </div>

        <!-- Khuyến mãi đang hoạt động -->
        <div class="col-md-3 col-sm-6 mb-3">
            <div class="card shadow-sm border-0">
                <div class="card-body d-flex align-items-center">
                    <span class="icon bg-purple text-white rounded-circle p-3 me-3">
                        <i class="bi bi-ticket-perforated fs-4"></i>
                    </span>
                    <div>
                        <h5 class="card-title mb-1">Khuyến mãi hoạt động</h5>
                        <p class="card-text fw-bold text-purple">{{ $soKhuyenMaiHoatDong }}</p>
                    </div>
                </div>
            </div>
        </div>
    </div>

    <!-- Bảng thống kê chi tiết -->
    <div class="row mb-4">
        <!-- Sản phẩm bán chạy -->
        <div class="col-md-6 mb-4">
            <div class="card shadow-sm border-0">
                <div class="card-header bg-light">
                    <h5 class="card-title mb-0">Sản phẩm bán chạy</h5>
                </div>
                <div class="card-body">
                    <div class="table-responsive">
                        <table class="table table-hover align-middle">
                            <thead class="table-light">
                                <tr>
                                    <th>#</th>
                                    <th>Tên sản phẩm</th>
                                    <th>Số lượng bán</th>
                                    <th>Doanh thu (VNĐ)</th>
                                </tr>
                            </thead>
                            <tbody>
                                @forelse($sanPhamBanChay as $sp)
                                    <tr>
                                        <td>{{ $loop->iteration }}</td>
                                        <td>{{ $sp->tensp }}</td>
                                        <td>{{ $sp->soLuongBan }}</td>
                                        <td>{{ number_format($sp->doanhThu, 0, ',', '.') }}</td>
                                    </tr>
                                @empty
                                    <tr>
                                        <td colspan="4" class="text-center text-muted py-4">
                                            <i class="bi bi-exclamation-circle me-2"></i> Không có sản phẩm nào.
                                        </td>
                                    </tr>
                                @endforelse
                            </tbody>
                        </table>
                    </div>
                </div>
            </div>
        </div>

        <!-- Sản phẩm sắp hết -->
        <div class="col-md-6 mb-4">
            <div class="card shadow-sm border-0">
                <div class="card-header bg-light">
                    <h5 class="card-title mb-0">Sản phẩm sắp hết</h5>
                </div>
                <div class="card-body">
                    <div class="table-responsive">
                        <table class="table table-hover align-middle">
                            <thead class="table-light">
                                <tr>
                                    <th>#</th>
                                    <th>Tên sản phẩm</th>
                                    <th>Số lượng tồn</th>
                                    <th>Trạng thái</th>
                                </tr>
                            </thead>
                            <tbody>
                                @forelse($sanPhamSapHet as $sp)
                                    <tr>
                                        <td>{{ $loop->iteration }}</td>
                                        <td>{{ $sp->tensp }}</td>
                                        <td>{{ $sp->soluong }}</td>
                                        <td>
                                            <span class="badge {{ $sp->soluong <= 5 ? 'bg-danger' : 'bg-warning' }} px-2 py-1">
                                                {{ $sp->soluong <= 5 ? 'Hết hàng' : 'Sắp hết' }}
                                            </span>
                                        </td>
                                    </tr>
                                @empty
                                    <tr>
                                        <td colspan="4" class="text-center text-muted py-4">
                                            <i class="bi bi-exclamation-circle me-2"></i> Không có sản phẩm nào.
                                        </td>
                                    </tr>
                                @endforelse
                            </tbody>
                        </table>
                    </div>
                </div>
            </div>
        </div>

        <!-- Bài viết mới -->
        <div class="col-md-6 mb-4">
            <div class="card shadow-sm border-0">
                <div class="card-header bg-light">
                    <h5 class="card-title mb-0">Bài viết mới</h5>
                </div>
                <div class="card-body">
                    <div class="table-responsive">
                        <table class="table table-hover align-middle">
                            <thead class="table-light">
                                <tr>
                                    <th>#</th>
                                    <th>Tiêu đề</th>
                                    <th>Danh mục</th>
                                    <th>Người tạo</th>
                                    <th>Ngày tạo</th>
                                </tr>
                            </thead>
                            <tbody>
                                @forelse($baiVietMoi as $bv)
                                    <tr>
                                        <td>{{ $loop->iteration }}</td>
                                        <td>{{ $bv->tieude }}</td>
                                        <td>{{ $bv->danhMucBaiViet->tendm ?? 'N/A' }}</td>
                                        <td>{{ $bv->nguoiTao->hoten ?? 'N/A' }}</td>
                                        <td>{{ $bv->created_at->format('d/m/Y') }}</td>
                                    </tr>
                                @empty
                                    <tr>
                                        <td colspan="5" class="text-center text-muted py-4">
                                            <i class="bi bi-exclamation-circle me-2"></i> Không có bài viết nào.
                                        </td>
                                    </tr>
                                @endforelse
                            </tbody>
                        </table>
                    </div>
                </div>
            </div>
        </div>

        <!-- Đánh giá mới -->
        <div class="col-md-6 mb-4">
            <div class="card shadow-sm border-0">
                <div class="card-header bg-light">
                    <h5 class="card-title mb-0">Đánh giá mới</h5>
                </div>
                <div class="card-body">
                    <div class="table-responsive">
                        <table class="table table-hover align-middle">
                            <thead class="table-light">
                                <tr>
                                    <th>#</th>
                                    <th>Sản phẩm</th>
                                    <th>Khách hàng</th>
                                    <th>Điểm</th>
                                    <th>Ngày đánh giá</th>
                                </tr>
                            </thead>
                            <tbody>
                                @forelse($danhGiaMoi as $dg)
                                    <tr>
                                        <td>{{ $loop->iteration }}</td>
                                        <td>{{ $dg->sanpham->tensp ?? 'N/A' }}</td>
                                        <td>{{ $dg->user->hoten ?? 'N/A' }}</td>
                                        <td>{{ $dg->danhgia }}/5</td>
                                        <td>{{ $dg->created_at->format('d/m/Y') }}</td>
                                    </tr>
                                @empty
                                    <tr>
                                        <td colspan="5" class="text-center text-muted py-4">
                                            <i class="bi bi-exclamation-circle me-2"></i> Không có đánh giá nào.
                                        </td>
                                    </tr>
                                @endforelse
                            </tbody>
                        </table>
                    </div>
                </div>
            </div>
        </div>
    </div>

    
</div>

<!-- Script Chart.js -->
<script src="https://cdn.jsdelivr.net/npm/chart.js"></script>


<style>
    .icon {
        display: inline-flex;
        align-items: center;
        justify-content: center;
        width: 50px;
        height: 50px;
    }
    .bg-purple {
        background-color: #6f42c1 !important;
    }
    .text-purple {
        color: #6f42c1 !important;
    }
    .card {
        transition: transform 0.3s ease, box-shadow 0.3s ease;
    }
    .card:hover {
        transform: translateY(-5px);
        box-shadow: 0 10px 20px rgba(0, 0, 0, 0.1) !important;
    }
    .table th, .table td {
        vertical-align: middle;
    }
    .badge {
        font-size: 0.9rem;
    }
</style>
@endsection