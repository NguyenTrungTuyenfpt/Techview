@extends('admin.layout.layout')

@section('content')
<h2>Danh sách đánh giá sản phẩm</h2>

<table class="table">
    <thead>
        <tr>
            <th>#</th>
            <th>Khách hàng</th>
            <th>Sản phẩm</th>
            <th>Đánh giá</th>
            <th>Nội dung</th>
            <th>Ẩn/Hiện</th>
            <th>Phản hồi</th>
        </tr>
    </thead>
    <tbody>
        @foreach ($danhgias as $danhgia)
        <tr>
            <td>{{ $danhgia->id }}</td>
            <td>{{ $danhgia->user->hoten }}</td>
            <td>{{ $danhgia->sanpham->tensp }}</td>
            <td>

                <!-- Hiển thị icon ngôi sao dựa trên điểm đánh giá -->
                @for ($i = 1; $i <= 5; $i++)
                    @if ($i <=$danhgia->danhgia)
                    <i class="fa fa-star" style="color: gold; "></i>
                    @else
                    <i class="fa fa-star-o" style="color: gold; "></i>
                    @endif
                    @endfor
            </td>
            <!-- <td>{{ $danhgia->noidung }}</td> -->

            <td>

            <span class="text-muted fst-italic" style="font-size: 0.75rem;">
                {{ $danhgia->created_at->format('d/m/Y H:i') }} 
            </span><br>
                {{ $danhgia->noidung }} <br>

                @if ($danhgia->phanHoi) <!-- Kiểm tra nếu có phản hồi từ admin -->
                <div class="small text-muted mt-2">
                    <span>Phản hồi từ admin: </span>{{ $danhgia->phanHoi->noidung }}
                </div>
                @endif
            </td>
            <td>


                <form action="{{ route('danhgia.anhien', $danhgia->id) }}" method="POST">
                    @csrf
                    <button type="submit" class="badge {{ $danhgia->anhien ? 'bg-success bg-opacity-10 text-success' : 'bg-danger bg-opacity-10 text-danger' }} p-2 focus:outline-none">
                        {{ $danhgia->anhien ? 'Hiện' : 'Ẩn' }}
                    </button>

                </form>
            </td>

            <td>
                <form action="{{ route('danhgia.phanhoi', $danhgia->id) }}" method="POST">
                    @csrf
                    @if ($danhgia->danhGiaGoc()->exists()) <!-- Kiểm tra nếu đã có phản hồi -->
                    <div class="alert alert-success d-flex align-items-center mb-2 py-1 px-2 small" role="alert" style="font-size: 0.85rem;">
                        <span class="me-1"><i class="bi bi-check-circle-fill"></i></span>
                        <span>Đã phản hồi</span>
                    </div>

                    @else <!-- Nếu chưa có phản hồi -->
                    <!-- Nút Phản hồi -->
                    <button id="toggleResponse" class="btn btn-outline-secondary mb-3" type="button">
                        Phản hồi
                    </button>

                    <!-- Phản hồi Form (Ẩn đi ban đầu) -->
                    <div id="responseForm" class="collapse">
                        <div class="dropdown mb-3">
                            <button class="btn btn-outline-primary dropdown-toggle" type="button" id="dropdownMenuButton" data-bs-toggle="dropdown" aria-expanded="false">
                                Chọn phản hồi
                            </button>
                            <ul class="dropdown-menu" aria-labelledby="dropdownMenuButton">
                                <li><a class="dropdown-item" href="#" onclick="setResponse('Cảm ơn bạn đã tin tưởng và sử dụng sản phẩm');">Cảm ơn bạn đã tin tưởng và sử dụng sản phẩm</a></li>
                                <li><a class="dropdown-item" href="#" onclick="setResponse('Cảm ơn bạn đã đánh giá!');">Cảm ơn bạn đã đánh giá!</a></li>
                                <li><a class="dropdown-item" href="#" onclick="setResponse('Sản phẩm này đang được cải tiến, cảm ơn bạn đã ủng hộ sản phẩm!');">Sản phẩm này đang được cải tiến, cảm ơn bạn đã ủng hộ sản phẩm!</a></li>
                            </ul>
                        </div>

                        <textarea name="noidung" class="form-control mb-3" placeholder="Phản hồi..." id="responseInput"></textarea>

                        <button type="submit" class="btn btn-primary">Phản hồi</button>
                    </div>
                    @endif
                </form>


            </td>

        </tr>
        @endforeach

        <script>
            // Hàm set nội dung vào ô nhập văn bản khi chọn dropdown item
            function setResponse(response) {
                document.getElementById('responseInput').value = response;
            }


            // Khi nhấn vào nút, toggle hiện/ẩn form phản hồi
            document.getElementById('toggleResponse').addEventListener('click', function() {
                let responseForm = document.getElementById('responseForm');
                if (responseForm.classList.contains('collapse')) {
                    responseForm.classList.remove('collapse'); // Hiện form
                } else {
                    responseForm.classList.add('collapse'); // Ẩn form
                }
            });

            // Khi double click vào nút, ẩn form nếu nó đang hiển thị
            document.getElementById('toggleResponse').addEventListener('dblclick', function() {
                let responseForm = document.getElementById('responseForm');
                if (!responseForm.classList.contains('collapse')) {
                    responseForm.classList.add('collapse'); // Ẩn form
                }
            });
        </script>
    </tbody>
</table>
@endsection