@extends('admin.layout.layout')

@section('title', 'Sửa Khuyến Mãi')

@section('content')
<!-- Nội dung chính của trang sẽ nằm ở đây -->

<p><a href="/">Trang chủ</a> / <span class="text-primary">Sửa khuyến mãi </span></p>

<form action="{{ route('khuyenmai.update', $khuyenmai->id) }}" method="POST" enctype="multipart/form-data">
    @csrf
    @method('PUT')

    @if ($errors->any())
    <div class="alert alert-danger">
        <ul>
            @foreach ($errors->all() as $error)
                <li>{{ $error }}</li>
            @endforeach
        </ul>
    </div>
@endif

    
    <div class="add-product">
        <div class="row">
            <!-- Thông tin sản phẩm -->
            <div class="col-md-12">
                <div class="border rounded p-3">
                    <h5 class="fw-bold">Thông tin </h5>
                    <div class="row">
                        <!-- Tên sản phẩm -->
                        <div class="col-md-4 mt-3">
                            <label class="form-label">Mã </label>
                            <input type="text" name="makm" class="form-control" value="{{ $khuyenmai->makm }}" required>
                        </div>

                        <!-- Giá sản phẩm -->
                        <div class="col-md-4 mt-3">
                            <label class="form-label">Mo ta</label>
                            <input type="text" name="mota" class="form-control" value="{{ $khuyenmai->mota }}" required>
                        </div>

                        <!-- Giá khuyến mãi -->
                        <div class="col-md-4 mt-3">
                            <label class="form-label">Ngay bat dau</label>
                            <input type="date" name="ngaybatdau" class="form-control" value="{{ $khuyenmai->ngaybatdau }}">
                        </div>

                        <!-- Mô tả -->
                        <div class="col-md-4 mt-3">
                            <label class="form-label">Ngay ket thuc</label>
                            <input type="date" name="ngayketthuc" class="form-control" value="{{ $khuyenmai->ngayketthuc }}">
                        </div>

                       

                        <!-- Mã combo -->
                        <div class="col-md-4 mt-3">
                            <label class="form-label">He so giam gia</label>
                            <input type="number" name="hesogiamgia" class="form-control" value="{{ $khuyenmai->hesogiamgia }}">
                        </div>

                        <!-- Số lượng -->
                        <div class="col-md-4 mt-3">
                            <label class="form-label">Gia tri DH toi thieu</label>
                            <input type="number" name="sotientoithieu" class="form-control" value="{{ $khuyenmai->sotientoithieu }}">
                           
                        </div>

                         <!-- Số lượng -->
                         <div class="col-md-4 mt-3">
                            <label class="form-label">Gioi han su dung</label>
                            <input type="number" name="gioihan" class="form-control" value="{{ $khuyenmai->gioihan }}">
                           
                        </div>

                         <!-- Số lượng -->
                         <div class="col-md-4 mt-3">
                            <label class="form-label">So tien giam toi thieu</label>
                            <input type="number" name="sotiengiamtoida" class="form-control" value="{{ $khuyenmai->sotiengiamtoida }}">
                        </div>

                        <!-- Trạng thái hiển thị -->
                        <div class="col-md-4 mt-3">
                            <label class="form-label d-block">Trạng thái </label>
                            <div class="form-check form-check-inline">
                                <input class="form-check-input" type="radio" name="hoatdong" value="1"
                                    {{ $khuyenmai->hoatdong == 1 ? 'checked' : '' }}>
                                <label class="form-check-label">Hiển thị</label>
                            </div>
                            <div class="form-check form-check-inline">
                                <input class="form-check-input" type="radio" name="hoatdong" value="0"
                                    {{ $khuyenmai->hoatdong == 0 ? 'checked' : '' }}>
                                <label class="form-check-label">Ẩn</label>
                            </div>

                            
                        </div>
                    </div>
                </div>
            </div>
        </div>

      

        <!-- Buttons -->
        <div class="d-flex justify-content-end mt-4">
            <button type="submit" class="btn btn-primary me-2">Cập nhật </button>
            <a href="{{ route('khuyenmai') }}" class="btn btn-danger">Hủy</a>
        </div>
    </div>
</form>





@if(session('popup'))
<script>
    window.onload = function() {
        if (confirm("{{ session('message') }}")) {
            window.location.href = "{{ route('khuyenmai') }}";
        }
    };
</script>
@endif

</div>
</div>

@endsection