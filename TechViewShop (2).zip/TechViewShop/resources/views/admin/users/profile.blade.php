@extends('admin.layout.layout')

@section('content')
<div class="container my-4">
    <h2>Cập nhật thông tin cá nhân</h2>

    @if(session('message'))
    <div class="alert alert-success">
        {{ session('message') }}
    </div>
    @endif

    <form action="{{ route('user.updateProfile') }}" method="POST" enctype="multipart/form-data">
        @csrf

        @if ($errors->any())
        <div class="alert alert-danger">
            <ul>
                @foreach ($errors->all() as $error)
                <li>{{ $error }}</li>
                @endforeach
            </ul>
        </div>
        @endif

        <!-- Tên -->
        <div class="mb-3">
            <label for="name" class="form-label">Họ tên</label>
            <input type="text" class="form-control" id="name" name="name" value="{{ old('name', $user->hoten) }}">
        </div>

        <!-- Số điện thoại -->
        <div class="mb-3">
            <label for="sodienthoai" class="form-label">Số điện thoại</label>
            <input type="text" class="form-control" id="sodienthoai" name="sodienthoai" value="{{ old('sodienthoai', $user->sodienthoai) }}">
        </div>

        <!-- Email
        <div class="mb-3">
            <label for="email" class="form-label">Email</label>
            <input type="email" class="form-control" id="email" name="email" value="{{ old('email', $user->email) }}" required>
        </div> -->

        <!-- Địa chỉ -->
        <div class="mb-3">
            <label for="diachi" class="form-label">Địa chỉ</label>
            <input type="text" class="form-control" id="diachi" name="diachi" value="{{ old('diachi', $user->diachi) }}">
        </div>

        <!-- Giới tính -->
        <div class="mb-3">
            <label for="gioitinh" class="form-label">Giới tính</label>
            <select class="form-select" id="gioitinh" name="gioitinh">
                <option value="nam" {{ old('gioitinh', $user->gioitinh) == 'nam' ? 'selected' : '' }}>Nam</option>
                <option value="nữ" {{ old('gioitinh', $user->gioitinh) == 'nữ' ? 'selected' : '' }}>Nữ</option>
                <option value="khác" {{ old('gioitinh', $user->gioitinh) == 'khác' ? 'selected' : '' }}>Khác</option>
            </select>
        </div>

        <!-- Ngày sinh -->
        <div class="mb-3">
            <label for="ngaysinh" class="form-label">Ngày sinh</label>
            <input type="date" class="form-control" id="ngaysinh" name="ngaysinh" value="{{ old('ngaysinh', $user->ngaysinh) }}">
        </div>

        <!-- Hình ảnh -->
        <div class="mb-3">
            <label for="hinh" class="form-label">Hình ảnh</label>
            <input type="file" class="form-control" id="hinh" name="hinh">
        </div>

        <!-- Mật khẩu -->
        <div class="mb-3">
            <label for="password" class="form-label">Mật khẩu mới</label>
            <input type="password" class="form-control" id="password" name="password">
        </div>

        <!-- Xác nhận mật khẩu -->
        <div class="mb-3">
            <label for="confirm_password" class="form-label">Xác nhận mật khẩu</label>
            <input type="password" class="form-control" id="confirm_password" name="confirm_password">
        </div>

        <button type="submit" class="btn btn-primary">Cập nhật</button>
    </form>
</div>
@endsection