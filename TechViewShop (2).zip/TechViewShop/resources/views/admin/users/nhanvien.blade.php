@extends('admin.layout.layout')

@section('title', 'Thành viên')

@section('content')

<!-- Nội dung chính của trang sẽ nằm ở đây -->
<div class="container">
    <div class="category-list mt-4 d-flex justify-content-between align-items-center">
        <h4 class="fw-bold">DANH SÁCH THÀNH VIÊN</h4>
        <a href="{{route('auth.register')}}"><button class="btn btn-primary"><i class="bi bi-plus-lg"></i> Đăng ký thành viên mới </button></a>
    </div>
    <div class="table-responsive border-1">
        <table class="table table-hover align-middle">
            <thead class="table-primary">
                <tr>
                    <th>ID</th>
                    <th>Họ tên</th>
                    <th>SDT</th>
                    <th>Email</th>
                    <th>Địa chỉ</th>
                    <th>Giới tính</th>
                    <th>Trạng thái</th>
                    <th>Thao tác</th>
                </tr>
            </thead>
            <tbody>

                @foreach($thanhvien as $thanhvien)

                <tr>
                    <td>{{ $thanhvien->id }}</td>
                    <!-- <td>{{ $thanhvien->hoten }}</td> -->
                    <td>
                        <a class="text-decoration-none text-dark fw-semibold" href="{{ route('nhanvien.show', $thanhvien->id) }}">
                            {{ $thanhvien->hoten }}
                        </a>
                    </td>
                    <td>{{ $thanhvien->sodienthoai }}</td>
                    <td>{{ $thanhvien->email }}</td>
                    <td>{{ $thanhvien->diachi }}</td>
                    <td>{{ $thanhvien->gioitinh == 1 ? 'Nam' : 'Nữ' }}</td>

                    <td>{{ $thanhvien->trangthai == 1 ? ' Còn Hoạt động' : 'Ngừng' }}</td>



                    <td><a href="#"><span class="badge bg-success bg-opacity-10 text-success p-2"><i class="bi bi-pencil"></i> Sửa</span></a> - <a href="#"><span class="badge bg-danger bg-opacity-10 text-danger p-2"><i class="bi bi-trash3"></i> Xoá</span></a></td>
                </tr>
                @endforeach


            </tbody>
        </table>
    </div>
</div>
<nav aria-label="Page navigation example">
    <ul class="pagination justify-content-end">
        <li class="page-item disabled">
            <a class="page-link">Previous</a>
        </li>
        <li class="page-item"><a class="page-link" href="#">1</a></li>
        <li class="page-item"><a class="page-link" href="#">2</a></li>
        <li class="page-item"><a class="page-link" href="#">3</a></li>
        <li class="page-item">
            <a class="page-link" href="#">Next</a>
        </li>
    </ul>
</nav>
</div>

</div>

@endsection