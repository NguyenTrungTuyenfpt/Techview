@extends('admin.layout.layout')

@section('title', 'Chỉnh sửa danh mục bài viết')

@section('content')

<div class="container-fluid mt-5">
    <form action="{{ route('danhmucbaiviet.update', $danhMuc->id) }}" method="POST" style="max-width: 98%; margin: auto;">
        @csrf
        @method('PUT')
        <div class="row w-100">
            <div class="col-xl-8 col-lg-8 col-sm-12 col-12 m-auto">
                @if(Session::has('message'))
                <div class="alert alert-success alert-dismissible">
                    <button type="button" class="close" data-dismiss="alert">×</button>
                    {{ Session::get('message') }}
                </div>
                @elseif(Session::has('failed'))
                <div class="alert alert-danger alert-dismissible">
                    <button type="button" class="close" data-dismiss="alert">×</button>
                    {{ Session::get('failed') }}
                </div>
                @endif
                <div class="card shadow">
                    <div class="card-header d-flex justify-content-between align-items-center mb-4">
                        <h4 class="card-title fw-bold text-primary mb-0">Chỉnh sửa danh mục bài viết</h4>
                        <a href="{{ route('danhmucbaiviet.index') }}" class="btn btn-outline-secondary">
                            <i class="bi bi-arrow-left"></i> Quay lại
                        </a>
                    </div>
                    <div class="card-body">
                        <!-- Tên danh mục -->
                        <div class="form-group mb-3">
                            <label for="tendm" class="form-label fw-semibold">Tên danh mục</label>
                            <input type="text" class="form-control" id="tendm" name="tendm" placeholder="Nhập tên danh mục" value="{{ old('tendm', $danhMuc->tendm) }}" required>
                            @error('tendm')
                                <span class="text-danger">{{ $message }}</span>
                            @enderror
                        </div>

                        <!-- Ẩn/Hiện -->
                        <div class="mb-3">
                            <label class="form-label fw-semibold">Trạng thái</label>
                            <div class="form-check">
                                <input type="checkbox" name="anhien" id="anhien" class="form-check-input" value="1" {{ old('anhien', $danhMuc->anhien) ? 'checked' : '' }}>
                                <label for="anhien" class="form-check-label">Hiển thị</label>
                            </div>
                        </div>
                    </div>

                    <div class="card-footer">
                        <button type="submit" class="btn btn-success">Lưu</button>
                    </div>
                </div>
            </div>
        </div>
    </form>
</div>

<script src="https://ajax.googleapis.com/ajax/libs/jquery/3.6.4/jquery.min.js"></script>
<script src="https://cdn.jsdelivr.net/npm/bootstrap@5.2.3/dist/js/bootstrap.bundle.min.js"></script>
@endsection