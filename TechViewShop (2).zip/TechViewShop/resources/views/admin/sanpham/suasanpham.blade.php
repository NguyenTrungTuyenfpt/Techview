@extends('admin.layout.layout')

@section('title', 'Sửa sản phẩm')

@section('content')
<div class="container mt-5">
    <div class="row justify-content-center">
        <div class="col-lg-12">
            <!-- Breadcrumb -->
            <nav aria-label="breadcrumb" class="mb-4">
                <ol class="breadcrumb">
                    <li class="breadcrumb-item"><a href="/" class="text-muted text-decoration-none">Trang chủ</a></li>
                    <li class="breadcrumb-item active text-primary" aria-current="page">Sửa sản phẩm</li>
                </ol>
            </nav>

            <!-- Card chính -->
            <div class="card border-0 shadow-lg rounded-3">
                <div class="card-header bg-primary text-white p-4 rounded-top">
                    <h2 class="mb-0">Sửa sản phẩm: {{ $sanpham->tensp }}</h2>
                </div>
                <div class="card-body p-4">
                    <!-- Hiển thị thông báo lỗi -->
                    @if ($errors->any())
                    <div class="alert alert-danger alert-dismissible fade show" role="alert">
                        <ul class="mb-0">
                            @foreach ($errors->all() as $error)
                            <li>{{ $error }}</li>
                            @endforeach
                        </ul>
                        <button type="button" class="btn-close" data-bs-dismiss="alert" aria-label="Close"></button>
                    </div>
                    @endif

                    <!-- Form chỉnh sửa -->
                    <form action="{{ route('sanpham.update', $sanpham->id) }}" method="POST" enctype="multipart/form-data">
                        @csrf
                        @method('PUT')

                        <!-- Thông tin sản phẩm -->
                        <div class="mb-4">
                            <h5 class="text-primary mb-3">Thông tin sản phẩm</h5>
                            <div class="p-3 bg-light rounded">
                                <div class="row">
                                    <!-- Tên sản phẩm -->
                                    <div class="col-md-4 mb-3">
                                        <label for="tensp" class="form-label fw-semibold">Tên sản phẩm <span class="text-danger">*</span></label>
                                        <input type="text" name="tensp" id="tensp" class="form-control" value="{{ old('tensp', $sanpham->tensp) }}" required>
                                        @error('tensp')
                                        <small class="text-danger">{{ $message }}</small>
                                        @enderror
                                    </div>

                                    <!-- Giá sản phẩm -->
                                    <div class="col-md-4 mb-3">
                                        <label for="gia" class="form-label fw-semibold">Giá sản phẩm <span class="text-danger">*</span></label>
                                        <input type="number" name="gia" id="gia" class="form-control" value="{{ old('gia', $sanpham->gia) }}" required>
                                        @error('gia')
                                        <small class="text-danger">{{ $message }}</small>
                                        @enderror
                                    </div>

                                    <!-- Giá khuyến mãi -->
                                    <div class="col-md-4 mb-3">
                                        <label for="giamgia" class="form-label fw-semibold">% Khuyến mãi</label>
                                        <input type="number" name="giamgia" id="giamgia" class="form-control" value="{{ old('giamgia', $sanpham->giamgia) }}">
                                        @error('giamgia')
                                        <small class="text-danger">{{ $message }}</small>
                                        @enderror
                                    </div>

                                    <!-- Mô tả -->
                                    <div class="col-md-4 mb-3">
                                        <label for="mota" class="form-label fw-semibold">Mô tả</label>
                                        <textarea name="mota" id="mota" class="form-control" rows="3">{{ old('mota', $sanpham->mota) }}</textarea>
                                        @error('mota')
                                        <small class="text-danger">{{ $message }}</small>
                                        @enderror
                                    </div>

                                    <!-- Danh mục -->
                                    <div class="col-md-4 mb-3">
                                        <label for="id_danhmuc" class="form-label fw-semibold">Danh mục</label>
                                        <select name="id_danhmuc" id="id_danhmuc" class="form-select">
                                            @foreach($danhmuc as $dm)
                                            <option value="{{ $dm->id }}" {{ old('id_danhmuc', $sanpham->id_danhmuc) == $dm->id ? 'selected' : '' }}>
                                                {{ $dm->tendm }}
                                            </option>
                                            @endforeach
                                        </select>
                                        @error('id_danhmuc')
                                        <small class="text-danger">{{ $message }}</small>
                                        @enderror
                                    </div>

                                    <!-- Nhà cung cấp -->
                                    <div class="col-md-4 mb-3">
                                        <label for="id_nhacungcap" class="form-label fw-semibold">Nhà cung cấp</label>
                                        <select name="id_nhacungcap" id="id_nhacungcap" class="form-select">
                                            @foreach($nhacungcap as $cc)
                                            <option value="{{ $cc->id }}" {{ old('id_nhacungcap', $sanpham->id_nhacungcap) == $cc->id ? 'selected' : '' }}>
                                                {{ $cc->ten_ncc }}
                                            </option>
                                            @endforeach
                                        </select>
                                        @error('id_nhacungcap')
                                        <small class="text-danger">{{ $message }}</small>
                                        @enderror
                                    </div>

                                    <!-- Thương hiệu -->
                                    <div class="col-md-4 mb-3">
                                        <label for="thuonghieu" class="form-label fw-semibold">Thương hiệu</label>
                                        <input type="text" name="thuonghieu" id="thuonghieu" class="form-control" value="{{ old('thuonghieu', $sanpham->thuonghieu) }}">
                                        @error('thuonghieu')
                                        <small class="text-danger">{{ $message }}</small>
                                        @enderror
                                    </div>

                                    <!-- Số lượng -->
                                    <div class="col-md-4 mb-3">
                                        <label for="soluong" class="form-label fw-semibold">Số lượng</label>
                                        <input type="number" name="soluong" id="soluong" class="form-control" value="{{ old('soluong', $sanpham->soluong) }}">
                                        @error('soluong')
                                        <small class="text-danger">{{ $message }}</small>
                                        @enderror
                                    </div>

                                    <div class="col-md-4 mt-3">
                                        <label class="form-label">Tên thông số sản phẩm</label>
                                        <input type="text" name="tenthongso" class="form-control" placeholder="Nhập tại đây" >
                                    </div>
                                    <div class="col-md-4 mt-3">
                                        <label class="form-label">Giá trị thông số của sản phẩm</label>
                                        <input type="text" name="giatrithongso" class="form-control" placeholder="Nhập tại đây">
                                    </div>

                                    <!-- Trạng thái hiển thị và nổi bật -->
                                    <div class="col-md-4 mb-3">
                                        <label class="form-label fw-semibold">Trạng thái hiển thị</label>
                                        <div class="d-flex mb-3">
                                            <div class="form-check me-3">
                                                <input class="form-check-input" type="radio" name="anhien" id="anhien1" value="1" {{ old('anhien', $sanpham->anhien) == 1 ? 'checked' : '' }}>
                                                <label class="form-check-label" for="anhien1">Hiển thị</label>
                                            </div>
                                            <div class="form-check">
                                                <input class="form-check-input" type="radio" name="anhien" id="anhien0" value="0" {{ old('anhien', $sanpham->anhien) == 0 ? 'checked' : '' }}>
                                                <label class="form-check-label" for="anhien0">Ẩn</label>
                                            </div>
                                        </div>
                                        @error('anhien')
                                        <small class="text-danger">{{ $message }}</small>
                                        @enderror

                                        <label class="form-label fw-semibold">Trạng thái nổi bật</label>
                                        <div class="d-flex">
                                            <div class="form-check me-3">
                                                <input class="form-check-input" type="radio" name="noibat" id="noibat1" value="1" {{ old('noibat', $sanpham->noibat) == 1 ? 'checked' : '' }}>
                                                <label class="form-check-label" for="noibat1">Nổi bật</label>
                                            </div>
                                            <div class="form-check">
                                                <input class="form-check-input" type="radio" name="noibat" id="noibat0" value="0" {{ old('noibat', $sanpham->noibat) == 0 ? 'checked' : '' }}>
                                                <label class="form-check-label" for="noibat0">Không nổi bật</label>
                                            </div>
                                        </div>
                                        @error('noibat')
                                        <small class="text-danger">{{ $message }}</small>
                                        @enderror
                                    </div>
                                </div>
                            </div>
                        </div>

                        <!-- Ảnh chính -->
                        <div class="mb-4">
                            <h5 class="text-primary mb-3">Ảnh chính</h5>
                            <div class="p-3 bg-light rounded text-center">
                                @if($sanpham->hinh)
                                <img src="{{ asset('uploads/sanpham/' . $sanpham->hinh) }}"
                                    class="img-fluid rounded shadow-sm border mb-3"
                                    style="max-height: 150px; object-fit: cover;"
                                    alt="Ảnh chính hiện tại">
                                <p class="text-muted mb-2">Ảnh chính hiện tại</p>
                                @else
                                <div class="bg-white rounded p-3 border mb-3" style="width: 150px; height: 150px; margin: 0 auto;">
                                    <i class="bi bi-image text-muted" style="font-size: 2rem;"></i>
                                    <p class="text-muted mt-2 small">Chưa có ảnh chính</p>
                                </div>
                                @endif
                                <label for="anhchinh" class="form-label fw-semibold">Chọn ảnh mới (nếu muốn thay đổi)</label>
                                <input type="file" name="anhchinh" id="anhchinh" class="form-control w-50 mx-auto">
                                @error('anhchinh')
                                <small class="text-danger">{{ $message }}</small>
                                @enderror
                            </div>
                        </div>

                        <!-- Ảnh phụ hiện tại -->
                        <div class="mb-4">
                            <h5 class="text-primary mb-3">Ảnh phụ hiện tại</h5>
                            <div class="p-3 bg-light rounded">
                                @if(count($sanpham->anhsanpham) > 0)
                                <div class="row">
                                    @foreach($sanpham->anhsanpham as $anh)
                                    <div class="col-md-3 col-sm-6 mb-3 text-center">
                                        <img src="{{ asset('uploads/sanpham/' . $anh->src) }}"
                                            class="img-fluid rounded shadow-sm border"
                                            style="max-height: 120px; object-fit: cover;"
                                            alt="Ảnh phụ">
                                        <div class="form-check mt-2">
                                            <input class="form-check-input" type="checkbox" name="xoa_anhphu[]" id="xoa_anhphu_{{ $anh->id }}" value="{{ $anh->id }}">
                                            <label class="form-check-label" for="xoa_anhphu_{{ $anh->id }}">Xóa ảnh này</label>
                                        </div>
                                    </div>
                                    @endforeach
                                </div>
                                @else
                                <div class="alert alert-info text-center" role="alert">
                                    <i class="bi bi-info-circle me-2"></i> Không có ảnh phụ nào.
                                </div>
                                @endif
                            </div>
                        </div>

                        <!-- Thêm ảnh phụ mới -->
                        <div class="mb-4">
                            <h5 class="text-primary mb-3">Thêm ảnh phụ mới</h5>
                            <div class="p-3 bg-light rounded">
                                <label for="anhphu" class="form-label fw-semibold">Chọn ảnh phụ mới (có thể chọn nhiều ảnh)</label>
                                <input type="file" name="anhphu[]" id="anhphu" class="form-control w-50" multiple>
                                @error('anhphu.*')
                                <small class="text-danger">{{ $message }}</small>
                                @enderror
                            </div>
                        </div>

                        <!-- Nút hành động -->
                        <div class="text-end">
                            <button type="submit" class="btn btn-success me-2">
                                <i class="bi bi-check-circle"></i> Cập nhật sản phẩm
                            </button>
                            <a href="{{ route('sanpham') }}" class="btn btn-outline-danger">
                                <i class="bi bi-x-circle"></i> Hủy
                            </a>
                        </div>
                    </form>
                </div>
            </div>
        </div>
    </div>
</div>

@if(session('popup'))
<script>
    window.onload = function() {
        if (confirm("{{ session('message') }}")) {
            window.location.href = "{{ route('sanpham') }}";
        }
    };
</script>
@endif

<style>
    .card {
        transition: transform 0.3s ease, box-shadow 0.3s ease;
    }

    .card:hover {
        transform: translateY(-5px);
        box-shadow: 0 10px 20px rgba(0, 0, 0, 0.1) !important;
    }

    .form-control,
    .form-select {
        transition: border-color 0.3s ease;
    }

    .form-control:focus,
    .form-select:focus {
        border-color: #0d6efd;
        box-shadow: 0 0 5px rgba(13, 110, 253, 0.2);
    }

    .img-fluid {
        transition: transform 0.3s ease;
    }

    .img-fluid:hover {
        transform: scale(1.05);
    }
</style>
@endsection