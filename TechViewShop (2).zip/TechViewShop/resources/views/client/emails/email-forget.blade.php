<!DOCTYPE html>
<html>
<head>
    <title>Đặt lại mật khẩu</title>
    <link rel="stylesheet" href="{{ asset('/css/email.css')}}">
</head>
<body>
    <div class="email">
        <h2 class="email-title">TechView Shop</h2>
        <div class="email-content">
            <h4 class="email-desc">Xin chào</h4>
            <p class="email-message">Bạn đã yêu cầu đặt lại mật khẩu. Vui lòng nhấp vào liên kết dưới đây:</p>
            <a href="{{ route('account.reset_password', $token) }}" class="email-link">Đặt lại mật khẩu</a>
            <p class="email-skip">Nếu bạn không yêu cầu điều này, hãy bỏ qua email này.</p>
        </div>
    </div>
</body>
</html>
