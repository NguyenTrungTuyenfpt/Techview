@extends('client.layout.layout')
@section('title')
    Trang sản phẩm yêu thích
@endsection

@section('body')
    <div class="wishlist">
        <div class="grid container">
            <div class="row">
                <div class="col l-12 m-12 c-12">
                    @if (session('success'))
                        <div class="success">
                            {{ session('success') }}
                        </div>
                    @endif
                    @if(count($favoriteList) > 0)
                        <div class="table-responsive">
                            <table class="product-table">
                                <thead>
                                    <tr>
                                        <th class="product-table-mobile" width="50%" colspan="2">Sản phẩm</th>
                                        <th class="product-table-mobile" width="10%">Giá</th>
                                        <th class="product-table-mobile" width="15%">Ngày thêm</th>
                                        <th class="product-table-mobile" width="10%">Còn hàng</th>
                                        <th class="product-table-mobile" width="15%">Thêm vào giỏ hàng</th>
                                    </tr>
                                </thead>
                                <tbody>
                                    @foreach ($favoriteList as $favorite)
                                        <tr>
                                            <td>
                                                <img src="{{ asset('/img/sanpham/'.$favorite->product->hinh)}}" alt="No image" class="">
                                            </td>
                                            <td>
                                                <span class="product-table__item-name"> {{ $favorite->product->tensp }} </span>
                                            </td>
                                            <td>
                                                @if ($favorite->product->giamgia)
                                                    <p><del>{{ number_format($favorite->product->gia) }}₫</del></p>
                                                    <span class="discounted">
                                                        {{ number_format($favorite->product->gia*(1 - ($favorite->product->giamgia/100))) }}₫
                                                    </span>
                                                @else
                                                    <span class="discounted">
                                                        {{ number_format($favorite->product->gia) }}₫
                                                    </span>
                                                @endif
                                            </td>
                                            <td><span class="product-table__item-name">{{ $favorite->ngaythem }}</span></td>
    
                                            @if ($favorite->product->tonkho > 0)
                                                <td class="stock in-stock product-table__item-name">
                                                    Còn hàng
                                                </td>
                                            @elseif ($favorite->product->tonkho == 0)
                                                <td class="stock item-ofstock product-table__item-name">
                                                    Hết hàng
                                                </td>
                                            @endif
    
                                            <td class="addcart" >
                                                @if ($favorite->product->tonkho == 0)
                                                    <button type="submit" class="add-to-cart hide-on-mobile hide-on-table">Thêm vào giỏ</button>
                                                @else
                                                    <form action="{{ route('cart.add') }}" method="post">
                                                        @csrf
                                                        <input type="hidden" name="id" value="{{ $favorite->product->id }}">
                                                        <input type="hidden" class="qty-input" name="quantity" value="1" min="1" max="{{ $favorite->product->tonkho }}">
                                                        <button type="submit" class="add-to-cart hide-on-mobile hide-on-table">Thêm vào giỏ</button>
                                                    </form>
                                                @endif
                                                
                                                <form action="{{ route('favorite.delete', $favorite->id) }}" 
                                                    method="POST" 
                                                    onsubmit="return confirm('Bạn có chắc chắn muốn xóa không?')"
                                                >
                                                    @csrf
                                                    <button type="submit" class="addcart-icon__link">
                                                        <i class="addcart-icon__link-icon fa-solid fa-xmark"></i>
                                                    </button>
                                                </form>
                                            </td>
                                        </tr>
                                    @endforeach
                                </tbody>
                            </table>
                        </div>
                    @else
                        <p class="product-table-empty">Bạn chưa có sản phẩm yêu thích</p>
                    @endif
                </div>
            </div>

            @if (count($favoriteList) > 0)
                <div class="row">
                    <div class="col l-12">
                        <a href="javascript:void(0)" onclick="history.back()" class="shopingcart-link ">
                            <i class="shopingcart-link__icon fa-solid fa-arrow-left"></i>
                            Quay lại trang chủ
                        </a>
                    </div>
                </div>
            @endif
        </div>

    </div>
@endsection