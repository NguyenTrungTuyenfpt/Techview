@extends('client.layout.layout')
@section('title')
    Trang chủ
@endsection

@section('body')
    <!-- Banner 1-->
    <section class="section-banner hide-on-mobile hide-on-tablet">
        <div class="container">
            <div class="row">
                <div class="col l-3"></div>
                <div class="col l-9">
                    <div class="banner">
                        <div class="sub-menu"></div>
                        <div class="slideshow-container">
                            <div class="mySlides fade">
                                {{-- <div class="numbertext">1</div> --}}
                                <img class="slideshow-img" src="{{asset('/')}}img/banner1.png">
                                {{-- <div class="text">Caption Text</div> --}}
                            </div>
                            
                            <div class="mySlides fade">
                                {{-- <div class="numbertext">2</div> --}}
                                <img class="slideshow-img" src="{{asset('/')}}img/banner2.jpg">
                                {{-- <div class="text">Caption Two</div> --}}
                            </div>
                            
                            <div class="mySlides fade">
                                {{-- <div class="numbertext">3</div> --}}
                                <img class="slideshow-img" src="{{asset('/')}}img/banner3.jpg">
                                {{-- <div class="text">Caption Three</div> --}}
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </section>
    <!-- End banner -->

    {{-- Sản phẩm mới--}}
    <section class="featuredProduct">
        <div class="grid container">
            <div class="section-product__head">
                <h3 class="section-product__title">Sản phẩm mới</h3>
                <a href="{{ route('product') }}" class="section-product__link pl-none">
                    Xem tất cả
                    <i class="section-product__icon fa-solid fa-arrow-right"></i>
                </a>
            </div>
            <div class="product-slider">
                <div class="row">
                    <div class="product-container">
                        @foreach ($productList as $product)
                            @php
                                $rating = collect($rating)->firstWhere('id_sanpham', $product->id) ?? (object) ['tb_sao' => 0, 'dem' => 0];
                            @endphp
                            <div class="col l-2-4 m-4 c-6 pr-none">
                                <div class="product">
                                    <div class="product-item">
                                        <a href="product/detail/{{ $product->slug}}" class="product-item__link">
                                            @if ($product->giamgia)
                                                <span class="product-item__discount">-{{ $product->giamgia }}%</span>
                                            @endif
                                            <img src="{{ asset('/img/sanpham/'.$product->hinh) }}" class="product-item__img" alt="Kính thiên văn">
                                        </a>

                                        @if ($product->tonkho == 0)
                                            <div class="product-detail__status">
                                                Hết hàng
                                            </div>
                                        @endif
                                        <form action="{{ route('favorite.add') }}" method="POST">
                                            @csrf
                                            <input type="hidden" name="id" value="{{ $product->id }}">
                                            <button type="submit" class="product-item__heart-link">
                                                <i class="fa-regular fa-heart product-item__heart"></i>
                                            </button>
                                        </form>  
                                    </div>
                                    
                                    <div class="product-content">
                                        <a href="product/detail/{{ $product->slug}}" class="product-title"> {{ $product->tensp}} </a>
                                        
                                        <div class="product-rating">
                                            <div class="product-rating__list">
                                                @for ($i = 0; $i < ($rating->tb_sao ?? 0) ; $i++)
                                                    <i class="icon-rating fa-solid fa-star"></i>
                                                @endfor
                                                @for ($i = 0; $i < (5 - ($rating->tb_sao ?? 0)) ; $i++)
                                                    <i class="icon-rating-none fa-solid fa-star"></i>
                                                @endfor                                   
                                            </div>
                                           
                                            @if ($rating->dem > 0)
                                                <span class="product-review">
                                                    {{ $rating->dem }}
                                                    đánh giá
                                                </span>
                                            @else    
                                                <span class="product-review">Chưa đánh giá</span>
                                            @endif
                                            
                                        </div>
                                        <div class="product-cart">
                                            <div class="product-price">
                                                @if ($product->giamgia)
                                                    <p class="old-price"><del>{{ number_format($product->gia) }}</del>đ</p>
                                                    <p class="new-price">
                                                        {{ number_format($product->gia * (1 - ($product->giamgia/100))) }}₫
                                                    </p>
                                                @else
                                                    <p class="new-price">{{ number_format($product->gia) }}₫</p>
                                                @endif
                                            </div>
                                            @if ($product->tonkho == 0)
                                                <button type="submit" class="product-cart__link">
                                                    <i class="product-cart__icon fa-solid fa-cart-shopping"></i>
                                                </button>
                                            @else
                                                <form action="{{ route('cart.add') }}" method="POST">
                                                    @csrf
                                                    <input type="hidden" name="id" value="{{ $product->id }}">
                                                    <input type="hidden" name="quantity" value="1">
                                                    <button type="submit" class="product-cart__link">
                                                        <i class="product-cart__icon fa-solid fa-cart-shopping"></i>
                                                    </button>
                                                </form>
                                            @endif
                                        </div>
                                        <div class="product-status">
                                            @if ($product->tonkho == 0)
                                                <svg xmlns="http://www.w3.org/2000/svg" width="15" height="16" viewBox="0 0 15 16" fill="none">
                                                    <path d="M14.1358 3.43605L8.57846 0.28359C7.91183 -0.0945299 7.08783 -0.0945299 6.42121 0.28359L0.864174 3.43605C0.686049 3.53698 0.687054 3.78823 0.866183 3.88791L7.5 7.57974L14.1342 3.88791C14.3133 3.78823 14.3143 3.53729 14.1358 3.43605ZM14.5992 4.83071L8.03571 8.48316V15.4774C8.03571 15.8799 8.48404 16.1309 8.84096 15.9284L13.9356 13.0384C14.5945 12.6647 15 11.9778 15 11.2353V5.05727C15 4.85696 14.7777 4.73134 14.5992 4.83071ZM0 5.05727V11.2353C0 11.9781 0.405469 12.6647 1.0644 13.0384L6.15904 15.9281C6.51629 16.1306 6.96429 15.8799 6.96429 15.4771V8.48316L0.400781 4.83071C0.222321 4.73134 0 4.85696 0 5.05727Z" fill="#099268"/>
                                                </svg>
                                                <span class="item-ofstock">Hết hàng</span>
                                            @else
                                                <svg xmlns="http://www.w3.org/2000/svg" width="15" height="16" viewBox="0 0 15 16" fill="none">
                                                    <path d="M14.1358 3.43605L8.57846 0.28359C7.91183 -0.0945299 7.08783 -0.0945299 6.42121 0.28359L0.864174 3.43605C0.686049 3.53698 0.687054 3.78823 0.866183 3.88791L7.5 7.57974L14.1342 3.88791C14.3133 3.78823 14.3143 3.53729 14.1358 3.43605ZM14.5992 4.83071L8.03571 8.48316V15.4774C8.03571 15.8799 8.48404 16.1309 8.84096 15.9284L13.9356 13.0384C14.5945 12.6647 15 11.9778 15 11.2353V5.05727C15 4.85696 14.7777 4.73134 14.5992 4.83071ZM0 5.05727V11.2353C0 11.9781 0.405469 12.6647 1.0644 13.0384L6.15904 15.9281C6.51629 16.1306 6.96429 15.8799 6.96429 15.4771V8.48316L0.400781 4.83071C0.222321 4.73134 0 4.85696 0 5.05727Z" fill="#099268"/>
                                                </svg>
                                                <span class="item-stock">Còn hàng</span>
                                            @endif
                                        </div>
                                    </div>
                                </div>
                            </div>                            
                        @endforeach
                    </div>
                </div>
            </div>
            
            <!-- Dấu chấm điều hướng -->
            <div class="dots">
                <span class="dot active" onclick="moveSlide(0)"></span>
                <span class="dot" onclick="moveSlide(1)"></span>
                <span class="dot" onclick="moveSlide(2)"></span>
                <span class="dot" onclick="moveSlide(3)"></span>
                <span class="dot" onclick="moveSlide(4)"></span>
                <span class="dot" onclick="moveSlide(5)"></span>
            </div>
        </div>
    </section>

    {{-- Banner 2 --}}
    <section class="banner">
        <div class="grid container">
            <div class="row">
                <div class="col l-4 m-4 c-12">
                    <a class="banner__link" href="#">
                        <img class="banner__link-img" src="{{asset('/img/banner4.webp')}}" alt="">
                    </a>
                </div>
                <div class="col l-4 m-4 c-12">
                    <a class="banner__link" href="#">
                        <img class="banner__link-img" src="{{asset('/img/banner5.webp')}}" alt="">
                    </a>
                </div>
                <div class="col l-4 m-4 c-12">
                    <a class="banner__link" href="#">
                        <img class="banner__link-img" src="{{asset('/img/banner6.webp')}}" alt="">
                    </a>
                </div>
            </div>
        </div>
    </section>

    {{-- Sản phẩm giảm giá nhiều nhất và mới nhất --}}
    <section class="deals">
        <div class="grid container">
            <div class="section-deals__head">
                <h3 class="section-deals__title">Ưu Đãi Mới Nhất</h3>
                <a href="{{ route('product.byType', ['slug' => 'sale']) }}" class="section-deals__link">
                    Xem tất cả
                    <i class="section-deals__icon fa-solid fa-arrow-right"></i>
                </a>
            </div>
            <div class="product-list">
                <div class="row">
                    @foreach ($productHotSaller as $product)
                        <div class="col l-6 m-6 c-12">
                            <div class="deals-item">
                                <span class="product-deals__discount">-{{ $product->giamgia }}%</span>
                                <div class="row">
                                    <div class="col l-4 m-12 c-12">
                                        <div class="deals-header">
                                            <div class="product-deals-header">
                                                <a href="product/detail/{{ $product->slug }}" class="product-deals__link">
                                                    <img src=" {{ asset('img/sanpham/'. $product->hinh) }}" class="product-deals__img" alt="Kính thiên văn">
                                                </a>
                                                @if ($product->tonkho == 0)
                                                    <div class="product-detail__status">
                                                        Hết hàng
                                                    </div>
                                                @endif
                                                <form action="{{ route('favorite.add') }}" method="POST">
                                                    @csrf
                                                    <input type="hidden" name="id" value="{{ $product->id }}">
                                                    <button type="submit" class="product-item__heart-link">
                                                        <i class="fa-regular fa-heart product-item__heart"></i>
                                                    </button>
                                                </form>  
                                            </div>
                                        </div>
                                    </div>
                                    <div class="col l-8 m-12 c-12">
                                        <div class="deals-content">
                                            <a href="product/detail/{{ $product->slug }}" class="deals-title"> {{ $product->tensp }} </a>
                                            <div class="deals-rating">
                                                <div class="deals-rating__list">
                                                    @for ($i = 0; $i < ($rating->tb_sao ?? 0) ; $i++)
                                                        <i class="icon-rating fa-solid fa-star"></i>
                                                    @endfor
                                                    @for ($i = 0; $i < (5 - ($rating->tb_sao ?? 0)) ; $i++)
                                                        <i class="icon-rating-none fa-solid fa-star"></i>
                                                    @endfor                                   
                                                </div>
                                               
                                                @if ($rating->dem)
                                                    <span class="deals-review">
                                                        {{ $rating->dem }}
                                                        đánh giá
                                                    </span>
                                                @else    
                                                    <span class="deals-review">Chưa đánh giá</span>
                                                @endif
                                            </div>
                                            <div class="deals-cart">
                                                <div class="deals-price">
                                                    @if ($product->giamgia)
                                                        <p class="old-price"><del> {{ number_format($product->gia) }} </del>₫</p>
                                                        <p class="new-price">
                                                            {{ number_format($product->gia * (1- ($product->giamgia/100))) }}₫
                                                        </p> 
                                                    @else
                                                        <p class="new-price">{{ number_format($product->gia) }}₫</p>
                                                    @endif
                                                </div>
                                                @if ($product->tonkho == 0)
                                                    <button type="submit" class="product-cart__link">
                                                        <i class="product-cart__icon fa-solid fa-cart-shopping"></i>
                                                    </button>
                                                @else
                                                    <form action="{{ route('cart.add') }}" method="POST">
                                                        @csrf
                                                        <input type="hidden" name="id" value="{{ $product->id }}">
                                                        <input type="hidden" name="quantity" value="1">
                                                        <button type="submit" class="product-cart__link">
                                                            <i class="product-cart__icon fa-solid fa-cart-shopping"></i>
                                                        </button>
                                                    </form>
                                                @endif
                                            </div>
                                            <div class="deals-wrapper">
                                                <div class="deals-progress">
                                                    <span class="progress" style="width: {{ (($sold_quantity[$product->id] ?? 0) / $product->soluong )*100 }}%"></span>
                                                    <span class="no-progress" style="width: {{ 100 - ($product->soluong - ($sold_quantity[$product->id] ?? 0)) }}%"></span>
                                                </div>
                                                <div class="deals-count">
                                                    <div class="available">
                                                        Có sẵn:
                                                        <strong class="available-bold">{{ $product->soluong }}</strong>
                                                    </div>
                                                    <div class="sold">
                                                        Đã bán:
                                                        <strong class="sold-bold">{{ $sold_quantity[$product->id] ?? 0 }}</strong>
                                                    </div>
                                                </div>
                                            </div>
                                        </div>
                                    </div>
                                </div>
                            </div>
                        </div>
                    @endforeach
                </div>

            </div>
    </section>

    {{-- Khuyến mãi --}}
    @if ($coupon)
        <section class="widget">
            <div class="grid container">
                <div class="row">
                    <div class="col l-12 m-12 c-12">
                        <a class="coupon-wrapper" href="#!">
                            <div class="">
                                <div class="promo-badge">🎁 KHUYẾN MÃI</div>
                                <div class="coupon-sale">
                                    -{{ $coupon->hesogiamgia }}
                                    <span>%</span>
                                </div>
                            </div>
                            <div class="text-wrap">
                                <div class="coupon-title">{{ $coupon->mota }}</div>
                                <div class="coupon-desc">Sử dụng mã giảm giá ở trang thanh toán</div>
                            </div>
                            <div class="sale-overflow hide-on-mobile hide-on-tablet">
                                -
                                {{ $coupon->hesogiamgia }}
                                %
                            </div>
                        
                            <button class="coupon-code" id="promoCode" onclick="copyPromoCode()">{{ $coupon->makm }}</button>
                        </a>
                    </div>
                </div>
            </div>
        </section>
    @endif

    {{-- Sản phẩm hot --}}
    <section class="section-product ">
        <div class="grid container">
            <div class="row">
                <div class="col l-3 m-3 c-12 p-none">
                    <div class="promo-banner" href="">
                        <div class="promo-banner__discount">-{{$coupon->hesogiamgia}}%</div>
                        <div class="promo-banner__text">
                            <h2 class="promo-banner__title">Sản phẩm nổi bật</h2>
                            <p class="promo-banner__desc">{{$coupon->mota}}</p>
                        </div>
                        <a href="{{ route('product.byType', ['slug' => 'hot']) }}" class="promo-banner__link">Xem tất cả →</a>
                    </div>
                </div>
                <div class="col l-9 m-9 c-12 p-none">
                    <div class="row ">
                        @foreach ($productHot as $product)
                            <div class="col l-3 m-4 c-6 p-none">
                                <div class="item__list">
                                <div class="item">
                                    <div class="item-box">
                                        <a href="product/detail/{{ $product->slug }}" class="item-box__link">
                                            @if ($product->giamgia)
                                                <span class="item-box__discount">-{{ $product->giamgia }}%</span>
                                            @endif
                                            <img src="{{asset('img/sanpham/'.$product->hinh)}}" class="item-box__img" alt="{{ $product->hinh }}">
                                        </a>
                                        @if ($product->tonkho == 0)
                                            <div class="product-detail__status">
                                                Hết hàng
                                            </div>
                                        @endif

                                        <form action="{{ route('favorite.add') }}" method="POST">
                                            @csrf
                                            <input type="hidden" name="id" value="{{ $product->id }}">
                                            <button type="submit" class="product-item__heart-link">
                                                <i class="fa-regular fa-heart product-item__heart"></i>
                                            </button>
                                        </form>  
                                    </div>
                                    <div class="item-details">
                                        <a href="product/detail/{{ $product->slug }}" class="item-title">
                                            {{ $product->tensp }}
                                        </a>
                                        <div class="item-rating">
                                            <div class="item-rating__list">
                                                @for ($i = 0; $i < ($rating->tb_sao ?? 0); $i++)
                                                    <i class="icon-rating fa-solid fa-star"></i>
                                                @endfor

                                                @for ($i = 0; $i < (5 - ($rating->tb_sao ?? 0)); $i++)
                                                    <i class="icon-rating-none fa-solid fa-star"></i>
                                                @endfor                                        
                                            </div>
                                            @if ($rating->dem)
                                                <span class="item-review">{{ $rating->dem }} đánh giá</span>
                                            @endif
                                        </div>
                                        <div class="item-cart">
                                            <div class="item-price">
                                                @if ($product->giamgia)
                                                    <p class="old-price"><del> {{ number_format($product->gia) }} </del>₫</p>
                                                    <p class="new-price">
                                                        {{ number_format($product->gia * (1- ($product->giamgia/100))) }}₫
                                                    </p> 
                                                @else
                                                    <p class="new-price">{{ number_format($product->gia) }}₫</p>
                                                @endif
                                            </div>
                                            @if ($product->tonkho == 0)
                                                <button type="submit" class="item-cart__link">
                                                    <i class="item-cart__icon fa-solid fa-cart-shopping"></i>
                                                </button>
                                            @else
                                                <form action="{{ route('cart.add') }}" method="POST">
                                                    @csrf
                                                    <input type="hidden" name="id" value="{{ $product->id }}">
                                                    <input type="hidden" name="quantity" value="1">
                                                    <button type="submit" class="item-cart__link">
                                                        <i class="item-cart__icon fa-solid fa-cart-shopping"></i>
                                                    </button>
                                                </form>
                                            @endif
                                        </div>
                                        <div class="item-status">
                                            @if ($product->tonkho == 0)
                                                <svg xmlns="http://www.w3.org/2000/svg" width="15" height="16" viewBox="0 0 15 16" fill="none">
                                                    <path d="M14.1358 3.43605L8.57846 0.28359C7.91183 -0.0945299 7.08783 -0.0945299 6.42121 0.28359L0.864174 3.43605C0.686049 3.53698 0.687054 3.78823 0.866183 3.88791L7.5 7.57974L14.1342 3.88791C14.3133 3.78823 14.3143 3.53729 14.1358 3.43605ZM14.5992 4.83071L8.03571 8.48316V15.4774C8.03571 15.8799 8.48404 16.1309 8.84096 15.9284L13.9356 13.0384C14.5945 12.6647 15 11.9778 15 11.2353V5.05727C15 4.85696 14.7777 4.73134 14.5992 4.83071ZM0 5.05727V11.2353C0 11.9781 0.405469 12.6647 1.0644 13.0384L6.15904 15.9281C6.51629 16.1306 6.96429 15.8799 6.96429 15.4771V8.48316L0.400781 4.83071C0.222321 4.73134 0 4.85696 0 5.05727Z" fill="#099268"/>
                                                </svg>
                                                <span class="item-ofstock">Hết hàng</span>
                                            @else
                                                <svg xmlns="http://www.w3.org/2000/svg" width="15" height="16" viewBox="0 0 15 16" fill="none">
                                                    <path d="M14.1358 3.43605L8.57846 0.28359C7.91183 -0.0945299 7.08783 -0.0945299 6.42121 0.28359L0.864174 3.43605C0.686049 3.53698 0.687054 3.78823 0.866183 3.88791L7.5 7.57974L14.1342 3.88791C14.3133 3.78823 14.3143 3.53729 14.1358 3.43605ZM14.5992 4.83071L8.03571 8.48316V15.4774C8.03571 15.8799 8.48404 16.1309 8.84096 15.9284L13.9356 13.0384C14.5945 12.6647 15 11.9778 15 11.2353V5.05727C15 4.85696 14.7777 4.73134 14.5992 4.83071ZM0 5.05727V11.2353C0 11.9781 0.405469 12.6647 1.0644 13.0384L6.15904 15.9281C6.51629 16.1306 6.96429 15.8799 6.96429 15.4771V8.48316L0.400781 4.83071C0.222321 4.73134 0 4.85696 0 5.05727Z" fill="#099268"/>
                                                </svg>
                                                <span class="item-stock">Còn hàng</span>
                                            @endif
                                        </div>
                                    </div>
                                </div>
                                </div>
                            </div>
                        @endforeach
                    </div>
                </div>
            </div>
        </div>
    </section>

    {{-- Banner 2 --}}
    <section class="banner2">
        <div class="grid container">
            <div class="row">
                <div class="col l-6 m-6 c-12">
                    <a class="banner2__link" href="#">
                        <img class="banner2__link-img" src="{{asset('/img/banner7.webp')}}" alt="">
                    </a>
                </div>
                <div class="col l-6 m-6 c-12">
                    <a class="banner2__link" href="#">
                        <img class="banner2__link-img" src="{{asset('/img/banner8.webp')}}" alt="">
                    </a>
                </div>
            </div>
        </div>
    </section>

    {{-- Sản Phẩm Khuyến mãi --}}
    <section class="sales">
        <div class="grid container">
            <div class="section-sales__head">
                <h3 class="section-sales__title">Sản Phẩm Khuyến mãi</h3>
                @if (isset($countdown['end_time']))
                    <div class="date-time" id="countdown" data-time={{ $countdown['end_time'] }}>
                        <div id="days">00</div>
                        <span class="separator">:</span>
                        <div id="hours">00</div>
                        <span class="separator">:</span>
                        <div id="minutes">00</div>
                        <span class="separator">:</span>
                        <div id="seconds">00</div>
                    </div>
                @endif
                <a href="{{ route('product.byType', ['slug' => 'sale']) }}" class="section-sales__link">
                    Xem tất cả
                    <i class="section-sales__icon fa-solid fa-arrow-right"></i>
                </a>
            </div>
            <div class="row">
                @foreach ($productSaller as $product)
                    <div class="col l-2-4 m-4 c-6 pr-none">
                        <div class="product">
                            <div class="product-item">
                                <a href="product/detail/{{$product->slug}}" class="product-item__link">
                                    @if ($product->giamgia)
                                        <span class="product-item__discount">-{{ $product->giamgia }}%</span>
                                    @endif
                            
                                    <img src="{{asset('img/sanpham/'.$product->hinh) }}" class="product-item__img" alt="Kính thiên văn">
                                </a>
                                @if ($product->tonkho == 0)
                                    <div class="product-detail__status">
                                        Hết hàng
                                    </div>
                                @endif 

                                <form action="{{ route('favorite.add') }}" method="POST">
                                    @csrf
                                    <input type="hidden" name="id" value="{{ $product->id }}">
                                    <button type="submit" class="product-item__heart-link">
                                        <i class="fa-regular fa-heart product-item__heart"></i>
                                    </button>
                                </form>  
                            </div>
                            
                            <div class="product-content">
                                <a href="product/detail/{{$product->slug}}" class="product-title"> {{ $product->tensp }} </a>
                                <div class="product-rating">
                                    <div class="product-rating__list">
                                        @for ($i = 0; $i < ($rating->tb_sao ?? 0); $i++)
                                            <i class="icon-rating fa-solid fa-star"></i>    
                                        @endfor
                                        @for ($i = 0; $i < (5 - ($rating->tb_sao ?? 0)); $i++)
                                            <i class="icon-rating-none fa-solid fa-star"></i>    
                                        @endfor                                       
                                    </div>
                                    @if ($rating->dem)
                                        <span class="product-review">{{ $rating->dem }}</span>      
                                    @else
                                        <span class="product-review">Chưa đánh giá</span>      
                                    @endif
                                </div>
                                <div class="product-cart">
                                    <div class="product-price">
                                        <p class="old-price"><del>3.200.000</del> đ</p>
                                        <p class="new-price">2.850.000₫</p>
                                    </div>
                                    @if ($product->tonkho == 0)
                                        <button type="submit" class="product-cart__link">
                                            <i class="product-cart__icon fa-solid fa-cart-shopping"></i>
                                        </button>
                                    @else
                                        <form action="{{ route('cart.add') }}" method="POST">
                                            @csrf
                                            <input type="hidden" name="id" value="{{ $product->id }}">
                                            <input type="hidden" name="quantity" value="1">
                                            <button type="submit" class="product-cart__link">
                                                <i class="product-cart__icon fa-solid fa-cart-shopping"></i>
                                            </button>
                                        </form>
                                    @endif                                       
                                </div>

                                <div class="product-status">
                                    @if ($product->tonkho == 0)
                                        <svg xmlns="http://www.w3.org/2000/svg" width="15" height="16" viewBox="0 0 15 16" fill="none">
                                            <path d="M14.1358 3.43605L8.57846 0.28359C7.91183 -0.0945299 7.08783 -0.0945299 6.42121 0.28359L0.864174 3.43605C0.686049 3.53698 0.687054 3.78823 0.866183 3.88791L7.5 7.57974L14.1342 3.88791C14.3133 3.78823 14.3143 3.53729 14.1358 3.43605ZM14.5992 4.83071L8.03571 8.48316V15.4774C8.03571 15.8799 8.48404 16.1309 8.84096 15.9284L13.9356 13.0384C14.5945 12.6647 15 11.9778 15 11.2353V5.05727C15 4.85696 14.7777 4.73134 14.5992 4.83071ZM0 5.05727V11.2353C0 11.9781 0.405469 12.6647 1.0644 13.0384L6.15904 15.9281C6.51629 16.1306 6.96429 15.8799 6.96429 15.4771V8.48316L0.400781 4.83071C0.222321 4.73134 0 4.85696 0 5.05727Z" fill="#099268"/>
                                        </svg>
                                        <span class="item-ofstock">Hết hàng</span>
                                    @else
                                        <svg xmlns="http://www.w3.org/2000/svg" width="15" height="16" viewBox="0 0 15 16" fill="none">
                                            <path d="M14.1358 3.43605L8.57846 0.28359C7.91183 -0.0945299 7.08783 -0.0945299 6.42121 0.28359L0.864174 3.43605C0.686049 3.53698 0.687054 3.78823 0.866183 3.88791L7.5 7.57974L14.1342 3.88791C14.3133 3.78823 14.3143 3.53729 14.1358 3.43605ZM14.5992 4.83071L8.03571 8.48316V15.4774C8.03571 15.8799 8.48404 16.1309 8.84096 15.9284L13.9356 13.0384C14.5945 12.6647 15 11.9778 15 11.2353V5.05727C15 4.85696 14.7777 4.73134 14.5992 4.83071ZM0 5.05727V11.2353C0 11.9781 0.405469 12.6647 1.0644 13.0384L6.15904 15.9281C6.51629 16.1306 6.96429 15.8799 6.96429 15.4771V8.48316L0.400781 4.83071C0.222321 4.73134 0 4.85696 0 5.05727Z" fill="#099268"/>
                                        </svg>
                                        <span class="product-stock">Còn hàng</span>
                                    @endif
                                </div>
                            </div>
                        </div>
                    </div>
                @endforeach
            </div>
    </section>

    {{-- Banner 3 --}}
    <section class="banner">
        <div class="grid container">
            <div class="row">
                <div class="col l-12 m-12 c-12">
                    <a class="banner__link" href="#">
                        <img class="banner__link-img" src="{{asset('/img/banner9.webp')}}" alt="">
                    </a>
                </div>
            </div>
        </div>
    </section>    

    {{-- Danh mục --}}
    <section class="category">
        <div class="grid container">
            <div class="section-category__head">
                <h3 class="section-category__title">Danh mục có nhiều sản phẩm</h3>
                <a href="{{ route('product') }}" class="section-category__link">
                    Xem tất cả
                    <i class="section-category__icon fa-solid fa-arrow-right"></i>
                </a>
            </div>
            <div class="category-list">
                <div class="row">
                    @foreach ($topCategory as $category)
                        <div class="col l-2 m-4 c-6 p-none">
                            <div class="category-item ">
                                <a class="category-item__link">
                                    <img src="{{asset('img/sanpham/'.$category->hinh)}}" class="category-item__img" alt="Kính thiên văn">
                                </a>
                                <div class="category-content">
                                    <a href="/category/{{$category->slug}}" class="category-title">{{ $category->tendm }}</a>
                                    <span class="counter">
                                        {{ $category->product_count }} sản phẩm
                                    </span>
                                </div>
                            </div>
                        </div>
                    @endforeach
                    
                </div>
            </div>
        </div>
    </section>

    {{-- Comment --}}
    <section class="customer">
        <div class="grid container">
            <div class="row">
                <div class="col l-12 m-12 c-12">
                    <div class="customer-head">
                        <h3 class="customer-title">Nhận Xét Của Khách Hàng</h3>
                        <p class="customer-desc hide-on-mobile hide-on-table">
                            Kính thiên văn sắc nét, dễ sử dụng. 
                            Giao hàng nhanh, đóng gói cẩn thận. 
                            Dịch vụ tư vấn nhiệt tình, rất hài lòng. Sẽ ủng hộ TechView lâu dài!
                        </p>
                    </div>
                </div>
            </div>
            <div class="customer-list">
                <div class="row">
                    <div class="col l-4 m-4 c-12">
                        <div class="customer-item">
                            <div class="customer-avatar">
                                <img src="{{asset('img/avatar1.jpg')}}" alt="" class="customer-avatar__img">
                            </div>
                            <div class="customer-content">
                                <div class="customer-content__stars">
                                    <i class="customer-rating__icon fa-solid fa-star"></i>
                                    <i class="customer-rating__icon fa-solid fa-star"></i>
                                    <i class="customer-rating__icon fa-solid fa-star"></i>
                                    <i class="customer-rating__icon fa-solid fa-star"></i>
                                    <i class="customer-rating__icon fa-solid fa-star"></i> 
                                </div>
                                <div class="customer-name">Nguyễn Long Tuấn Kiệt</div>
                                <div class="customer-mission">Quản trị nhà hàng</div>
                                <div class="customer-description">
                                    <p>Sản phẩm tuyệt vời! Hình ảnh sắc nét, dễ sử dụng, rất phù hợp cho người mới bắt đầu quan sát thiên văn</p>
                                </div>
                            </div>
                        </div>
                    </div>
                    <div class="col l-4 m-4 c-12">
                        <div class="customer-item">
                            <div class="customer-avatar">
                                <img src="{{asset('img/avatar2.jpg')}}" alt="" class="customer-avatar__img">
                            </div>
                            <div class="customer-content">
                                <div class="customer-content__stars">
                                    <i class="customer-rating__icon fa-solid fa-star"></i>
                                    <i class="customer-rating__icon fa-solid fa-star"></i>
                                    <i class="customer-rating__icon fa-solid fa-star"></i>
                                    <i class="customer-rating__icon fa-solid fa-star"></i>
                                    <i class="customer-rating__icon fa-solid fa-star"></i> 
                                </div>
                                <div class="customer-name">Trần Văn Nam</div>
                                <div class="customer-mission">Quản trị nhà hàng</div>
                                <div class="customer-description">
                                    <p>Chất lượng kính rất tốt, giao hàng nhanh, đóng gói cẩn thận. Nhân viên tư vấn nhiệt tình, rất hài lòng!</p>
                                </div>
                            </div>
                        </div>
                    </div>
                    <div class="col l-4 m-4 c-12">
                        <div class="customer-item">
                            <div class="customer-avatar">
                                <img src="{{asset('img/avatar3.jpg')}}" alt="" class="customer-avatar__img">
                            </div>
                            <div class="customer-content">
                                <div class="customer-content__stars">
                                    <i class="customer-rating__icon fa-solid fa-star"></i>
                                    <i class="customer-rating__icon fa-solid fa-star"></i>
                                    <i class="customer-rating__icon fa-solid fa-star"></i>
                                    <i class="customer-rating__icon fa-solid fa-star"></i>
                                    <i class="customer-rating__icon fa-solid fa-star"></i> 
                                </div>
                                <div class="customer-name">Nguyễn Vân Anh</div>
                                <div class="customer-mission">Diễn Viên</div>
                                <div class="customer-description">
                                    <p>Giá hợp lý, kính thiên văn hoạt động tốt, nhìn rõ Mặt Trăng và các hành tinh. Sẽ ủng hộ lần sau!</p>
                                </div>
                            </div>
                        </div>
                    </div>
                    {{-- <div class="col l-4">
                        <div class="customer-item">
                            <div class="customer-avatar">
                                <img src="{{asset('img/avatar4.jpeg')}}" alt="" class="customer-avatar__img">
                            </div>
                            <div class="customer-content">
                                <div class="stars">
                                    <i class="customer-rating__icon fa-solid fa-star"></i>
                                    <i class="customer-rating__icon fa-solid fa-star"></i>
                                    <i class="customer-rating__icon fa-solid fa-star"></i>
                                    <i class="customer-rating__icon fa-solid fa-star"></i>
                                    <i class="customer-rating__icon fa-solid fa-star"></i> 
                                </div>
                                <div class="customer-name">Trịnh Trần Phương Tuấn</div>
                                <div class="customer-mission">Ca sĩ</div>
                                <div class="customer-description">
                                    <p>Giá hợp lý, kính thiên văn hoạt động tốt, nhìn rõ Mặt Trăng và các hành tinh. Sẽ ủng hộ lần sau!</p>
                                </div>
                            </div>
                        </div>
                    </div> --}}
                </div>
            </div>
        </div>
    </section>

    {{-- Mã Khuyến mãi --}}
    @if ($coupon)
        <section class="coupon">
            <div class="grid container">
                <div class="row">
                    <div class="col l-12 m-12 c-12">
                        <a class="coupon-wrapper" href="#!">
                            <div class="coupon-title mb-none mb-moblie">
                                {{ $coupon->mota }}
                            </div>
                            <div class="coupon-code__mess mb-moblie">
                                <span> {{ $coupon->makm }}</span>
                            </div>
                            <div class="coupon-desc" id="promoCode" onclick="copyPromoCode()">
                                <p>Sử dụng mã giảm giá ở trạng thái thanh toán</p>
                            </div>
                        </a>
                    </div>
                </div>
            </div>
        </section>
    @endif

    {{-- Tin tức --}}
    <section class="news">
        <div class="grid container">
            <div class="section-category__head">
                <h3 class="section-category__title">Tin tức mới nhất</h3>
                <a href="#" class="section-category__link">
                    Xem tất cả
                    <i class="section-category__icon fa-solid fa-arrow-right"></i>
                </a>
            </div>
            <div class="news-list">
                <div class="row">
                    @foreach ($blogs as $blog)
                        <div class="col l-4 m-4 c-12">
                            <div class="news-item">
                                <a class="news-item__link">
                                    <img src="{{asset('img/baiviet/'. $blog->hinh)}}" alt="" class="news-item__link-img">
                                </a>
                                <div class="news-body">
                                    <div class="news-published">{{ \Carbon\Carbon::parse($blog->created_at)->format('d-m-Y') }}</div>

                                    <a href="#!" class="news-title">{{ $blog->tieude }}</a>
                                    <div class="news-content">
                                        {{ $blog->noidung }}
                                    </div>
                                    <div class="news-meta">
                                        <div class="news-auth">
                                            <p>Được viết bởi</p>
                                            <p class="news-authby">{{ $blog->user->hoten }}</p>
                                        </div>
                                        <div class="news-comment">
                                            <p>Bình luận</p>
                                            <p class="news-count">{{ $blog->comments_count ?? 0 }}</p>
                                        </div>
                                    </div>
                                </div>
                            </div>
                        </div>
                    @endforeach
                </div>
            </div>
        </div>
    </section>
    

    <script>
         function copyPromoCode() {
            const code = document.getElementById('promoCode').textContent;
            navigator.clipboard.writeText(code).then(() => {
                alert("Mã giảm giá đã được sao chép!");
            });
        }
    </script>
@endsection