@extends('client.layout.layout')
@section('title')
    Đăng kí
@endsection

@section('body')
<section class="section-register">
    <div class="grid wide container">
        <div class="row">
            <div class="register col l-6 l-o-3 m-10 m-o-1 c-12">
                <div class="register-title">
                    <a class="login__link auth-link" href="{{ route('account.login')}}">Đăng nhập</a>
                    <a class="register__link auth-link" href="{{ route('account.register')}}">Đăng kí</a>
                </div>

                <form class="register-form" method="post">
                    @csrf
                    <div class="form-group">
                        <label class="label-reg" for="name">Họ tên<span class="required"></span>:</label>
                        <input class="input-field" type="text" name="name" id="name">
                    </div>
                    @error('name')
                        <div class="message">{{ $message }}</div>
                    @enderror

                    <div class="form-group">
                        <label class="label-reg" for="email">Email<span class="required"></span>:</label>
                        <input class="input-field" type="email" name="email" id="email">
                    </div>
                    @error('email')
                        <div class="message">{{ $message }}</div>
                    @enderror

                    <div class="form-group">
                        <label class="label-reg" for="password">Mật khẩu<span class="required"></span>:</label>
                        <div class="input-item">
                            <input class="input-field" type="password" name="password" id="password">
                            <i class="input-icon fa-regular fa-eye toggle-password" data-target="password"></i>
                        </div>
                    </div>
                    @error('password')
                        <div class="message">{{ $message }}</div>
                    @enderror
                    <div class="form-group">
                        <label class="label-reg" for="confirm_password">Nhập lại mật khẩu<span class="required"></span>:</label>
                        <div class="input-item">
                            <input class="input-field" type="password" name="confirm_password" id="confirm_password">
                            <i class="input-icon fa-regular fa-eye toggle-password" data-target="confirm_password"></i>
                        </div>
                    </div>
                    @error('confirm_password')
                        <div class="message">{{ $message }}</div>
                    @enderror

                    @if (session('error'))
                        <div class="message">
                            {{ session('error') }}
                        </div>
                    @elseif (session('success')) 
                        <div class="success">
                            {{ session('success') }}
                        </div>
                    @endif
                    
                    <button type="submit" class="btn-reg">ĐĂNG KÍ</button>
                </form>
            </div>
        </div>
    </div>
</section>
@endsection