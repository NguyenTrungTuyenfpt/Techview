@extends('client.layout.layout')
@section('title')
    Trạng thái thanh toán
@endsection

@section('body')
    <div class="success-content">
        <i class="fa-solid fa-triangle-exclamation icon-pay-fail"></i>
        <h2 class="btn-pay-title">Thanh toán thất bại</h2>
        <p class="btn-pay-desc-err">Vui lòng kiểm tra lại thông tin thanh toán của bạn và thử lại.</p>
        <div class="btn-pay-success">
            <a href="{{ route('checkout') }}" class="btn-pay-success__link">Thử thanh toán lại</a>
        </div>
    </div>
@endsection