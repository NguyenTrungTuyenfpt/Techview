@extends('client.layout.layout')
@section('title')
    Trạng thái thanh toán
@endsection

@section('body')
    <div class="success-content">
        <i class="fa-solid fa-exclamation icon-pay-error"></i>
        <h2 class="btn-pay-title">Đã xảy ra lỗi</h2>
        <p class="btn-pay-desc-err">Vui lòng kiểm tra lại thông tin thẻ hoặc phương thức thanh toán của bạn và thử lại.</p>
        <div class="btn-pay-success">
            <a href="{{ route('index') }}" class="btn-pay-success__link">Quay lại trang chủ</a>
        </div>
    </div>
@endsection