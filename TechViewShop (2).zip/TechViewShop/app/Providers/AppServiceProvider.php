<?php

namespace App\Providers;

use App\Models\Cart;
use App\Models\Category;
use App\Models\Favorite;
use App\Models\Product;
use Illuminate\Support\ServiceProvider;
use Illuminate\Pagination\Paginator;
use Illuminate\Support\Facades\Auth;
use Illuminate\Support\Facades\DB;

class AppServiceProvider extends ServiceProvider
{
    /**
     * Register any application services.
     */
    public function register(): void
    {
        //
    }

    public function boot(): void
    {
        Paginator::useBootstrap();
        view()->composer('*', function($view) {
            $view->with([
                'categoryList' => Category::whereNull('id_danhmuc_cha')->with('children')->get(),
                'categoryFooter' => Category::whereNull('id_danhmuc_cha')->get()->chunk(5),
                'favoriteCount' => Favorite::where('id_user', Auth::id())->count(),
                'cartCount' => Cart::where('id_user', Auth::id())->count(),
                'cartTotal' => DB::table('giohang')
                        ->join('sanpham', 'giohang.id_sanpham', '=', 'sanpham.id')
                        ->where('giohang.id_user', Auth::id())
                        ->select(DB::raw('SUM((sanpham.gia * (1 - sanpham.giamgia / 100)) * giohang.soluong) as total'))
                        ->value('total'),
                'cartCountSession' => count(session('cart', [])),
                'cartTotalSession' => session('cartTotal', 0),
                'favoriteCountSession' => count(session('favorite', [])),
            ]);
        });
    }
}
