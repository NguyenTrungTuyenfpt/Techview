<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Factories\HasFactory;
use Illuminate\Database\Eloquent\Model;

class Blog extends Model
{
    use HasFactory;
    protected $table = 'baiviet';
    protected $fillable = ['tieude', 'noidung', 'hinh', 'anhien', 'id_danhmuc', 'id_user'];
    public $timestamps = true;
    
    public function user() {
        return $this->belongsTo(User::class, 'id_user');
    }

    public function comments() {
        return $this->hasMany(CommentBlog::class, 'id_baiviet');
    }
}
