<?php

namespace App\Models\Models_2;

use Illuminate\Database\Eloquent\Factories\HasFactory;
use Illuminate\Database\Eloquent\Model;

class KhuyenMai extends Model
{
    protected $table = 'khuyenmai';
    protected $fillable = [
        'makm',
        'mota',
        'ngaybatdau',
        'ngayketthuc',
        'hesogiamgia',
        'sotientoithieu',
        'sotiengiamtoida',
        'gioihan',
        'dasudung',
        'id_user',
    ];

    public $timestamps = true;

    public function nguoiTao() {
        return $this->belongsTo(User::class, 'id_user');
    }
    
}
