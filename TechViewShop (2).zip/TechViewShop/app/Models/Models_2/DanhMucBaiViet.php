<?php

namespace App\Models\Models_2;

use Illuminate\Database\Eloquent\Factories\HasFactory;
use Illuminate\Database\Eloquent\Model;

class DanhMucBaiViet extends Model
{
    use HasFactory;
    protected $table = 'danhmucbaiviet';
    protected $fillable = [
        'tendm',
        'mota',
        'hinh',
        'thutu',
        'anhien',
        'id_user',
    ];

    public function nguoiTao() {
        return $this->belongsTo(User::class, 'id_user');
    }
    

    public function baiViets() {
        return $this->hasMany(BaiViet::class, 'id_danhmucbaiviet');
    }
    
}
