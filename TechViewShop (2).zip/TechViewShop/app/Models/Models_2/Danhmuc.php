<?php

namespace App\Models\Models_2;

use Illuminate\Database\Eloquent\Factories\HasFactory;
use Illuminate\Database\Eloquent\Model;

class Danhmuc extends Model
{
    use HasFactory; 

    protected $table = 'danhmuc';
    protected $fillable = ['tendm','slug','mota','hinh', 'thutu', 'anhien','id_danhmuc_cha','id_user'];
    public $timestamps = true;

    public function sanphams()
    {
        return $this->hasMany(SanPham::class, 'id_danhmuc');
    }

  // Quan hệ danh mục con
    public function danhmuccon()
    {
        return $this->hasMany(Danhmuc::class, 'id_danhmuc_cha');
    }

     // Quan hệ danh mục cha
     public function danhmuccha()
     {
         return $this->belongsTo(Danhmuc::class, 'id_danhmuc_cha');
     }

     public function nguoiTao() {
        return $this->belongsTo(User::class, 'id_user');
    }

}
