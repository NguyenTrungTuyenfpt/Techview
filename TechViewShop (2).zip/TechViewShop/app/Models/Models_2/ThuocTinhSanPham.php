<?php

namespace App\Models\Models_2;

use Illuminate\Database\Eloquent\Factories\HasFactory;
use Illuminate\Database\Eloquent\Model;

class ThuocTinhSanPham extends Model
{
    protected $table = 'thuoctinhsanpham';

    protected $fillable = [
        'tenthuoctinh',
        'giatri',
        'id_sanpham',
        'id_user',
    ];

    /**
     * Quan hệ: Một thuộc tính thuộc về một sản phẩm
     */
    public function sanpham()
    {
        return $this->belongsTo(SanPham::class, 'id_sanpham');
    }
    public function nguoiTao() {
        return $this->belongsTo(User::class, 'id_user');
    }

}
