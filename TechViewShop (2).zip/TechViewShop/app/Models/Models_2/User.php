<?php

namespace App\Models\Models_2;

// use Illuminate\Contracts\Auth\MustVerifyEmail;
use Illuminate\Database\Eloquent\Factories\HasFactory;
use Illuminate\Foundation\Auth\User as Authenticatable;
use Illuminate\Notifications\Notifiable;

use Laravel\Sanctum\HasApiTokens;

class User extends Authenticatable
{
    use HasApiTokens, HasFactory, Notifiable;


    protected $fillable = [
        'hoten',
        'sodienthoai',
        'email',
        'vaitro',
        'matkhau',
        'diachi',
        'gioitinh',
        'ngaysinh',
        'trangthai',
        'google_id',
        'remember_token',
        'email_verified_at'
    ];


    protected $hidden = [
        'matkhau',
        'vaitro',
        'phanquyen',
        'google_id',
        'remember_token',
        'email_verified_at',
        'created_at',
        'updated_at'
    ];


    protected $casts = [
        'email_verified_at' => 'datetime',
    ];


    // Quan hệ: User có nhiều đơn hàng
    public function donHangs()
    {
        return $this->hasMany(DonHang::class, 'id_user');
    }

    public function danhGias()
    {
        return $this->hasMany(DanhGiaSanPham::class, 'id_user');
    }

    // Trong model User.php
    public function sanPhamTao()
    {
        return $this->hasMany(SanPham::class, 'id_user');
    }

    public function danhMucTao()
    {
        return $this->hasMany(Danhmuc::class, 'id_user');
    }

    public function bannerTao()
    {
        return $this->hasMany(Banner::class, 'id_user');
    }

    
    public function baiVietTao()
    {
        return $this->hasMany(BaiViet::class, 'id_user');
    }


    public function danhMucBaiVietTao()
    {
        return $this->hasMany(DanhMucBaiViet::class, 'id_user');
    }


    public function hinhAnhSanPhamTao()
    {
        return $this->hasMany(HinhAnhSanPham::class, 'id_user');
    }

   
    public function khuyenMaiTao()
    {
        return $this->hasMany(KhuyenMai::class, 'id_user');
    }


    public function nhaCungCapTao()
    {
        return $this->hasMany(NhaCungCap::class, 'id_user');
    }

   
    public function thuocTinhSanPhamTao()
    {
        return $this->hasMany(ThuocTinhSanPham::class, 'id_user');
    }

   

}
