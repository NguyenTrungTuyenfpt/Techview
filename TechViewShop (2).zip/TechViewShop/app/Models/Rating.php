<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Factories\HasFactory;
use Illuminate\Database\Eloquent\Model;

class Rating extends Model
{
    use HasFactory;
    protected $table = 'danhgiasanpham';
    protected $fillable = [
        'danhgia',
        'noidung',
        'anhien',
        'ngaytao',
        'id_user',
        'id_sanpham'
    ];

    public function getAverageRating() {
        return $this->danhgiasp()->avg('danhgia') ?? 0;
    }

    public function user() {
        return $this->belongsTo(User::class, 'id_user');
    }

    public function product() {
        return $this->belongsTo(Product::class, 'id_sanpham');
    }
}
