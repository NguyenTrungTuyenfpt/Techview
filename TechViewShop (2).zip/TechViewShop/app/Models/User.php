<?php

namespace App\Models;

// use Illuminate\Contracts\Auth\MustVerifyEmail;
use Illuminate\Database\Eloquent\Factories\HasFactory;
use Illuminate\Foundation\Auth\User as Authenticatable;
use Illuminate\Notifications\Notifiable;
use Laravel\Sanctum\HasApiTokens;

class User extends Authenticatable
{
    use HasApiTokens, HasFactory, Notifiable;
    protected $table = 'users';
    protected $fillable = [
        'hoten',
        'sodienthoai',
        'email',
        'matkhau',
        'diachi',
        'hinh',
        'gioitinh',
        'ngaysinh',
        'google_id',
        'remember_token',
        'email_verified_at'
    ];

    public function giohang() {
        return $this->hasMany(Cart::class, 'id_user');
    }
    public function blogs() {
        return $this->hasMany(Blog::class, 'id_user');
    }

    public function comments() {
        return $this->hasMany(CommentBlog::class, 'id_user');
    }

    protected $hidden = [
        'matkhau',
        'vaitro',
        'google_id',
        'remember_token',
        'email_verified_at',
        'create_at',
        'update_at'
    ];


    protected $casts = [
        'email_verified_at' => 'datetime',
    ];


  
}
