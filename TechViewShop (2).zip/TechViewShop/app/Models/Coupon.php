<?php

namespace App\Models;

use Carbon\Carbon;
use Illuminate\Database\Eloquent\Factories\HasFactory;
use Illuminate\Database\Eloquent\Model;

class Coupon extends Model
{
    use HasFactory;
    protected $table = 'khuyenmai';

    protected $fillable = [
        'makm',
        'mota',
        'hesogiamgia',
        'sotientoithieu',
        'sotiengiamtoida',
        'ngaybatdau',
        'ngayketthuc',
        'gioihan',
        'dasudung',
    ];
    public function orders()
    {
        return $this->hasMany(Order::class, 'id_khuyenmai', 'id');
    }
   // Tính thời gian đếm ngược từ ngày bắt đầu đến ngày kết thúc
   public function getCountdown()
   {
        $now = Carbon::now();
        $endTime = Carbon::parse($this->ngayketthuc);

        if ($now >= $endTime) {
            return null;
        }
        $remainingSeconds = $endTime->diffInSeconds($now);

        $hours = floor($remainingSeconds / 3600);
        $minutes = floor(($remainingSeconds % 3600) / 60);
        $seconds = $remainingSeconds % 60;

        return [
            'hours' => str_pad($hours, 2, '0', STR_PAD_LEFT),
            'minutes' => str_pad($minutes, 2, '0', STR_PAD_LEFT),
            'seconds' => str_pad($seconds, 2, '0', STR_PAD_LEFT),
            'end_time' => $endTime->timestamp * 1000 // Timestamp để dùng trong JavaScript
        ];
   }
}
