<?php

namespace App\Listeners;

use Illuminate\Auth\Events\Login;
use App\Models\Cart;
use App\Models\Product;
use Illuminate\Contracts\Queue\ShouldQueue;
use Illuminate\Queue\InteractsWithQueue;
use Illuminate\Support\Facades\Session;

class MergeCartAfterLogin
{
    /**
     * Create the event listener.
     */
    public function __construct()
    {
        //
    }
    /**
     * Handle the event.
     */
    public function handle(Login $event): void
    {
        // Lấy thông tin người dùng đăng nhập
        $user = $event->user;

        // Lấy giỏ hàng từ session
        $sessionCart = Session::get('cart', []);

        // Lấy giỏ hàng trong database của user
        $dbCart = Cart::where('id_user', $user->id)->get()->keyBy('id_sanpham');

        foreach ($sessionCart as $item) {
            $cart = $dbCart->get($item['id']);

            if ($cart) {
                // Nếu sản phẩm đã có, cộng dồn số lượng
                $cart->soluong += $item['quantity'];
                $cart->save();
            } else {
                // Nếu chưa có, thêm sản phẩm mới vào database
                Cart::create([
                    'gia' => Product::find($item['id'])->gia ?? 0,
                    'soluong' => $item['quantity'],
                    'id_user' => $user->id,
                    'id_sanpham' => $item['id']
                ]);
            }
        }

        // Xóa giỏ hàng session sau khi merge
        Session::forget('cart');
    }
}
