<?php

namespace App\Listeners;

use Illuminate\Auth\Events\Login;
use App\Models\Favorite;
use App\Models\Product;
use Carbon\Carbon;
use Illuminate\Support\Facades\Session;

class MergeFavoriteAfterLogin
{
    /**
     * Create the event listener.
     */
    public function __construct()
    {
        //
    }
    /**
     * Handle the event.
     */
    public function handle(Login $event): void
    {
        // Lấy thông tin người dùng đăng nhập
        $user = $event->user;

        // Lấy giỏ hàng từ session
        $sessionFavorite = Session::get('favorite', []);
        foreach ($sessionFavorite as $item) {
            $product = Product::find($item['id']);
            if ($product ) {
                Favorite::firstOrCreate(
                    ['id_user' => $user->id, 'id_sanpham' => $item['id']], // Điều kiện tìm kiếm
                    ['gia' => $product->gia, 'ngaythem' => Carbon::now()] // Dữ liệu cần thêm vào nếu không tìm thấy
                );
            }
        }
        // Xóa giỏ hàng session sau khi merge
        Session::forget('favorite');
    }
}
