<?php

namespace App\Http\Middleware;

use Closure;
use Illuminate\Http\Request;
use Illuminate\Support\Facades\Auth;

class CheckQuyenHan
{
    public function handle(Request $request, Closure $next, $permission)
    {
        // Kiểm tra người dùng đã đăng nhập
        if (!Auth::check()) {
            return redirect()->route('auth.login')->with('error', 'Vui lòng đăng nhập để tiếp tục.');
        }

        // Lấy thông tin người dùng đã đăng nhập
        $user = Auth::user();

        // Kiểm tra phân quyền
        if ($user->phanquyen != $permission) {
            return redirect()->back()->with('error', 'Bạn không có quyền truy cập chức năng này.');
        }

        return $next($request);
    }
}