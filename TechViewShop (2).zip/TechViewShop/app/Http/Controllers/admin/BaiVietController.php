<?php

namespace App\Http\Controllers\Admin;

use App\Http\Controllers\Controller;
use Illuminate\Http\Request;
use App\Models\Models_2\BaiViet;
use App\Models\Models_2\DanhMucBaiViet;
use Illuminate\Support\Facades\Auth;

class BaiVietController extends Controller
{
    public function __construct()
    {
        $this->middleware('auth');
    }
    public function index(Request $request)
    {
        $query = BaiViet::with('danhMucBaiViet');

        if ($request->has('search') && $request->search) {
            $query->where('tieude', 'like', '%' . $request->search . '%');
        }
        $sort = $request->get('sort', 'id');
        $direction = $request->get('direction', 'asc');
        $query->orderBy($sort, $direction);
        $baiViets = $query->paginate(10);
        return view('admin.baiviet.baiviet', compact('baiViets'));
    }

    public function create()
    {
        $danhMucs = DanhMucBaiViet::where('anhien', 1)->get();
        return view('admin.baiviet.them', compact('danhMucs'));
    }

    public function store(Request $request)
{
    $request->validate([
        'tieude' => 'required|string|max:255',
        'noidung' => 'nullable|string',
        'hinh' => 'nullable|image|mimes:jpg,jpeg,png,gif|max:2048',
        'id_danhmuc' => 'required|exists:danhmucbaiviet,id',
        'anhien' => 'boolean',
    ]);

    $data = [
        'tieude' => $request->tieude,
        'noidung' => $request->noidung,
        'id_danhmucbaiviet' => $request->id_danhmuc,
        'anhien' => $request->has('anhien') ? 1 : 0,
        'id_user' => Auth::id(),
    ];

    // Xử lý ảnh
    if ($request->hasFile('hinh')) {
        $file = $request->file('hinh');
        $filename = time() . '_' . uniqid() . '.' . $file->getClientOriginalExtension();
        $file->move(public_path('uploads/baiviet'), $filename);
        $data['hinh'] = $filename;
    }

    BaiViet::create($data);
    return redirect()->route('baiviet')->with('message', 'Thêm bài viết thành công!');
}


    public function edit($id)
    {
        $baiViet = BaiViet::findOrFail($id);
        $danhMucs = DanhMucBaiViet::where('anhien', 1)->get();
        return view('admin.baiviet.sua', compact('baiViet', 'danhMucs'));
    }

    public function update(Request $request, $id)
    {
        $baiViet = BaiViet::findOrFail($id);

        $request->validate([
            'tieude' => 'required|string|max:255',
            'noidung' => 'nullable|string',
            // 'hinh' => 'nullable|image|mimes:jpg,jpeg,png,gif|max:2048',
            'id_danhmuc' => 'required|exists:danhmucbaiviet,id',
            'anhien' => 'boolean',
        ]);
        // // Xử lý ảnh
        // if ($request->hasFile('hinh')) {
        //     // Xóa ảnh cũ nếu tồn tại
        //     if ($baiViet->hinh && file_exists(public_path('uploads/baiviet/' . $baiViet->hinh))) {
        //         unlink(public_path('uploads/baiviet/' . $baiViet->hinh));
        //     }

        //     // Lưu ảnh mới
        //     $file = $request->file('hinh');
        //     $filename = time() . '_' . uniqid() . '.' . $file->getClientOriginalExtension();
        //     $file->move(public_path('uploads/baiviet'), $filename);
        //     $data['hinh'] = $filename;
        // }


        $data = [
            'tieude' => $request->tieude,
            'noidung' => $request->noidung,
            'id_danhmucbaiviet' => $request->id_danhmuc,
            'anhien' => $request->has('anhien') ? 1 : 0,
        ];

        $baiViet->update($data);
        return redirect()->route('baiviet')->with('message', 'Cập nhật bài viết thành công!');
    }

    public function destroy($id)
    {
        $baiViet = BaiViet::findOrFail($id);
        $baiViet->delete();
        return redirect()->route('baiviet')->with('message', 'Xóa bài viết thành công!');
    }
}
