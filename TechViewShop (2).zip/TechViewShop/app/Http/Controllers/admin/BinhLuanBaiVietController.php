<?php

namespace App\Http\Controllers\admin;

use App\Http\Controllers\Controller;
use Illuminate\Http\Request;
use Illuminate\Support\Facades\Auth;
use App\Models\Models_2\BinhLuanBaiViet;
use App\Models\Models_2\BaiViet;
use Carbon\Carbon;

class BinhLuanBaiVietController extends Controller
{



    public function binhluan(Request $request)
    {
      
        $search = $request->get('search', '');

      
        $binhluans = BinhLuanBaiViet::with(['baiviet', 'user'])  
            ->when($search, function ($query) use ($search) {
                return $query->where('noidung', 'like', "%{$search}%")
                    ->orWhereHas('baiviet', function ($query) use ($search) {
                        $query->where('noidung', 'like', "%{$search}%");
                    });
            })
            ->orderBy('created_at', 'desc')
            ->paginate(10);  


        return view('admin.binhluanbaiviet.binhluan', compact('binhluans', 'search'));
    }

    public function anhien($id){
        $binhluan = BinhLuanBaiViet::find($id);
        if (!$binhluan) {
            return response()->json(['message' => 'Bình luận không tồn tại.'], 404);
        }

        $binhluan->anhien =!$binhluan->anhien;
        $binhluan->save();

        return redirect()->back()->with('popup', true)->with('message', 'Đã ẩn bình luận');
    }




    // API
    







    // Hiển thị tất cả bình luận của bài viết
    public function index($postId)
    {
        $post = BaiViet::find($postId);
        if (!$post) {
            return response()->json(['message' => 'Bài viết không tồn tại.'], 404);
        }

        $comments = BinhLuanBaiviet::where('id_baiviet', $postId)
            ->whereNull('id_binhluan') // Chỉ lấy bình luận gốc (không phải phản hồi)
            ->with('replies.user') // Lấy luôn phản hồi của bình luận
            ->orderBy('created_at', 'desc')
            ->get();
        //    return response()->json($comments);

        return response()->json([
            'message' => 'Danh sách bình luận',
            'data' => $comments
        ]);
    }

    //  Thêm bình luận hoặc phản hồi
    public function store(Request $request, $postId)
    {
        $request->validate([
            'noidung' => 'required|string|min:3',
            'id_binhluan' => 'nullable|exists:binhluanbaiviet,id' // Đảm bảo id_binhluan hợp lệ nếu có
        ]);

        // Kiểm tra xem bài viết có tồn tại không
        $post = BaiViet::find($postId);
        if (!$post) {
            return response()->json(['message' => 'Bài viết không tồn tại.'], 404);
        }

        if ($request->id_binhluan) {
            $parentComment = BinhLuanBaiviet::find($request->id_binhluan);
            if (!$parentComment || $parentComment->id_baiviet !== $postId) {
                return response()->json(['message' => 'Bình luận cha không hợp lệ.'], 400);
            }
        }



        $comment = BinhLuanBaiviet::create([
            'id_user' => Auth::id(),
            'id_baiviet' => $postId,
            'noidung' => $request->noidung,
            'id_binhluan' => $request->id_binhluan // Nếu có id_binhluan thì là phản hồi
        ]);

        return response()->json($comment, 201);
    }







    // Cập nhật bình luận
    public function update(Request $request, $commentId)
    {
        $request->validate([
            'noidung' => 'required|string|min:3',
        ]);

        if (!Auth::check()) {
            return response()->json(['message' => 'Bạn cần đăng nhập để chỉnh sửa bình luận.'], 401);
        }

        $comment = BinhLuanBaiviet::find($commentId);
        if (!$comment) {
            return response()->json(['message' => 'Bình luận không tồn tại.'], 404);
        }

        if ($comment->id_user !== Auth::id()) {
            return response()->json(['message' => 'Không có quyền sửa bình luận này.'], 403);
        }

        $comment->update([
            'noidung' => $request->noidung
        ]);

        return response()->json($comment);
    }




    //   Xóa bình luận (hoặc phản hồi)
    public function destroy($commentId)
    {

        if (!Auth::check()) {
            return response()->json(['message' => 'Bạn cần đăng nhập để xóa bình luận.'], 401);
        }

        $comment = BinhLuanBaiviet::find($commentId);
        if (!$comment) {
            return response()->json(['message' => 'Bình luận không tồn tại.'], 404);
        }

        if ($comment->id_user !== Auth::id()) {
            return response()->json(['message' => 'Không có quyền xóa bình luận này.'], 403);
        }

        $comment->delete();
        return response()->json(['message' => 'Bình luận đã bị xóa.']);
    }
}
