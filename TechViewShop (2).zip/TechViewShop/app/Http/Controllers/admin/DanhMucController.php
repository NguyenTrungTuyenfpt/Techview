<?php

namespace App\Http\Controllers\Admin;

use App\Http\Controllers\Controller;
use Illuminate\Http\Request;
use App\Models\Models_2\DanhMuc;
use App\Models\Models_2\SanPham;
use Illuminate\Support\Str;
use Illuminate\Support\Facades\DB;


class DanhMucController extends Controller
{
    public function index(Request $request)
{
    $search = $request->query('search');
    $sort = $request->query('sort', 'id'); 
    $direction = $request->query('direction', 'asc'); 
    $danhmucQuery = DanhMuc::withCount('sanphams')
        ->with('danhmuccon');

    if ($search) {
        $danhmucQuery->where('tendm', 'like', '%' . $search . '%');
    }

    switch ($sort) {
        case 'ten':
            $danhmucQuery->orderBy('tendm', $direction);
            break;
        case 'soluong':
            $danhmucQuery->orderBy('sanphams_count', $direction);
            break;
        default:
            $danhmucQuery->orderBy('id', $direction);
            break;
    }

 
    $danhmuc = $danhmucQuery->paginate(5);
    return view('admin.danhmucsp.danhmuc', compact('danhmuc', 'search', 'sort', 'direction'));
}
    public function show($id)
{
    $danhmuc = DanhMuc::with('sanphams')->find($id);
    
    if (!$danhmuc) {
        return redirect()->route('danhmuc')->with('error', 'Danh mục không tồn tại!');
    }
    
    $sanphamBanChay = SanPham::where('id_danhmuc', $id) // Lọc theo danh mục
        ->withCount(['donHangChiTiet as da_ban' => function ($query) {
            $query->select(DB::raw("SUM(soluong)"))
                  ->whereHas('donhang', function ($q) {
                      $q->whereIn('trangthai', ['hoàn thành', 'đã giao']);
                  });
        }])
        ->having('da_ban', '>', 0)
        ->orderBy('da_ban', 'desc') // Sắp xếp theo số lượng bán giảm dần
        ->limit(5) // Giới hạn số lượng sản phẩm bán chạy (ví dụ: 5)
        ->get();

    return view('admin.danhmucsp.chitietdanhmuc', compact('danhmuc', 'sanphamBanChay'));
}

    public function create()
    {
        $danhmuc = DanhMuc::orderBy('id')->get();
        return view('admin.danhmucsp.themdanhmuc', compact('danhmuc'));
    }


    public function store(Request $request) {
        $request->validate([
            'tendm' => 'required|string|max:255',
            'mota' => 'nullable|string',
            'hinh' => 'nullable|image|mimes:jpeg,png,jpg,webp|max:2048',
            'thutu' => 'nullable|integer',
            'anhien' => 'required|boolean',
            'id_danhmuc_cha' => 'nullable|integer',
        ]);


        // Xử lý ảnh 
        $hinhanh = null;
        if ($request->hasFile('hinh')) {
            $file = $request->file('hinh');
            $filename = $file->getClientOriginalName();
            $file->move(public_path('uploads/danhmuc'), $filename);
            $hinhanh = $filename;
        }
                // Tạo slug từ tên sản phẩm
                $slug = Str::slug($request->tendm, '-');


        // DanhMuc::create($request->all());

        // dd($request->all(), $slug);

        DanhMuc::create([
            'tendm' => $request->tendm,
            'mota' => $request->mota,
            'hinh' => $hinhanh, // Chỉ lưu tên file
            'thutu' => $request->thutu,
            'anhien' => $request->anhien,
            'slug' => $slug,
            'id_danhmuc_cha' => $request->id_danhmuc_cha, 
            'id_user' => auth()->id(), 
        ]);

        
        // return redirect()->back()->with('popup', true)->with('message', 'Thêm danh mục thành công!');
        return redirect()->back()
        ->with('popup', true)
        ->with('message', 'Thêm danh mục thành công!')
        ->with('route', route('danhmuc')); // Truyền route vào session
    }

    public function edit($id) {
        $danhmuc = DanhMuc::findOrFail($id);
        $danhmucAll = DanhMuc::where('id', '!=', $danhmuc->id)
        ->where(function($query) use ($danhmuc) {
            $query->where('id_danhmuc_cha', '!=', $danhmuc->id)
                  ->orWhereNull('id_danhmuc_cha');
        })
        ->get();

        // dd($danhmucAll); 
        return view('admin.danhmucsp.suadanhmuc', compact('danhmuc', 'danhmucAll'));
    }
    

    public function update(Request $request, $id) {
        // Validate input
        $request->validate([
            'tendm' => 'required|string|max:255',
            'mota' => 'nullable|string',
            'thutu' => 'nullable|integer',
            'anhien' => 'required|boolean',
            'id_danhmuc_cha' => 'nullable|integer', // Validate if parent category exists
            'hinh' => 'nullable|image|mimes:jpeg,png,jpg,webp|max:2048', // Thêm validate cho hình ảnh
        ]);
    
        // Find the category to update
        $danhmuc = DanhMuc::findOrFail($id);
    
        // Xử lý ảnh nếu có
        if ($request->hasFile('hinh')) {
            // Remove old image if exists
            if ($danhmuc->hinh) {
                unlink(public_path('uploads/danhmuc/' . $danhmuc->hinh)); // Xóa ảnh cũ
            }
    
            // Validate và xử lý ảnh
            $file = $request->file('hinh');
            $filename = $file->getClientOriginalName();
            $file->move(public_path('uploads/danhmuc'), $filename);
            $danhmuc->hinh = $filename; // Update with new image
        }
    
        // Tạo slug từ tên danh mục
        $slug = Str::slug($request->tendm, '-');
    
        // Cập nhật danh mục
        $danhmuc->update([
            'tendm' => $request->tendm,
            'mota' => $request->mota,
            'thutu' => $request->thutu,
            'anhien' => $request->anhien,
            'slug' => $slug,
            'id_danhmuc_cha' => $request->id_danhmuc_cha, // Cập nhật danh mục cha nếu có
        ]);
    
        // Return success message
        // return redirect()->back()->with('popup', true)->with('message', 'Cập nhật danh mục thành công!');
        return redirect()->back()
        ->with('popup', true)
        ->with('message', 'Cập nhật danh mục thành công!')
        ->with('route', route('danhmuc')); // Truyền route vào session
    }
    

    public function destroy($id)
{
    $danhmuc = DanhMuc::findOrFail($id);

    // Kiểm tra xem danh mục có sản phẩm không
    if ($danhmuc->sanphams()->count() > 0) {
        $danhmuc->anhien = 0;
        $danhmuc->save();
        return redirect()->route('danhmuc')->with('popup', true)->with('message', 'Danh mục có sản phẩm, không thể xóa!');
    }

    

    // Nếu không có sản phẩm, tiến hành xóa
    $danhmuc->delete();
    return redirect()->route('danhmuc')->with('success', 'Xoá danh mục thành công!');
}



}
