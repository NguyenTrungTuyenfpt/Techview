<?php

namespace App\Http\Controllers\Admin;

use App\Http\Controllers\Controller;
use Illuminate\Http\Request;
use App\Models\Models_2\DanhGiaSanPham;
use App\Models\Models_2\SanPham;
use App\Models\Models_2\DonHang;
use App\Models\Models_2\ChiTietDonHang;
use Illuminate\Support\Facades\Auth;

class DanhGiaController extends Controller
{
    public function index()
    {

        $danhgias = DanhGiaSanPham::whereNull('id_danhgia')
            ->with(['user', 'sanpham', 'phanHoi'])
            ->get();
        return view('admin.danhgiasp.danhgia', compact('danhgias'));
    }



    // Hàm admin phản hồi đánh giá
    public function phanHoi(Request $request, $id)
    {
        // Tìm đánh giá gốc
        $danhgia = DanhgiaSanpham::whereNull('id_danhgia') // Đảm bảo đây là đánh giá, không phải phản hồi
            ->findOrFail($id);

        // Kiểm tra xem đánh giá đã có phản hồi chưa
        // $existingPhanHoi = DanhgiaSanpham::where('id_danhgia', $danhgia->id)->first();
        // if ($existingPhanHoi) {
        //     return redirect()->back()->with('error', 'Đánh giá này đã có phản hồi rồi!');
        // }

        // Tạo phản hồi mới của admin
        DanhgiaSanpham::create([
            'id_user' => auth()->user()->id,
            'id_sanpham' => $danhgia->id_sanpham,
            'id_donhang' => $danhgia->id_donhang + 1, // Lấy id_donhang từ đánh giá gốc
            'danhgia' => null, // Admin không cần đánh giá sao
            'noidung' => $request->noidung, // Không validate
            'id_danhgia' => $danhgia->id, // Liên kết với đánh giá gốc
            'anhien' => 0,
        ]);

        return redirect()->back()->with('success', 'Phản hồi thành công!');
    }





    public function addDanhGia(Request $request, $id_sanpham)
    {
        // Kiểm tra dữ liệu đầu vào
        $request->validate([
            'danhgia' => 'required|integer|min:1|max:5',
            'noidung' => 'required|string|max:500',
        ]);

        $product = SanPham::findOrFail($id_sanpham);


        $userId = Auth::id();

        // Tìm đơn hàng mới nhất mà người dùng đã mua sản phẩm này
        $order = DonHang::where('id_user', $userId)
            ->whereHas('chitietdonhang', function ($query) use ($id_sanpham) {
                $query->where('id_sanpham', $id_sanpham);
            })
            // Nếu có trạng thái đơn hàng, có thể thêm điều kiện, ví dụ:
            // ->where('trangthai', 'completed')
            ->orderBy('created_at', 'desc') // Lấy đơn hàng mới nhất
            ->first();

        if (!$order) {
            return redirect()->back()->with('error', 'Bạn không thể đánh giá sản phẩm này vì chưa mua nó!');
        }

        $id_donhang = $order->id;

     
        $existingDanhgia = DanhGiaSanPham::where('id_user', $userId)
            ->where('id_sanpham', $id_sanpham)
            ->where('id_donhang', $id_donhang)
            ->whereNull('id_danhgia') // Chỉ kiểm tra đánh giá, không phải phản hồi
            ->first();

        if ($existingDanhgia) {
            return redirect()->back()->with('error', 'Bạn đã đánh giá sản phẩm này trong đơn hàng này rồi!');
        }

        // Thêm đánh giá
        DanhGiaSanPham::create([
            'id_user' => $userId,
            'id_sanpham' => $id_sanpham,
            'id_donhang' => $id_donhang,
            'danhgia' => $request->danhgia,
            'noidung' => $request->noidung,
            'anhien' => 1,
        ]);

        return redirect()->route('product.detail',$product->slug)->with('success', 'Đánh giá của bạn đã được gửi!');
    }

   
  



    // Hàm ẩn/hiện đánh giá ( admin)
    public function anhien($id)
    {
        $danhgia = DanhGiaSanPham::findOrFail($id);
        $danhgia->anhien = !$danhgia->anhien;
        $danhgia->save();

        return redirect()->back()->with('success', 'Cập nhật thành công!');
    }
}
