<?php

namespace App\Http\Controllers\Admin;

use App\Http\Controllers\Controller;
use Illuminate\Http\Request;
use App\Models\Models_2\DanhMucBaiViet;

class DanhMucBaiVietController extends Controller
{
    public function index(Request $request)
    {
        $query = DanhMucBaiViet::withCount('baiViets');

   
        if ($request->has('search') && $request->search) {
            $query->where('tendm', 'like', '%' . $request->search . '%');
        }
    
        $sort = $request->get('sort', 'id');
        $direction = $request->get('direction', 'asc');
        if ($sort === 'baiviets_count') {
            $query->orderBy('baiviets_count', $direction);
        } else {
            $query->orderBy($sort, $direction);
        }

        $danhMucBaiViets = $query->paginate(10);
        return view('admin.danhmucbaiviet.danhmucbaiviet', compact('danhMucBaiViets'));
    }

    public function create()
    {
        return view('admin.danhmucbaiviet.them');
    }

    public function store(Request $request)
    {
        $request->validate([
            'tendm' => 'required|string|max:255',
            'anhien' => 'boolean',
        ]);

        DanhMucBaiViet::create([
            'tendm' => $request->tendm,
            'anhien' => $request->has('anhien') ? 1 : 0,
            'id_user'=>auth()->id()
        ]);

        return redirect()->route('danhmucbaiviet.index')->with('message', 'Thêm danh mục bài viết thành công!');
    }

    public function show($id)
    {
        $danhMuc = DanhMucBaiViet::with('baiViets')->findOrFail($id);
        return view('admin.danhmucbaiviet.show', compact('danhMuc'));
    }

    public function edit($id)
    {
        $danhMuc = DanhMucBaiViet::findOrFail($id);
        return view('admin.danhmucbaiviet.sua', compact('danhMuc'));
    }

    public function update(Request $request, $id)
    {
        $danhMuc = DanhMucBaiViet::findOrFail($id);

        $request->validate([
            'tendm' => 'required|string|max:255',
            'anhien' => 'boolean',
        ]);

        $danhMuc->update([
            'tendm' => $request->tendm,
            'anhien' => $request->has('anhien') ? 1 : 0,
        ]);

        return redirect()->route('danhmucbaiviet.index')->with('message', 'Cập nhật danh mục bài viết thành công!');
    }

    public function destroy($id)
    {
        $danhMuc = DanhMucBaiViet::findOrFail($id);

        // Nếu có bài viết, chỉ ẩn danh mục
        if ($danhMuc->baiViets()->count() > 0) {
            $danhMuc->update(['anhien' => 0]);
            return redirect()->route('danhmucbaiviet.index')->with('message', 'Danh mục đã được ẩn do có bài viết!');
        }

        $danhMuc->delete();
        return redirect()->route('danhmucbaiviet.index')->with('message', 'Xóa danh mục bài viết thành công!');
    }
}