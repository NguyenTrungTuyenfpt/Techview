<?php

namespace App\Http\Controllers\Admin;

use App\Http\Controllers\Controller;
use Illuminate\Http\Request;
use App\Models\Models_2\KhuyenMai;

class KhuyenMaiController extends Controller
{
    public function index()
    {
        $khuyenmai = KhuyenMai::orderBy('id')->get();
        return view('admin.khuyenmai.khuyenmai', compact('khuyenmai'));
    }


    public function create()
    {
        return view('admin.khuyenmai.themkhuyenmai');
    }


    public function store(Request $request)
    {
        $request->validate([
            'makm' => 'required|string|max:255',
            'mota' => 'nullable|string',
            'ngaybatdau' => 'nullable|date|after_or_equal:today',
            'ngayketthuc' => 'nullable|date|after_or_equal:ngaybatdau',
            'hesogiamgia' => 'required|integer|min:0',
            'sotientoithieu' => 'required|numeric', 
            'sotiengiamtoida' => 'required|numeric',
            'gioihan' => 'required|integer|min:0', 

        ]);


        $ngaybatdau = $request->ngaybatdau ?? now()->toDateString();
        // Xử lý ngày kết thúc (nếu không có thì gán 7 ngày sau ngày bắt đầu)
        $ngayketthuc = $request->ngayketthuc ?? now()->addDays(7)->toDateString(); // Đây là sửa chỗ này

        //    dd($request->all());

        KhuyenMai::create([
            'makm' => $request->makm,
            'mota' => $request->mota,
            'ngaybatdau' => $ngaybatdau,
            'ngayketthuc' => $ngayketthuc,
            'hesogiamgia' => $request->hesogiamgia, //
            'sotientoithieu' => $request->sotientoithieu,
            'sotiengiamtoida' => $request->sotiengiamtoida, //
            'gioihan' => $request->gioihan, //
            'id_user' => auth()->id() //
        ]);

        return redirect()->back()->with('popup', true)->with('message', 'Thêm khuyến mãi thành công!');
    }


    public function edit($id)
    {
        $khuyenmai = khuyenmai::findOrFail($id);

        return view('admin.khuyenmai.suakhuyenmai', compact('khuyenmai'));
    }


    public function update(Request $request, $id)
    {
        $khuyenmai = khuyenmai::findOrFail($id);

        // Validate dữ liệu
        $request->validate([
            'makm' => 'required|string|max:255',
            'mota' => 'nullable|string',
            'ngaybatdau' => 'nullable|date|after_or_equal:today',
            'ngayketthuc' => 'nullable|date|after_or_equal:ngaybatdau', // ngày kết thúc phải sau hoặc bằng ngày bắt đầu
            'hesogiamgia' => 'required|integer|min:0',
            'sotientoithieu' => 'required|numeric', // Nếu là số tiền thì dùng numeric
            'sotiengiamtoida' => 'required|numeric',
            'gioihan' => 'required|integer|min:0', // Nếu là số lượng thì dùng integer
        ]);


        // Lấy dữ liệu từ request
        $data = $request->only([
            'makm', 'mota', 'ngaybatdau', 'ngayketthuc', 
            'hesogiamgia', 'sotientoithieu', 'sotiengiamtoida', 
            'gioihan'
        ]);
        
      
        
        // Cập nhật khuyenmai
        $khuyenmai->update($data);

        return redirect()->back()->with('popup', true)->with('message', 'Cập nhật khuyen mai thành công!');
    }


    public function destroy($id)
    {
        $khuyenmais = khuyenmai::findOrFail($id);
        $khuyenmais->delete();
        // return redirect()->route('danhmuc')->with('success', 'Xoá danh mục thành công!');
        return redirect()->back()->with('popup', true)->with('message', 'Xoá khuyenmai thành công!');
    }
}
