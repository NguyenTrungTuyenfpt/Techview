<?php

namespace App\Http\Controllers\Admin;

use App\Http\Controllers\Controller;
use Illuminate\Http\Request;
use App\Models\Models_2\User;
use App\Models\Models_2\DonHang;
use App\Models\Models_2\ChiTietDonHang;
use App\Models\Models_2\DanhGiaSanPham;
use Illuminate\Support\Facades\DB;
use Illuminate\Pagination\LengthAwarePaginator;
use Illuminate\Support\Facades\Hash;
use Illuminate\Support\Facades\Auth;


class UserController extends Controller
{

    public function khachhang(Request $request)
    {
        $search = $request->query('search');
        $sort = $request->query('sort', 'id');
        $direction = $request->query('direction', 'asc');
        $query = User::where('vaitro', 0)
            ->withCount('donhangs')
            ->withCount([
                'donhangs as so_don_hoanthanh' => function ($q) {
                    $q->whereIn('trangthai', ['Hoàn thành']);
                },
                'donhangs as so_don_chuathanhtoan' => function ($q) {
                    $q->where('trangthaithanhtoan', 'Chưa thanh toán');
                },
            ])
            ->withSum([
                'donhangs as tong_tien_dachi' => function ($q) {
                    $q->whereIn('trangthai', ['Hoàn thành']);
                }
            ], 'tongtien');

        if ($search) {
            $query->where(function ($q) use ($search) {
                $q->where('hoten', 'like', '%' . $search . '%')
                    ->orWhere('email', 'like', '%' . $search . '%')
                    ->orWhere('sodienthoai', 'like', '%' . $search . '%');
            });
        }

        $sortableColumns = ['hoten', 'email', 'created_at', 'so_don_hoanthanh', 'so_don_chuathanhtoan', 'tong_tien_dachi', 'id'];
        $sort = in_array($sort, $sortableColumns) ? $sort : 'id';
        $direction = in_array($direction, ['asc', 'desc']) ? $direction : 'asc';
        $query->orderBy($sort, $direction);

        // Lấy dữ liệu
        $khachhang = $query->paginate(10);
        $khachhang->appends(request()->query());

        return view('admin.users.khachhang', compact('khachhang', 'search', 'sort', 'direction'));
    }

    public function kh_show($id)
    {
        $khachhang = User::findOrFail($id);

        // Lấy danh sách đơn hàng của khách
        $donHangs = $khachhang->donHangs()->latest()->get();

        // Thống kê đơn hàng
        $tongDon = $donHangs->count();
        $donThanhToan = $donHangs->where('trangthaithanhtoan', 'đã thanh toán')->count();
        $donHuy = $donHangs->where('trangthai', 'đã hủy')->count();
        $tongTien = $donHangs->where('trangthaithanhtoan', 'đã thanh toán')->sum('tongtien');

        // Thống kê sản phẩm mua nhiều nhất
        $topSanPham = ChiTietDonHang::select(
            'id_sanpham',
            DB::raw('SUM(soluong) as tong_so_luong'),
            DB::raw('SUM(soluong * gia) as tong_tien')
        )
            ->whereIn('id_donhang', $donHangs->pluck('id')->toArray()) // Chuyển sang mảng để tránh lỗi
            ->groupBy('id_sanpham')
            ->orderByDesc('tong_so_luong')
            ->with(['sanpham' => function ($query) {
                $query->select('id', 'tensp'); // Chỉ lấy các cột cần thiết
            }])
            ->take(5)
            ->get();

        // Đánh giá sản phẩm
        $danhGias = $khachhang->danhGias()->with('sanpham')->latest()->get();
        $soDanhGia = $danhGias->count();

        return view('admin.users.chitiettaikhoan_khach', compact(
            'khachhang',
            'donHangs',
            'tongDon',
            'donThanhToan',
            'donHuy',
            'tongTien',
            'topSanPham',
            'danhGias',
            'soDanhGia'
        ));
    }

    public function kh_lock($id)
    {
        $khachhang = User::findOrFail($id);

        // Kiểm tra trạng thái và chuyển đổi giữa 0 và 1
        $khachhang->trangthai = ($khachhang->trangthai == 1) ? 0 : 1;

        $khachhang->save();

        // Cập nhật thông báo khi thay đổi trạng thái
        $message = ($khachhang->trangthai == 0)
            ? 'Đã khóa tài khoản của ' . $khachhang->hoten
            : 'Đã mở khóa tài khoản của ' . $khachhang->hoten;

        return redirect()->back()
            ->with('success', $message);
    }




    public function nhanvien()
    {
        $thanhvien = User::where('vaitro', 1)->orderBy('id')->get();
        return view('admin.users.nhanvien', compact('thanhvien'));
    }

  

    public function nv_show($id)
{
    $nhanvien = User::where('vaitro', 1)->with([
        'sanPhamTao',
        'baiVietTao',
        'danhGias',
        'danhMucTao',
        'bannerTao',
        'khuyenMaiTao',
        'nhaCungCapTao',
        'thuocTinhSanPhamTao',
        'hinhAnhSanPhamTao',
        'danhMucBaiVietTao',
    ])->findOrFail($id);

    $activities = [];

    $addActivity = function ($icon, $color, $message, $timestamp) use (&$activities) {
        $activities[] = compact('icon', 'color', 'message', 'timestamp');
    };

    // Helper xử lý ngày
    $formatDate = fn($date) => $date ? $date->format('d/m/Y') : 'Không rõ ngày';
    $getTimestamp = fn($date) => $date ? $date->timestamp : 0;

    // --- Sản phẩm ---
    foreach ($nhanvien->sanPhamTao as $sp) {
        $addActivity('bi-box-seam', 'text-success', "[{$formatDate($sp->created_at)}] Tạo sản phẩm #{$sp->tensp}", $getTimestamp($sp->created_at));
    }
   

    // --- Bài viết ---
    foreach ($nhanvien->baiVietTao as $bv) {
        $addActivity('bi-journal-text', 'text-info', "[{$formatDate($bv->created_at)}] Tạo bài viết '{$bv->tieude}'", $getTimestamp($bv->created_at));
    }
   

    // --- Đánh giá ---
    foreach ($nhanvien->danhGias as $dg) {
        $addActivity('bi-star-fill', 'text-warning', "[{$formatDate($dg->created_at)}] Trả lời đánh giá của {$dg->user->hoten}: {$dg->noidung}", $getTimestamp($dg->created_at));
    }

    // --- Danh mục ---
    foreach ($nhanvien->danhMucTao as $dm) {
        $addActivity('bi-folder-plus', 'text-success', "[{$formatDate($dm->created_at)}] Tạo danh mục '{$dm->tendm}'", $getTimestamp($dm->created_at));
    }
    

    // --- Banner ---
    foreach ($nhanvien->bannerTao as $bn) {
        $addActivity('bi-image', 'text-success', "[{$formatDate($bn->created_at)}] Tạo banner #{$bn->ten}", $getTimestamp($bn->created_at));
    }
    

    // --- Khuyến mãi ---
    foreach ($nhanvien->khuyenMaiTao as $km) {
        $addActivity('bi-gift', 'text-success', "[{$formatDate($km->created_at)}] Tạo khuyến mãi '{$km->makm}'", $getTimestamp($km->created_at));
    }
    

    // --- Nhà cung cấp ---
    foreach ($nhanvien->nhaCungCapTao as $ncc) {
        $addActivity('bi-building', 'text-success', "[{$formatDate($ncc->created_at)}] Tạo nhà cung cấp '{$ncc->tenncc}'", $getTimestamp($ncc->created_at));
    }
   

    // --- Thuộc tính sản phẩm ---
    foreach ($nhanvien->thuocTinhSanPhamTao as $tt) {
        $addActivity('bi-tag', 'text-success', "[{$formatDate($tt->created_at)}] Tạo thuộc tính: {$tt->tenthongso} - {$tt->giatrithongso} cho sản phẩm: {$tt->sanpham->tensp}", $getTimestamp($tt->created_at));
    }
    

    // --- Hình ảnh sản phẩm ---
    foreach ($nhanvien->hinhAnhSanPhamTao as $ha) {
        $addActivity('bi-camera', 'text-success', "[{$formatDate($ha->created_at)}] Thêm hình ảnh phụ sản phẩm cho sản phẩm #{$ha->sanpham->tensp}", $getTimestamp($ha->created_at));
    }
    

    // --- Danh mục bài viết ---
    foreach ($nhanvien->danhMucBaiVietTao as $dm) {
        $addActivity('bi-folder-plus', 'text-success', "[{$formatDate($dm->created_at)}] Tạo danh mục bài viết '{$dm->tendm}'", $getTimestamp($dm->created_at));
    }
    

    // Sắp xếp theo thời gian giảm dần
    usort($activities, fn($a, $b) => $b['timestamp'] - $a['timestamp']);

    // Phân trang
    $page = request()->get('page', 1);
    $perPage = 5;
    $offset = ($page - 1) * $perPage;
    $pagedData = array_slice($activities, $offset, $perPage);

    $activities = new LengthAwarePaginator(
        $pagedData,
        count($activities),
        $perPage,
        $page,
        ['path' => request()->url(), 'query' => request()->query()]
    );

    // Xoá timestamp
    foreach ($activities as &$act) {
        unset($act['timestamp']);
    }

    return view('admin.users.chitiettaikhoan_nhanvien', compact('nhanvien', 'activities'));
}


    public function nv_lock($id)
    {
        $nhanvien = User::findOrFail($id); // Tìm nhân viên theo id

        // Đổi trạng thái tài khoản (khóa/mở)
        $nhanvien->trangthai = $nhanvien->trangthai == 1 ? 0 : 1;
        $nhanvien->save(); // Lưu thay đổi

        return redirect()->back()->with('success', 'Đã cập nhật thành công.');
    }

    public function updatePhanquyen(Request $request, $id)
{
    // Lấy nhân viên cần cập nhật
    $nhanvien = User::findOrFail($id);

    // Cập nhật quyền hạn
    $nhanvien->phanquyen = $request->input('phanquyen');
    $nhanvien->save();

    // Thông báo thành công
    return redirect()->back()->with('success', 'Cập nhật quyền hạn thành công');
}

  // Hiển thị thông tin cá nhân
  public function showProfile()
  {
      $user = Auth::user();  // Lấy thông tin người dùng đang đăng nhập
      return view('admin.users.profile', compact('user'));
  }

  // Cập nhật thông tin cá nhân
  public function updateProfile(Request $request)
{
    $user = auth()->user(); // Lấy thông tin người dùng đã đăng nhập

    // Xác thực các trường dữ liệu
    $validated = $request->validate([
        'hoten' => 'nullable|string|min:2|max:100',
        // 'email' => 'nullable|email|unique:users,email,' . $user->id,
        'sodienthoai' => 'nullable|unique:users,sodienthoai,' . $user->id,
        'diachi' => 'nullable|string|max:255',
        'gioitinh' => 'nullable|in:nam,nữ,khác',
        'ngaysinh' => 'nullable|date',
        'hinh' => 'nullable|image|mimes:jpeg,png,jpg,gif,svg|max:2048', // Kiểm tra ảnh hợp lệ
        'password' => 'nullable|min:8|regex:/[A-Z]/|regex:/[a-z]/|regex:/[0-9]/|regex:/[\W]/',  // Kiểm tra mật khẩu (nếu có thay đổi)
        'confirm_password' => 'nullable|same:password',  // Kiểm tra mật khẩu xác nhận
    ]);

    // Cập nhật thông tin cá nhân, kiểm tra mỗi trường có tồn tại trong validated không
    $user->hoten = isset($validated['hoten']) ? $validated['hoten'] : $user->hoten;
    // $user->email = isset($validated['email']) ? $validated['email'] : $user->email;
    $user->sodienthoai = isset($validated['sodienthoai']) ? $validated['sodienthoai'] : $user->sodienthoai;
    $user->diachi = isset($validated['diachi']) ? $validated['diachi'] : $user->diachi;
    $user->gioitinh = isset($validated['gioitinh']) ? $validated['gioitinh'] : $user->gioitinh;
    $user->ngaysinh = isset($validated['ngaysinh']) ? $validated['ngaysinh'] : $user->ngaysinh;


        // Cập nhật mật khẩu mới
        $user->matkhau = Hash::make($validated['password']);
    // }

    // Xử lý ảnh người dùng (nếu có)
    if ($request->hasFile('hinh')) {
        // Xóa ảnh cũ nếu có
        if ($user->hinh && file_exists(public_path('uploads/users/' . $user->hinh))) {
            unlink(public_path('uploads/users/' . $user->hinh));
        }

        // Lưu ảnh mới
        $file = $request->file('hinh');
        $filename = $file->getClientOriginalName();
        $file->move(public_path('uploads/users/'), $filename);
        
        // Cập nhật tên ảnh vào cơ sở dữ liệu
        $user->hinh = $filename;
    }

    // Lưu thông tin người dùng
    $user->save();

    return back()->with('message', 'Cập nhật thông tin thành công!');
}


}
