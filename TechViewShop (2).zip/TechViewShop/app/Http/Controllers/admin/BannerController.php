<?php

namespace App\Http\Controllers\admin;

use App\Http\Controllers\Controller;
use Illuminate\Http\Request;
use App\Models\Models_2\Banner;


class BannerController extends Controller
{
   

    public function index()
{
    $banners = Banner::orderBy('id', 'desc')->paginate(5); 
    return view('admin.banner.banner', compact('banners'));
}


    public function show($id)
    {
        $banners = Banner::find($id);
    
        if (!$banners) {
            return redirect()->route('danhmuc')->with('error', 'Danh mục không tồn tại!');
        }
    
        return view('admin.banner.chitietbanner', compact('banners'));
    }


    public function create()
    {
        return view('admin.banner.thembanner');
    }


    public function store(Request $request) {
        $request->validate([
            'hinh' => 'image|mimes:jpeg,png,jpg,webp|max:2048',
            'mota' => 'nullable|string',
            'vitri' => 'nullable|string|max:50',
            'anhien' => 'required|boolean',
            'thutu' => 'required|numeric',
            'link' => 'nullable|string',
            'ten' => 'nullable|string',
        ]);

            

        

        // Xử lý ảnh 
        $hinhanh = null;
        if ($request->hasFile('hinh')) {
            $file = $request->file('hinh');
        $filename = time() . '_' . uniqid() . '.' . $file->getClientOriginalExtension();
            
            // $filename = $file->getClientOriginalName();

            $file->move(public_path('uploads/banner'), $filename);
            $hinhanh = $filename;
        }

        Banner::create([
            'hinh' => $hinhanh, // Chỉ lưu tên file
            'mota' => $request->mota,
            'vitri' => $request->vitri,
            'anhien' => $request->anhien,
            'thutu' => $request->thutu,
            'link' => $request->link,
            'ten' => $request->ten,
            'id_user' => auth()->id(),
        ]);

       
        
        return redirect()->back()->with('popup', true)->with('message', 'Thêm banner thành công!');
    }

    public function edit($id)
    {
        $banner = Banner::findOrFail($id);
       
        return view('admin.banner.suabanner', compact('banner'));
    }

    
 public function update(Request $request, $id)
{
    $banner = Banner::findOrFail($id);

    // Validate dữ liệu
    $request->validate([
        'hinh' => 'image|mimes:jpeg,png,jpg,webp|max:2048',
        'mota' => 'nullable|string',
        'vitri' => 'nullable|string|max:50',
        'anhien' => 'required|boolean',
        'thutu' => 'required|numeric',
        'link' => 'nullable|string',
        'ten' => 'nullable|string',
    ]);

    // Lấy dữ liệu từ request
    $data = $request->only(['ten', 'mota', 'link', 'vitri', 'anhien', 'thutu']);

    // Xử lý ảnh
    if ($request->hasFile('hinh')) {
        // Xóa ảnh cũ nếu tồn tại
        if ($banner->hinh && file_exists(public_path('uploads/banner/' . $banner->hinh))) {
            unlink(public_path('uploads/banner/' . $banner->hinh));
        }

        // Lưu ảnh mới
        $file = $request->file('hinh');
        $filename = $file->getClientOriginalName();
        $file->move(public_path('uploads/banner'), $filename);
        $data['hinh'] = $filename; // Cập nhật ảnh mới vào data
    }

    // Cập nhật banner
    $banner->update($data);

    return redirect()->back()->with('popup', true)->with('message', 'Cập nhật banner thành công!');
}


    public function destroy($id) {
        $banners = Banner::findOrFail($id);
        $banners->delete();
        // return redirect()->route('danhmuc')->with('success', 'Xoá danh mục thành công!');
        return redirect()->back()->with('popup', true)->with('message', 'Xoá banner thành công!');
        
    }
}
