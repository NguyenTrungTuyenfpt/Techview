<?php

namespace App\Http\Controllers\Admin;

use App\Http\Controllers\Controller;
use Illuminate\Http\Request;
use Illuminate\Support\Str;

use App\Models\Models_2\SanPham;
use App\Models\Models_2\HinhAnhSanPham;
use App\Models\Models_2\NhaCungCap;
use App\Models\Models_2\DanhMuc;
use App\Models\Models_2\DonHang;
use App\Models\Models_2\ThuocTinhSanPham;
use App\Models\Models_2\ChiTietDonHang;
use Illuminate\Support\Facades\DB;


class SanPhamController extends Controller
{
    public function index(Request $request)
    {
        $search = $request->query('search');
        $sort = $request->query('sort', 'id'); 
        $direction = $request->query('direction', 'asc'); 
        $sanphamQuery = SanPham::withCount([
            'donHangChiTiet as da_ban' => function ($query) {
                $query->select(DB::raw("SUM(soluong)"))
                    ->whereHas('donhang', function ($q) {
                        $q->whereIn('trangthai', ['hoàn thành', 'đã giao']);
                    });
            }
        ]);

        if ($search) {
            $sanphamQuery->where('tensp', 'like', '%' . $search . '%');
        }
        switch ($sort) {
            case 'ngaytao':
                $sanphamQuery->orderBy('created_at', $direction);
                break;
            case 'soluong':
                $sanphamQuery->orderBy('soluong', $direction);
                break;
            case 'daban':
                $sanphamQuery->orderBy('da_ban', $direction);
                break;
            default:
                $sanphamQuery->orderBy('id', $direction);
                break;
        }
        $sanpham = $sanphamQuery->paginate(3);
        return view('admin.sanpham.sanpham', compact('sanpham', 'search', 'sort', 'direction'));
    }




    public function show($id)
    {
        $sanpham = SanPham::with(['danhmuc', 'nhacungcap', 'anhsanpham'])
            ->withCount([
                'donHangChiTiet as da_ban' => function ($query) {
                    $query->select(DB::raw("SUM(soluong)"))
                        ->whereHas('donhang', function ($q) {
                            $q->whereIn('trangthai', ['hoàn thành', 'đã giao']);
                        });
                }
            ])
            ->findOrFail($id);

        return view('admin.sanpham.chitietsanpham', compact('sanpham'));
    }


    public function create()
    {
        $danhmuc = DanhMuc::orderBy('id')->get();
        $nhacungcap = NhaCungCap::orderBy('id')->get();

        return view('admin.sanpham.themsanpham', compact('danhmuc', 'nhacungcap'));
    }

    public function store(Request $request)
    {
        // Validate dữ liệu
        $validated = $request->validate([
            'tensp' => 'required|string|max:255',
            'thuonghieu' => 'nullable|string|max:255',
            'mota' => 'nullable|string',
            'anhchinh' => 'image|mimes:jpeg,png,jpg|max:2048',
            'gia' => 'required|numeric',
            'giamgia' => 'nullable|numeric',
            'soluong' => 'required|integer|min:0',
            'anhhien' => 'nullable|boolean',
            'noibat' => 'nullable|boolean',
            'danhmuc_id' => 'required|exists:danhmuc,id',
            'nhacungcap_id' => 'exists:nhacungcap,id',
            'anhphu.*' => 'nullable|image|mimes:jpeg,png,jpg|max:2048',
            'tenthongso' => 'nullable|string|max:255',
            'giatrithongso' => 'nullable|string'
        ]);


        // dd($validated);



        // Xử lý ảnh chính
        $hinhanhChinh = null;
        if ($request->hasFile('anhchinh')) {
            $file = $request->file('anhchinh');
            $filename = time() . '_' . uniqid() . '.' . $file->getClientOriginalExtension();
            $file->move(public_path('uploads/sanpham'), $filename);
            $hinhanhChinh = $filename;
        }

        // Tạo slug từ tên sản phẩm
        $slug = Str::slug($request->tensp, '-');

        // Tạo sản phẩm mới
        $sanpham = new SanPham();
        $sanpham->tensp = $request->tensp;
        $sanpham->thuonghieu = $request->thuonghieu;
        $sanpham->slug = $slug;
        $sanpham->gia = $request->gia;
        $sanpham->giamgia = $request->giamgia;
        $sanpham->mota = $request->mota;
        $sanpham->hinh = $hinhanhChinh;
        $sanpham->id_danhmuc = $request->danhmuc_id;
        $sanpham->id_nhacungcap = $request->nhacungcap_id;
        $sanpham->soluong = $request->soluong;
        $sanpham->anhien = $request->has('trangthai') ? 1 : 0;
        $sanpham->noibat = $request->has('noibat') ? 1 : 0;
        $sanpham->id_user = auth()->id();

        $sanpham->save(); // lưu trước để có ID

        // Lưu hình ảnh nếu có
        // Xử lý ảnh phụ
        if ($request->hasFile('anhphu')) {
            foreach ($request->file('anhphu') as $file) {
                $filename = time() . '_' . uniqid() . '.' . $file->getClientOriginalExtension();
                $file->move(public_path('uploads/sanpham'), $filename);

                $anh = new HinhAnhSanPham();
                $anh->sanpham_id = $sanpham->id;
                $anh->tenanh = $filename;
                $anh->id_user = auth()->id();
                $anh->save();
            }


            // lưu thuộc tính sản phẩm
            $thuoctinh = new ThuocTinhSanPham();
            $thuoctinh->id_sanpham = $sanpham->id;
            $thuoctinh->tenthongso = $request->tenthongso;
            $thuoctinh->giatrithongso = $request->giatrithongso;
            $thuoctinh->id_user = auth()->id();
            $thuoctinh->save();

            // return redirect()->back()->with('success', 'Thêm sản phẩm thành công!');
            return redirect()->back()->with('popup', true)->with('message', 'Thêm sản phẩm thành công!');
        }
    }



    public function edit($id)
    {
        $sanpham = SanPham::with('anhsanpham')->findOrFail($id);
        $danhmuc = DanhMuc::all();  // nếu có chọn danh mục
        $nhacungcap = NhaCungCap::orderBy('id')->get();
        return view('admin.sanpham.suasanpham', compact('sanpham', 'danhmuc', 'nhacungcap'));
    }


    public function update(Request $request, $id)
    {
        $sanpham = SanPham::findOrFail($id);

        // Validate đầy đủ
        $request->validate([
            'tensp' => 'required|string|max:255',
            'gia' => 'required|numeric',
            'giamgia' => 'nullable|numeric',
            'mota' => 'nullable|string',
            'id_danhmuc' => 'required|integer',
            'id_nhacungcap' => 'integer',
            'thuonghieu' => 'nullable|string|max:50',
            'soluong' => 'required|integer|min:0',
            'anhien' => 'required|boolean',
            'noibat' => 'required|boolean',
            'anhchinh' => 'nullable|image|mimes:jpeg,png,jpg,gif,webp|max:2048',
            'anhphu.*' => 'nullable|image|mimes:jpeg,png,jpg,gif,webp|max:2048',
            'giatrithongso' => 'nullable|string',
            'tenthongso' => 'nullable|string'
        ]);


        // Lấy dữ liệu
        $data = $request->only([
            'tensp',
            'gia',
            'giagiam',
            'mota',
            'id_danhmuc',
            'id_nhacungcap',
            'thuonghieu',
            'soluong',
            'anhien',
            'noibat'
        ]);

        // Tạo slug và gán vào $data
        $data['slug'] = Str::slug($request->tensp, '-');

        // Xử lý ảnh chính
        if ($request->hasFile('anhchinh')) {
            // Xóa ảnh cũ nếu có
            if ($sanpham->anhchinh && file_exists(public_path('uploads/sanpham/' . $sanpham->hinh))) {
                unlink(public_path('uploads/sanpham/' . $sanpham->hinh));
            }

            $file = $request->file('anhchinh');
            $filename = $file->getClientOriginalName();
            $file->move(public_path('uploads/sanpham/'), $filename);
            $data['hinh'] = $filename;
        }

        // Cập nhật sản phẩm
        $sanpham->update($data);

        // Xử lý ảnh phụ
        if ($request->filled('xoa_anhphu')) {
            foreach ($request->xoa_anhphu as $id_anh) {
                $anh = HinhAnhSanPham::find($id_anh);
                if ($anh && file_exists(public_path('uploads/sanpham/' . $anh->src))) {
                    unlink(public_path('uploads/sanpham/' . $anh->src));
                }
                $anh?->delete();
            }
        }

        // Thêm ảnh phụ mới
        if ($request->hasFile('anhphu')) {
            foreach ($request->file('anhphu') as $file) {
                $filename = $file->getClientOriginalName();
                $file->move(public_path('uploads/sanpham'), $filename);

                HinhAnhSanPham::create([
                    'id_sanpham' => $sanpham->id,
                    'src' => $filename,
                    'id_user' => $sanpham->id_user ?? auth()->id() // Nếu id_user chưa có thì gán giá trị của auth()->id()
                ]);
                
            }
        }

        // lưu thuộc tính sản phẩm
        $thuoctinh = new ThuocTinhSanPham();
        $thuoctinh->id_sanpham = $sanpham->id;
        $thuoctinh->tenthongso = $request->tenthongso;
        $thuoctinh->giatrithongso = $request->giatrithongso;

        // Kiểm tra nếu id_user là null thì gán giá trị auth()->id()
        if (!$thuoctinh->id_user) {
            $thuoctinh->id_user = auth()->id();
        }

        $thuoctinh->save();


        // dd($thuoctinh);


        return redirect()->back()->with('popup', true)->with('message', 'Cập nhật sản phẩm thành công!');
    }
    public function destroy($id)
    {
        $sanpham = SanPham::withCount(['donHangChiTiet as da_ban' => function ($query) {
            $query->select(DB::raw("SUM(soluong)"))
                ->whereHas('donhang', function ($q) {
                    $q->whereIn('trangthai', ['hoàn thành', 'đã giao']);
                });
        }])->find($id);

        if (!$sanpham) {
            return redirect()->back()->with('error', 'Không tìm thấy sản phẩm!');
        }

        if ($sanpham->da_ban > 0) {
            // Nếu sản phẩm đã bán -> Không xóa mà chuyển sang ẩn
            $sanpham->anhien = 0;
            $sanpham->save();

            return redirect()->route('sanpham')->with('message', 'Sản phẩm đã được bán. Đã chuyển sang trạng thái ẩn!');
        }

        // Nếu chưa bán -> tiếp tục xóa

        // Xoá ảnh phụ
        foreach ($sanpham->anhsanpham as $anh) {
            $path = public_path('uploads/sanpham/' . $anh->src);
            if (file_exists($path)) {
                unlink($path); // xoá file
            }
            $anh->delete();
        }

        // Xoá ảnh chính
        $anhchinhPath = public_path('uploads/sanpham/' . $sanpham->hinh);
        if (file_exists($anhchinhPath)) {
            unlink($anhchinhPath);
        }

        // Xoá sản phẩm
        $sanpham->delete();

        return redirect()->route('sanpham')->with('success', 'Xoá sản phẩm thành công!');
    }
}
