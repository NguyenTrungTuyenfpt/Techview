<?php

namespace App\Http\Controllers\admin;

use App\Http\Controllers\Controller;
use App\Models\Models_2\DonHang;
use App\Models\Models_2\User;
use App\Models\Models_2\SanPham;
use Illuminate\Http\Request;
use Illuminate\Support\Facades\DB;

class IndexController extends Controller
{
    public function index()
    {
        $donhangs = DonHang::where('trangthai', 'pending')
            ->orderBy('created_at', 'desc')
            ->take(5)
            ->get();
        $doanhThu = DonHang::where('trangthai', 'completed')
            ->sum('tongtien');
        $doanhThuThangTruoc = DonHang::where('trangthai', 'completed')
            ->whereMonth('created_at', now()->subMonth()->month)
            ->sum('tongtien');
        $doanhThuThangNay = DonHang::where('trangthai', 'completed')
            ->whereMonth('created_at', now()->month)
            ->sum('tongtien');
        $doanhThuTang = $doanhThuThangTruoc > 0 ? round((($doanhThuThangNay - $doanhThuThangTruoc) / $doanhThuThangTruoc) * 100, 2) : 0;
        $tongDonHang = DonHang::count();
        $donHangThangTruoc = DonHang::whereMonth('created_at', now()->subMonth()->month)
            ->count();
        $donHangThangNay = DonHang::whereMonth('created_at', now()->month)
            ->count();
        $donHangTang = $donHangThangTruoc > 0 ? round((($donHangThangNay - $donHangThangTruoc) / $donHangThangTruoc) * 100, 2) : 0;
        $luotXem = SanPham::sum('luotxem'); 
        $luotXemThangTruoc = SanPham::whereMonth('updated_at', now()->subMonth()->month)
            ->sum('luotxem');
        $luotXemThangNay = SanPham::whereMonth('updated_at', now()->month)
            ->sum('luotxem');
        $luotXemTang = $luotXemThangTruoc > 0 ? round((($luotXemThangNay - $luotXemThangTruoc) / $luotXemThangTruoc) * 100, 2) : 0;

       
        $tongKhachHang = User::count();

        
        $khachHangThangTruoc = User::whereMonth('created_at', now()->subMonth()->month)
            ->count();
        $khachHangThangNay = User::whereMonth('created_at', now()->month)
            ->count();
        $khachHangTang = $khachHangThangTruoc > 0 ? round((($khachHangThangNay - $khachHangThangTruoc) / $khachHangThangTruoc) * 100, 2) : 0;

        // Sản phẩm bán chạy (lấy 4 sản phẩm bán chạy nhất)
        $sanPhamBanChay = SanPham::select('sanpham.*')
            ->join('chitietdonhang', 'sanpham.id', '=', 'chitietdonhang.id_sanpham')
            ->join('donhang', 'chitietdonhang.id_donhang', '=', 'donhang.id')
            ->where('donhang.trangthai', 'completed')
            ->groupBy('sanpham.id', 'sanpham.tensp', 'sanpham.hinh', 'sanpham.gia')
            ->selectRaw('SUM(chitietdonhang.soluong) as soLuongBan')
            ->orderBy('soLuongBan', 'desc')
            ->take(4)
            ->get();

        return view('admin.index', compact(
            'donhangs',
            'doanhThu',
            'doanhThuTang',
            'tongDonHang',
            'donHangTang',
            'luotXem',
            'luotXemTang',
            'tongKhachHang',
            'khachHangTang',
            'sanPhamBanChay'
        ));
    }
}