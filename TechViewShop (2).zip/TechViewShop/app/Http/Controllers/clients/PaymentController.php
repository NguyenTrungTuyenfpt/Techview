<?php

namespace App\Http\Controllers\clients;

use App\Http\Controllers\Controller;
use App\Http\Requests\OrderRequest;
use App\Models\Cart;
use App\Models\Coupon;
use App\Models\Order;
use App\Models\OrderDetail;
use Illuminate\Http\Request;
use Illuminate\Support\Facades\Auth;

class PaymentController extends Controller
{
    protected $vnp_TmnCode;
    protected $vnp_HashSecret;
    protected $vnp_Url;
    protected $vnp_Returnurl;
    protected $vnp_apiUrl;
    protected $apiUrl;

    public function __construct()
    {
        date_default_timezone_set('Asia/Ho_Chi_Minh');
        $this->vnp_TmnCode = "J6J87EPC"; 
        $this->vnp_HashSecret = "LIRRAH8W04Y7OHBKGDVLLF8ABUHOGHBF"; 
        $this->vnp_Url = "https://sandbox.vnpayment.vn/paymentv2/vpcpay.html";
        $this->vnp_Returnurl = "http://127.0.0.1:8000/checkout/result";
        $this->vnp_apiUrl = "http://sandbox.vnpayment.vn/merchant_webapi/merchant.html";
        $this->apiUrl = "https://sandbox.vnpayment.vn/merchant_webapi/api/transaction";
    }
   
    public function createPay(OrderRequest $req)
    {
        $req->validated();
        $order = new Order();
     
        $couponId = session('coupon_id');
        if ($couponId) {
            $coupon = Coupon::find($couponId);
        }
        
        $order->id_user = auth()->id();
        $madonhang = strtoupper(chr(rand(65, 90)) . chr(rand(65, 90))) . rand(1000, 9999);
        $order->madonhang = $madonhang;
        $order->tongtien = $req->input('amount');
        $order->phuongthucthanhtoan = 'Thanh toán vnpay';
        $order->id_khuyenmai = isset($coupon) ? $coupon->id : null;
        $paymentMethod = $req->input('payment');
        if ($paymentMethod == 1) {
            $order->phuongthucthanhtoan = 'Chuyển khoản ngân hàng';
        } elseif ($paymentMethod == 2) {
            $order->phuongthucthanhtoan = 'Thanh toán VNPay';
        } else {
            $order->phuongthucthanhtoan = 'Tiền mặt';
        }
        // Lưu thông tin người nhận
        $order->tennguoinhan = $req->input('name');
        $order->sodienthoai = $req->input('phone');
        $order->diachi = $req->input('address');
        $order->ghichu = $req->input('description');
        $order->phuongthucthanhtoan = $paymentMethod;
        // dd($order);
        $order->save();
        $cart = Cart::where('id_user', auth()->id())->with('product')->orderBy('id', 'DESC')->get();
        $orderDetails = [];
        foreach ($cart as $item) {
            $orderDetails[] = [
                'id_donhang' => $order->id, // Lấy ID đơn hàng vừa lưu
                'id_sanpham' => $item->id_sanpham,
                'gia' => $item->gia,
                'soluong' => $item->soluong
            ];
        }
        OrderDetail::insert($orderDetails);
        // dd($orderDetails);
        $startTime = date("YmdHis");
        $expire = date('YmdHis', strtotime('+15 minutes', strtotime($startTime)));
        $vnp_TxnRef = $order->id;
        $vnp_Amount = $_POST['amount']; // Số tiền thanh toán
        $vnp_Locale = $_POST['language']; //Ngôn ngữ chuyển hướng thanh toán
        $vnp_BankCode = $_POST['bankCode']; //Mã phương thức thanh toán
        $vnp_IpAddr = $_SERVER['REMOTE_ADDR']; //IP Khách hàng thanh toán

        $inputData = array(
            "vnp_Version" => "2.1.0",
            "vnp_TmnCode" => $this->vnp_TmnCode,
            "vnp_Amount" => $vnp_Amount * 100,
            "vnp_Command" => "pay",
            "vnp_CreateDate" => date('YmdHis'),
            "vnp_CurrCode" => "VND",
            "vnp_IpAddr" => $vnp_IpAddr,
            "vnp_Locale" => $vnp_Locale,
            "vnp_OrderInfo" => "Thanh toan GD:" . $vnp_TxnRef,
            "vnp_OrderType" => "other",
            "vnp_ReturnUrl" => $this->vnp_Returnurl,
            "vnp_TxnRef" => $vnp_TxnRef,
            "vnp_ExpireDate" => $expire
        );

        if (isset($vnp_BankCode) && $vnp_BankCode != "") {
            $inputData['vnp_BankCode'] = $vnp_BankCode;
        }

        ksort($inputData);
        $query = "";
        $i = 0;
        $hashdata = "";
        foreach ($inputData as $key => $value) {
            if ($i == 1) {
                $hashdata .= '&' . urlencode($key) . "=" . urlencode($value);
            } else {
                $hashdata .= urlencode($key) . "=" . urlencode($value);
                $i = 1;
            }
            $query .= urlencode($key) . "=" . urlencode($value) . '&';
        }

        $vnp_Url = $this->vnp_Url . "?" . $query;
        if (isset($this->vnp_HashSecret)) {
            $vnpSecureHash =   hash_hmac('sha512', $hashdata, $this->vnp_HashSecret); //  
            $vnp_Url .= 'vnp_SecureHash=' . $vnpSecureHash;
        }
        header('Location: ' . $vnp_Url);
        die();
    }

    public function result()
    {
        $vnp_SecureHash = $_GET['vnp_SecureHash'];
        $inputData = array();
        foreach ($_GET as $key => $value) {
            if (substr($key, 0, 4) == "vnp_") {
                $inputData[$key] = $value;
            }
        }
        unset($inputData['vnp_SecureHash']);
        ksort($inputData);
        $i = 0;
        $hashData = "";
        foreach ($inputData as $key => $value) {
            if ($i == 1) {
                $hashData = $hashData . '&' . urlencode($key) . "=" . urlencode($value);
            } else {
                $hashData = $hashData . urlencode($key) . "=" . urlencode($value);
                $i = 1;
            }
        }
        $secureHash = hash_hmac('sha512', $hashData, $this->vnp_HashSecret);

        if ($secureHash == $vnp_SecureHash) {
            if ($_GET['vnp_ResponseCode'] == '00') {
                $orderId = $_GET['vnp_TxnRef'];
                $order = Order::find($orderId);
                $order->trangthaithanhtoan = 'Đã thanh toán';
                $order->save();
                Cart::where('id_user', auth()->id())->delete();
                return view('client.pages.payment.success');
            } else {
                return view('client.pages.payment.fail');
            }
        } else {
            return view('client.pages.payment.error');
        }
    }
}
