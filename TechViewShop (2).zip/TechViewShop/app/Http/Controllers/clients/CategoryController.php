<?php

namespace App\Http\Controllers\clients;

use App\Http\Controllers\Controller;
use App\Models\Category;
use App\Models\Product;
use Illuminate\Http\Request;

class CategoryController extends Controller
{
    public function index($slug, $parent=null) {
        if ($parent) {
            $category = Category::where('slug', $parent)->first();  
            $productList = Product::where('id_danhmuc', $category->id)->paginate(16);
            
        } else {
            $category = Category::where('slug', $slug)->first();  
            $childCategories = $category->children->pluck('id')->toArray();
            $productList = Product::whereIn('id_danhmuc', array_merge([$category->id], $childCategories))->paginate(16);
        }
       
        $data = [
            'productList' => $productList,
            'type' => 'category'
        ];
        return view('client.pages.product', $data);
    }
}
