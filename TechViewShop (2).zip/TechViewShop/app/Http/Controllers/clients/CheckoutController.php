<?php

namespace App\Http\Controllers\clients;

use App\Http\Controllers\Controller;
use App\Http\Requests\OrderRequest;
use App\Models\Cart;
use App\Models\Coupon;
use App\Models\Order;
use App\Models\OrderDetail;
use App\Models\Product;
use Illuminate\Http\Request;
use Illuminate\Support\Facades\Auth;
use Illuminate\Support\Facades\DB;
use Illuminate\Support\Facades\Session;

class CheckoutController extends Controller
{
    public function index() {
        $user= Auth::user();
        $cartList = Cart::where('id_user', auth()->id())->with('product')->orderBy('id', 'DESC')->get();        
        $total = $result = $discount = $discountAmount = $newTotal = 0;
        
        foreach ($cartList as $cart) {
            $total += $cart->product->gia * (1 - ($cart->product->giamgia/100)) * $cart->soluong;
        }
        if (session('coupon')) {
            $coupon = session('coupon');
            $discount = $coupon['hesogiamgia'];
            $discountAmount = $total * ($discount / 100);
            if ($discountAmount > $coupon['sotiengiamtoida']) {
                $discountAmount = $coupon['sotiengiamtoida'];
            }
    
            $newTotal = $total - $discountAmount + 30000;
            $couponId = $coupon['id'];
            session()->forget('coupon');
            session(['coupon_id' => $couponId]);
        } else {
            $result = $total + 30000;
        }
        $data = [
            'user' =>  $user,
            'cartList' => $cartList,
            'discount' => $discount,
            'discountAmount' => $discountAmount,
            'total' => $total,
            'newTotal' => $newTotal,
            'result' => $result
        ];
        return view('client.pages.checkout', $data);
    }
    
    public function create(OrderRequest $req) {
        // Bắt đầu giao dịch
        DB::beginTransaction();
        try {
            $req->validated();
            $order = new Order();
            // Lấy mã khuyến mãi từ form
            $couponId = session('coupon_id');
            if ($couponId) {
                $coupon = Coupon::find($couponId);
            }
            // Tìm mã khuyến mãi trong cơ sở dữ liệu
            $order->id_user = auth()->id();
            $madonhang = strtoupper(chr(rand(65, 90)) . chr(rand(65, 90))) . rand(1000, 9999);
            $order->madonhang = $madonhang;
            $order->tongtien = $req->input('amount');
            $order->phuongthucthanhtoan = 'Thanh toán vnpay';
            $order->id_khuyenmai =  isset($coupon) ? $coupon->id : null;
            $paymentMethod = $req->input('payment');
            if ($paymentMethod == 1) {
                $order->phuongthucthanhtoan = 'Chuyển khoản ngân hàng';
            } elseif ($paymentMethod == 2) {
                $order->phuongthucthanhtoan = 'Thanh toán VNPay';
            } else {
                $order->phuongthucthanhtoan = 'Tiền mặt';
            }
            // Lưu thông tin người nhận
            $order->tennguoinhan = $req->input('name');
            $order->sodienthoai = $req->input('phone');
            $order->diachi = $req->input('address');
            $order->ghichu = $req->input('description');
            $order->phuongthucthanhtoan = $paymentMethod;
            // dd($order);
            $order->save();
            $cart = Cart::where('id_user', auth()->id())->with('product')->orderBy('id', 'DESC')->get();
            $orderDetails = [];
            foreach ($cart as $item) {
                $orderDetails[] = [
                    'id_donhang' => $order->id, // Lấy ID đơn hàng vừa lưu
                    'id_sanpham' => $item->id_sanpham,
                    'gia' => $item->gia,
                    'soluong' => $item->soluong
                ];
            }
            // Cam kết giao dịch
            DB::commit();
            OrderDetail::insert($orderDetails);
            Cart::where('id_user', auth()->id())->delete();
            return redirect()->route('checkout.success');
        }catch (\Exception $e) {
                // Nếu có lỗi, hoàn tác giao dịch
                DB::rollBack();
                // Gửi thông báo lỗi
                return back()->with('message', 'Đã có lỗi xảy ra, vui lòng thử lại!');
            }
    }

    public function success() {
        return view('client.pages.payment.success');
    }
}
