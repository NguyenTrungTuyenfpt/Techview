<?php

namespace App\Http\Controllers\clients;

use App\Http\Controllers\Controller;
use App\Models\Category;
use App\Models\Product;
use App\Models\Order;
use App\Models\Models_2\DanhGiaSanPham;
use App\Models\Models_2\DonHang;
use Illuminate\Support\Facades\Auth;
use App\Traits\RatingTrait;
use Illuminate\Pagination\Paginator;
use Illuminate\Http\Request;

use Illuminate\Support\Facades\DB;

class ProductController extends Controller
{
    use RatingTrait; 
    public function index(Request $req, $slug = null){
        switch ($slug) {
            case 'hot':
                $productList = Product::where('noibat', 1)->orderBy('id', 'DESC')->paginate(16);               
                $type = 'hot';
                break;
    
            case 'sale':
                $productList = Product::where('giamgia', '>', 0)->orderBy('id', 'DESC')->paginate(16);        
                $type = 'sale';
                break;
    
            case null:
            default:
                $productList = Product::orderBy('id', 'DESC')->paginate(16);          
                $type = 'all';
                break;
        }
        
        $rating = $this->getProductRatings();
        $data = [
            'productList' => $productList,
            'rating' => $rating,
            'type' => $type
        ];
        return view('client.pages.product', $data);
    }
    
    public function detail($slug)
    {
        // Load product with required relationships
        $product = Product::with([
            'category', 
            'specs', 
            'danhGiaSanPham' => function($query) {
                $query->where('anhien', 1);  
            },
            // 'danhGiaSanPham.user', 
            'images'
        ])
        ->where('slug', $slug)
        ->firstOrFail();
    

        // Load related products with ratings
        $relatedProducts = Product::with(['category', 'danhGiaSanPham'])
            ->where('id_danhmuc', $product->id_danhmuc)
            ->where('id', '!=', $product->id)
            ->limit(5)
            ->get();

        // Calculate rating for the current product
        $rating = $this->getProductRatings($product->id);

        // Increment view count
        $product->increment('luotxem');

        // Check if the user can review the product
        $canReview = false;
        if (Auth::check()) {
            // Check if the user has purchased this product
            $order = DonHang::where('id_user', Auth::id())
                ->whereHas('chitietdonhang', function ($query) use ($product) {
                    $query->where('id_sanpham', $product->id);
                })
                ->orderBy('created_at', 'desc') // Get most recent order
                ->first();
    
            if ($order) {
                // Check if the user has already reviewed the product in the most recent order
                $existingDanhgia = DanhGiaSanPham::where('id_user', Auth::id())
                    ->where('id_sanpham', $product->id)
                    ->where('id_donhang', $order->id)  // Check review for this order
                    ->first();
    
                if (!$existingDanhgia) {
                    // If no review found, user can review the product
                    $canReview = true;
                }
            }
        }

        // Pass data to the view
        $data = [
            'product' => $product,
            'rating' => $rating,
            'relatedProducts' => $relatedProducts,
            'canReview' => $canReview,
        ];

        return view('client.pages.product-detail', $data);
    }

   




    public function search(Request $req) {
        $key = trim(strip_tags($req->input('key')));
        $productList = Product::where('tensp', 'like', '%'.$key.'%')->orderBy('id', 'DESC')->paginate(16)->appends(['key' => $key]); 
        $data = [
            'productList' => $productList,
            'key' => $key,  
            'type' => 'search'
        ];
        
        return view('client.pages.product',$data);
    }   
}
