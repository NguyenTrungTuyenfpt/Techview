<?php

namespace App\Http\Controllers\api_admin;

use App\Http\Controllers\Controller;
use Illuminate\Http\Request;
use App\Models\Models_2\User;
use Illuminate\Support\Facades\Auth;
use Illuminate\Support\Facades\Hash;
use Illuminate\Support\Str;
use Illuminate\Support\Carbon;
use Illuminate\Support\Facades\Log;
use Illuminate\Support\Facades\Password;
use Illuminate\Validation\ValidationException;
use Laravel\Socialite\Facades\Socialite;

class AuthApiController extends Controller
{
     // Đăng kí tài khoản
     public function register(Request $request) {
        try {
            $request->validate([
                'hoten' => 'required|string|max:255|unique:khachhang',
                'email' => 'required|email|unique:khachhang',
                'matkhau' => [
                    'required',
                    'min:8',
                    'regex:/[A-Z]/',
                    'regex:/[a-z]/',
                    'regex:/[0-9]/',
                    'regex:/[\W]/',
                    'confirmed'
                ]
            ]);
    
            $user = User::create([
                'hoten' => $request->hoten,
                'email' => $request->email,
                'matkhau' => Hash::make($request->matkhau),
                'remember_token' => Str::random(60),
                'email_verified_at' => Carbon::now() // Hoặc null nếu chưa xác thực email
            ]);
    
            // Gửi email xác thực
            // Mail::to($user->email)->send(new VerifyEmailMail($user));
    
            return response()->json([
                'status' => 'success',
                'message' => 'Đăng ký thành công! Kiểm tra email để xác thực tài khoản.'
            ], 201);

        } catch (\Exception $e) {
            Log::error('Lỗi đăng ký: ' . $e->getMessage());
            return response()->json([
                'status' => 'error',
                'message' => 'Đã xảy ra lỗi trong quá trình đăng ký. Vui lòng thử lại!',
                'error' => $e->getMessage()
            ], 500);
        }
    }


    // Xác thực mail 
    public function verifyEmail($token) {
        $user = User::where('remember_token', $token)->first();
        if(!$user) {
            return response()->json([
                'status' => 'error',
                'message' => 'Token không hợp lệ!'
            ], 404);
        }
        $user->update(['email_verified_at' => now(), 'remember_token' => null]);
        return response()->json([
            'status' => 'success',
            'message' => 'Xác thực email thành công!'
        ], 200);
    }

    // Đăng nhập
    public function login(Request $request) {

        $request->validate([
            'email' => 'required',
            'matkhau' => 'required'
        ]);

        $user = User::where('email', $request->email)->first();
        
        if(!$user || !Hash::check($request->matkhau, $user->matkhau)) {
            return response()->json([
                'status' => 'error',
                'message' => 'Thông tin đăng nhập không chính xác!'
            ], 401);
        }

        if(!$user->email_verified_at) {
            return response()->json([
                'status' => 'error',
                'message' => 'Vui lòng xác thực email trước khi đăng nhập!'
            ], 403);
        }
        
        $token = $user->createToken('auth_token')->plainTextToken;

        return response()->json([
            'status' => 'success',
            'token' => $token,
            'user' => $user
        ], 200);
    }

    // Đăng xuất
    public function logout(Request $request) {

        if($request->user()) {
            $request->user()->tokens()->delete();
            
            return response()->json([
                'status' => 'success',
                'message' => 'Đăng xuất thành công!'
            ], 200);
        }

        return response()->json([
            'status' => 'error',
            'message' => 'Không tìm thấy user đăng nhập'
        ], 401);
    }


    


}
