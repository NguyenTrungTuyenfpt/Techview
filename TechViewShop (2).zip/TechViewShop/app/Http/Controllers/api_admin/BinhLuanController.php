<?php


namespace App\Http\Controllers\Api_admin;

use App\Http\Controllers\Controller;
use App\Models\Models_2\BinhLuanBaiViet;
use Illuminate\Http\Request;
use Illuminate\Support\Facades\Auth;

class BinhLuanController extends Controller
{
    public function index($id_baiviet)
    {
        $binhLuans = BinhLuanBaiViet::with('user', 'replies.user')
            ->where('id_baiviet', $id_baiviet)
            ->whereNull('parent_id')
            ->get();
        return response()->json($binhLuans);
    }


    // Lấy danh sách phản hồi của một bình luận cụ thể
    public function getReplies($id_binhluan)
    {
        $replies = BinhLuanBaiViet::with('user')
            ->where('parent_id', $id_binhluan)
            ->get();
        return response()->json($replies);
    }

    // Thêm bình luận hoặc phản hồi
    public function store(Request $request)
    {
        $request->validate([
            'noidung' => 'required|string',
            'id_baiviet' => 'required|exists:baiviet,id',
            'parent_id' => 'nullable|exists:binhluanbaiviet,id', // parent_id để phản hồi
        ]);

        $binhLuan = BinhLuanBaiViet::create([
            'noidung' => $request->noidung,
            'id_user' => Auth::id(),
            'id_baiviet' => $request->id_baiviet,
            'parent_id' => $request->parent_id, // Nếu có parent_id, đây là phản hồi
        ]);

        return response()->json($binhLuan->load('user'), 201);
    }

    // Sửa bình luận
    public function update(Request $request, $id)
    {
        $binhLuan = BinhLuanBaiViet::findOrFail($id);
        if ($binhLuan->id_user !== Auth::id()) {
            return response()->json(['message' => 'Unauthorized'], 403);
        }

        $request->validate(['noidung' => 'required|string']);
        $binhLuan->update(['noidung' => $request->noidung]);
        return response()->json($binhLuan);
    }
    // Xóa bình luận (và các phản hồi liên quan do onDelete('cascade'))
    public function destroy($id)
    {
        $binhLuan = BinhLuanBaiViet::findOrFail($id);
        if ($binhLuan->id_user !== Auth::id()) {
            return response()->json(['message' => 'Unauthorized'], 403);
        }

        $binhLuan->delete();
        return response()->json(['message' => 'Xóa bình luận thành công']);
    }
}