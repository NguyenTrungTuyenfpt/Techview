<?php

use Illuminate\Database\Migrations\Migration;
use Illuminate\Database\Schema\Blueprint;
use Illuminate\Support\Facades\Schema;

return new class extends Migration
{
    /**
     * Run the migrations.
     */
    public function up(): void
    {
        Schema::create('banners', function (Blueprint $table) {
            $table->id();
            $table->text('ten')->nullable();
            $table->string('hinh')->nullable();
            $table->text('mota')->nullable();
            $table->enum('vitri', ['home-header','home-thumnail-3','home-thumnail-2','home-thumnail-1', 'shop-header','chưa cập nhật'])->default('chưa cập nhật');
            $table->boolean('anhien')->default(1);
            $table->integer('thutu')->default(1);
            $table->string('link')->default('home');
            $table->unsignedBigInteger('id_user'); 
            $table->timestamps();

            $table->foreign('id_user')->references('id')->on('users')->onDelete('cascade');
        });
        
    }
    public function down(): void
    {
        Schema::dropIfExists('banners');
    }
};
