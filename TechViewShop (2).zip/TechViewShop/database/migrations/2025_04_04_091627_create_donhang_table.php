<?php

use Illuminate\Database\Migrations\Migration;
use Illuminate\Database\Schema\Blueprint;
use Illuminate\Support\Facades\Schema;

return new class extends Migration
{
    /**
     * Run the migrations.
     */
    public function up(): void
    {
        Schema::create('donhang', function (Blueprint $table) {
            $table->id();
            $table->string('madonhang')->unique();
            $table->string('tennguoinhan');
            $table->string('sodienthoai');
            $table->text('diachi');
            $table->text('ghichu');
            $table->integer('tongtien');
            $table->enum('trangthai', ['Đang xử lý', 'Đã xác nhận - Đang vận chuyển', 'Hoàn thành', 'Đã hủy'])->default('Đang xử lý');
            $table->enum('phuongthucthanhtoan',['Chuyển khoản ngân hàng', 'Tiền mặt'])->default('Tiền mặt');
            $table->enum('trangthaithanhtoan', ['Đã thanh toán', 'Chưa thanh toán'])->default('Chưa thanh toán');
            $table->unsignedBigInteger('id_khuyenmai')->nullable();
            $table->unsignedBigInteger('id_user');
            $table->timestamps();

            $table->foreign('id_khuyenmai')->references('id')->on('khuyenmai')->onDelete('set null');
            $table->foreign('id_user')->references('id')->on('users')->onDelete('cascade');
        });
    }
    public function down(): void
    {
        Schema::dropIfExists('donhang');
    }
};
