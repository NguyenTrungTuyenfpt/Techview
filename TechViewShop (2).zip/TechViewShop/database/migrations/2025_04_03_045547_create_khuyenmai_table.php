<?php

use Illuminate\Database\Migrations\Migration;
use Illuminate\Database\Schema\Blueprint;
use Illuminate\Support\Facades\Schema;
use Illuminate\Support\Facades\DB;


return new class extends Migration
{
    /**
     * Run the migrations.
     */
    public function up(): void
    {
        Schema::create('khuyenmai', function (Blueprint $table) {
            $table->id(); 
            $table->string('makm');
            $table->string('mota')->default('chưa cập nhật');
            $table->date('ngaybatdau'); 
            $table->date('ngayketthuc'); 
            $table->integer('hesogiamgia')->default(0);
            $table->integer('sotientoithieu')->default(0);
            $table->integer('sotiengiamtoida')->default(0);
            $table->integer('gioihan')->default(1); 
            $table->integer('dasudung')->default(0); 
            $table->unsignedBigInteger('id_user'); 
            $table->timestamps();

            $table->foreign('id_user')->references('id')->on('users')->onDelete('cascade');
        });
    }
    public function down(): void
    {
        Schema::dropIfExists('khuyenmai');
    }
};
