

<?php $__env->startSection('content'); ?>
<div class="container my-4">
    <h2>Cập nhật thông tin cá nhân</h2>

    <?php if(session('message')): ?>
    <div class="alert alert-success">
        <?php echo e(session('message')); ?>

    </div>
    <?php endif; ?>

    <form action="<?php echo e(route('user.updateProfile')); ?>" method="POST" enctype="multipart/form-data">
        <?php echo csrf_field(); ?>

        <?php if($errors->any()): ?>
        <div class="alert alert-danger">
            <ul>
                <?php $__currentLoopData = $errors->all(); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $error): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                <li><?php echo e($error); ?></li>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            </ul>
        </div>
        <?php endif; ?>

        <!-- Tên -->
        <div class="mb-3">
            <label for="name" class="form-label">Họ tên</label>
            <input type="text" class="form-control" id="name" name="name" value="<?php echo e(old('name', $user->hoten)); ?>">
        </div>

        <!-- Số điện thoại -->
        <div class="mb-3">
            <label for="sodienthoai" class="form-label">Số điện thoại</label>
            <input type="text" class="form-control" id="sodienthoai" name="sodienthoai" value="<?php echo e(old('sodienthoai', $user->sodienthoai)); ?>">
        </div>

        <!-- Email
        <div class="mb-3">
            <label for="email" class="form-label">Email</label>
            <input type="email" class="form-control" id="email" name="email" value="<?php echo e(old('email', $user->email)); ?>" required>
        </div> -->

        <!-- Địa chỉ -->
        <div class="mb-3">
            <label for="diachi" class="form-label">Địa chỉ</label>
            <input type="text" class="form-control" id="diachi" name="diachi" value="<?php echo e(old('diachi', $user->diachi)); ?>">
        </div>

        <!-- Giới tính -->
        <div class="mb-3">
            <label for="gioitinh" class="form-label">Giới tính</label>
            <select class="form-select" id="gioitinh" name="gioitinh">
                <option value="nam" <?php echo e(old('gioitinh', $user->gioitinh) == 'nam' ? 'selected' : ''); ?>>Nam</option>
                <option value="nữ" <?php echo e(old('gioitinh', $user->gioitinh) == 'nữ' ? 'selected' : ''); ?>>Nữ</option>
                <option value="khác" <?php echo e(old('gioitinh', $user->gioitinh) == 'khác' ? 'selected' : ''); ?>>Khác</option>
            </select>
        </div>

        <!-- Ngày sinh -->
        <div class="mb-3">
            <label for="ngaysinh" class="form-label">Ngày sinh</label>
            <input type="date" class="form-control" id="ngaysinh" name="ngaysinh" value="<?php echo e(old('ngaysinh', $user->ngaysinh)); ?>">
        </div>

        <!-- Hình ảnh -->
        <div class="mb-3">
            <label for="hinh" class="form-label">Hình ảnh</label>
            <input type="file" class="form-control" id="hinh" name="hinh">
        </div>

        <!-- Mật khẩu -->
        <div class="mb-3">
            <label for="password" class="form-label">Mật khẩu mới</label>
            <input type="password" class="form-control" id="password" name="password">
        </div>

        <!-- Xác nhận mật khẩu -->
        <div class="mb-3">
            <label for="confirm_password" class="form-label">Xác nhận mật khẩu</label>
            <input type="password" class="form-control" id="confirm_password" name="confirm_password">
        </div>

        <button type="submit" class="btn btn-primary">Cập nhật</button>
    </form>
</div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('admin.layout.layout', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\Users\admin\OneDrive - Đại học FPT- FPT University\Desktop\Duantotnghiep\TechViewShop\resources\views/admin/users/profile.blade.php ENDPATH**/ ?>