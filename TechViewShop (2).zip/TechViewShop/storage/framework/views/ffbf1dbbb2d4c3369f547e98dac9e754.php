
<?php $__env->startSection('title'); ?>
    Trang sản phẩm
<?php $__env->stopSection(); ?>

<?php $__env->startSection('body'); ?>
    <div class="container">
        <div class="banner-products hide-on-mobile hide-on-tablet">
            <img src="<?php echo e(asset('img/banner2.jpg')); ?>" alt="Banner quảng cáo">
        </div>

        <div class="grid">
            <div class="row">
                <div class="col l-3 filter-column">
                    <div class="left">
                        <div class="form-column"><button class="btn-primary">Tìm kiếm theo loại</button></div>
                        <div class="product-category"> 
                            <h4 class="title-category">Thể loại</h4>
                            <div class="widget-body">
                                <div >
                                    <ul class="category-product__list">
                                        <?php $__currentLoopData = $categoryList; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $category): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                            <li>
                                                <a href="/category/<?php echo e($category->slug); ?>" class="product_cat">
                                                    <?php echo e($category->tendm); ?>

                                                </a>
                                                
                                            </li>
                                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                    </ul>
                                </div> 
                            </div>
                            <div class="filter-section">
                                <h3 class="filter-title">Lọc theo giá</h3>
                                <div class="price-range">
                                    <input type="range" min="0" max="630" value="0" class="range-slider" />
                                    <span class="price-text">Giá:</span>
                                    <button class="filter-button">Lọc</button>
                                </div>
                            </div>
                            <div class="product-detail-status">
                                <h4 class="status-title">Tình trạng</h4>
                                <div class="checkbox-container">
                                    <input type="checkbox" />
                                    <span class="checkmark">Còn hàng</span>
                                </div>
                                <div class="checkbox-container">
                                    <input type="checkbox" />
                                    <span class="checkmark">Hết hàng</span>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
                <div class="col l-9 pl-none">
                    <div class="right">
                        <div class="before-shop-loop">
                            <div class="filter-button hide-above-992">
                                <a href="#" id="open-filter">
                                    <svg xmlns="http://www.w3.org/2000/svg" height="24px" viewBox="0 0 24 24" width="24px" fill="currentColor">
                                        <path d="M0 0h24v24H0V0z" fill="none"></path>
                                        <path d="M10 18h4v-2h-4v2zM3 6v2h18V6H3zm3 7h12v-2H6v2z"></path>
                                    </svg> Filter
                                </a>
                            </div>
                         <p class="woocommerce-result-count" role="alert" aria-relevant="all" data-is-sorted-by="true">
                             Hiển thị 1-16 trong số 37 sản phẩm</p>
                        <div class="sorting-products">
                            <span>Sort:</span>
                            <form class="woocommerce-ordering" method="get">
                                <select name="orderby" class="orderby" aria-label="Shop order">
                                    <option value="popularity">Sort by popularity</option>
                                    <option value="rating">Sort by average rating</option>
                                    <option value="date" selected="selected">Sort by latest</option>
                                    <option value="price">Sort by price: low to high</option>
                                    <option value="price-desc">Sort by price: high to low</option>          
                                </select>
                                <input type="hidden" name="paged" value="1">
                            </form>
                        </div>
                            <!-- For perpage option-->
                              <div class="per-page-products hide-mobile">
                                    <span>Show:</span>
                                    <form class="woocommerce-ordering product-filter products-per-page" method="get">
                                        <select name="perpage" class="perpage orderby filterSelect select2-hidden-accessible" data-class="select-filter-perpage">
                                            <option value="16">16 Items</option>
                                            <option value="32">32 Items</option>
                                            <option value="48">48 Items</option>
                                            <option value="64">64 Items</option>
                                        </select>
                                    </form>
                                </div>
                        </div>
                        <div class="product-list">
                            <div class="row">
                                <?php if($productList->isEmpty()): ?>
                                    <p class="product-empty">Hiện chưa có sản phẩm</p>
                                <?php else: ?>
                                    <?php $__currentLoopData = $productList; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $product): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                        <div class="col l-3 pr-none">
                                            <div class="product">
                                                <div class="product-item">
                                                    <a href="/product/detail/<?php echo e($product->slug); ?>" class="product-item__link">
                                                        <?php if($product->giamgia): ?>
                                                            <span class="product-item__discount">
                                                                -
                                                                <?php echo e($product->giamgia); ?>

                                                                %</span>
                                                        <?php endif; ?>
                                                        
                                                        <img src="<?php echo e(asset('img/sanpham/'.$product->hinh)); ?>" class="product-item__img" alt="Kính thiên văn">
                                                    </a>
                                                    <a href="#" class="product-item__heart-link">
                                                        <i class="fa-regular fa-heart product-item__heart"></i>
                                                    </a>
                                                </div>
                                                <div class="product-content">
                                                    <a href="/product/detail/<?php echo e($product->slug); ?>" class="product-title"> <?php echo e($product->tensp); ?></a>
                                                    <div class="product-rating">
                                                        <div class="product-rating__list">
                                                            <?php for($i = 0; $i < ($rating->tb_sao ?? 0); $i++): ?>
                                                                <i class="icon-rating fa-solid fa-star"></i>
                                                            <?php endfor; ?>

                                                            <?php for($i = 0; $i < (5 - ($rating->tb_sao ?? 0)); $i++): ?>
                                                                <i class="icon-rating-none fa-solid fa-star"></i>
                                                            <?php endfor; ?>                                    
                                                        </div>
                                                        <?php if($rating->dem ?? 0): ?>
                                                            <span class="product-review"><?php echo e($rating->dem); ?> đánh giá</span>  
                                                        <?php else: ?>
                                                            <span class="product-review">Chưa đánh giá</span>  
                                                        <?php endif; ?>
                                                        
                                                    </div>
                                                    <div class="product-cart2">
                                                        <div class="product-price">
                                                            <?php if($product->giamgia): ?>
                                                                <p class="old-price">
                                                                    <del><?php echo e(number_format($product->gia)); ?>₫</del>
                                                                </p>
                                                                <p class="new-price"><?php echo e(number_format($product->gia * (1 - ($product->giamgia)/100))); ?>₫</p>
                                                            <?php else: ?> 
                                                                <p class="new-price"><?php echo e(number_format($product->gia)); ?>₫</p>
                                                            <?php endif; ?>
                                                            
                                                        </div>
                                                        <a href="" class="product-cart__link"> 
                                                            <i class="product-cart__icon fa-solid fa-cart-shopping"></i>
                                                        </a>
                                                    </div>
                                                    <div class="product-status">
                                                        <svg xmlns="http://www.w3.org/2000/svg" width="15" height="16" viewBox="0 0 15 16" fill="none">
                                                            <path d="M14.1358 3.43605L8.57846 0.28359C7.91183 -0.0945299 7.08783 -0.0945299 6.42121 0.28359L0.864174 3.43605C0.686049 3.53698 0.687054 3.78823 0.866183 3.88791L7.5 7.57974L14.1342 3.88791C14.3133 3.78823 14.3143 3.53729 14.1358 3.43605ZM14.5992 4.83071L8.03571 8.48316V15.4774C8.03571 15.8799 8.48404 16.1309 8.84096 15.9284L13.9356 13.0384C14.5945 12.6647 15 11.9778 15 11.2353V5.05727C15 4.85696 14.7777 4.73134 14.5992 4.83071ZM0 5.05727V11.2353C0 11.9781 0.405469 12.6647 1.0644 13.0384L6.15904 15.9281C6.51629 16.1306 6.96429 15.8799 6.96429 15.4771V8.48316L0.400781 4.83071C0.222321 4.73134 0 4.85696 0 5.05727Z" fill="#099268"/>
                                                        </svg>
                                                        <span class="product-stock">Còn hàng</span>
                                                    </div>
                                                </div>
                                            </div>
                                        </div> 
                                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                <?php endif; ?>
                            </div>
                            <div class="custom-pagination">
                                <?php echo e($productList->links()); ?>

                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('client.layout.layout', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\Users\admin\OneDrive - Đại học FPT- FPT University\Desktop\Duantotnghiep\TechViewShop\resources\views/client/pages/product.blade.php ENDPATH**/ ?>