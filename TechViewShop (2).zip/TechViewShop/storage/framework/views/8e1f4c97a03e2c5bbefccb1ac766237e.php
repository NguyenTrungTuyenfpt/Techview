
<?php $__env->startSection('title'); ?>
    Trang giỏ hàng
<?php $__env->stopSection(); ?>

<?php $__env->startSection('body'); ?>
    <div class="shopingcart">
        <?php if(count($cartList) > 0): ?>
            <div class="grid container">
                <div class="row">
                    <div class="col l-8 m-7 c-12">
                        <table class="cart-table">
                            <thead>
                                <tr>
                                    <th colspan="2">Sản phẩm</th>
                                    <th>Số lượng</th>
                                    <th width="100px">Giá</th>
                                </tr>
                            </thead>
                            <tbody>
                                <?php $__currentLoopData = $cartList; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $cart): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                    <tr>
                                        <td>
                                            <form action="<?php echo e(route('cart.delete', $cart->id)); ?>" 
                                                method="post" 
                                                onsubmit="return confirm('Bạn có chắc chắn muốn xóa không?');" 
                                                class="table-icon-del">
                                                <?php echo csrf_field(); ?>
                                                
                                                <button type="submit" class="addcart-icon__link">
                                                    <i class="fa-solid fa-xmark"></i>
                                                </button>
                                                <img src="<?php echo e(asset('/img/sanpham/'.$cart->product->hinh)); ?>" alt="<?php echo e($cart->product->hinh); ?>">
                                            </form>
                                        </td>
                                        <td>
                                            <a href="/product/detail/<?php echo e($cart->product->slug); ?>">
                                                <?php echo e($cart->product->tensp); ?> 
                                            </a>
                                        </td>
                                        <td>
                                            <input class="quantity-change" data-id=<?php echo e($cart->product->id); ?> type="number"  value="<?php echo e($cart->soluong); ?>" min="1" max="<?php echo e($cart->product->tonkho); ?>">
                                        </td>
                                        <td> <?php echo e(number_format(($cart->product->gia * (1 - ($cart->product->giamgia/100))) * $cart->soluong)); ?>₫</td>
                                    </tr>
                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                            </tbody>
                        </table>

                        <div class="row">
                            <div class="col l-6 pl-none">
                                <a href="javascript:void(0)" onclick="history.back()" class="shopingcart-link ">
                                    <i class="shopingcart-link__icon fa-solid fa-arrow-left"></i>
                                    Tiếp tục mua hàng
                                </a>
                            </div>
                        </div>
                    </div>
                    <div class="col l-4 m-5 c-12">
                        <div class="cart-totals">
                            <div class="total-item">
                                <span class="total-title">Tạm tính</span>
                                <span class="total-price"><?php echo e(number_format($total)); ?>₫</span>
                            </div>
                            <div class="total-item2">
                                <span class="total-title2">Thành tiền</span>
                                <span class="total-price2"><?php echo e(number_format($total)); ?>₫</span>
                            </div>
                            <?php if(Auth::check()): ?>
                                <form action="<?php echo e(route('checkout')); ?>" method="GET">
                                    <?php echo csrf_field(); ?>
                                    <button type="submit" class="checkout-btn">Thanh toán ngay</button>
                                </form>
                            <?php else: ?>
                                <a href="<?php echo e(route('account.login')); ?>" class="checkout-btn">Thanh toán ngay</a>
                            <?php endif; ?>
                            
                        </div>
                    </div>
                </div>
            </div>
        <?php else: ?>
            <p class="product-table-empty">Giỏ hàng trống</p>
        <?php endif; ?>
    </div>

    <?php echo csrf_field(); ?>
    <script>
        document.querySelectorAll('.quantity-change').forEach(input => {
            input.addEventListener('change', (event) => {
                let id = event.target.getAttribute('data-id');
                let value = event.target.value;
                fetch(`/cart/update/${id}`, {
                    method: "PATCH",
                    headers: {
                        'Content-Type': 'application/json',
                        'X-CSRF-TOKEN': document.querySelector('[name="_token"]').value
                    },
                    body: JSON.stringify({
                        quantity: value
                    })
                }).then(() => {
                    location.reload();
                });
            })
        })
    </script>
<?php $__env->stopSection(); ?>


<?php echo $__env->make('client.layout.layout', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\Users\admin\OneDrive - Đại học FPT- FPT University\Desktop\Duantotnghiep\TechViewShop\resources\views/client/pages/cart.blade.php ENDPATH**/ ?>