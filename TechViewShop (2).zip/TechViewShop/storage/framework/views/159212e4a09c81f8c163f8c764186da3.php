

<?php $__env->startSection('title', 'Thống kê tổng quan'); ?>

<?php $__env->startSection('content'); ?>
<div class="container-fluid mt-5">
    <!-- Header -->
    <div class="d-flex justify-content-between align-items-center mb-4">
        <h2 class="fw-bold text-primary">Thống kê tổng quan</h2>
        <div class="btn-group">
            <button class="btn btn-outline-primary dropdown-toggle" type="button" id="filterDropdown" data-bs-toggle="dropdown" aria-expanded="false">
                <i class="bi bi-funnel"></i> Lọc theo thời gian
            </button>
            <ul class="dropdown-menu" aria-labelledby="filterDropdown">
                <li><a class="dropdown-item" href="<?php echo e(route('thongke.index', ['filter' => 'today'])); ?>">Hôm nay</a></li>
                <li><a class="dropdown-item" href="<?php echo e(route('thongke.index', ['filter' => 'week'])); ?>">Tuần này</a></li>
                <li><a class="dropdown-item" href="<?php echo e(route('thongke.index', ['filter' => 'month'])); ?>">Tháng này</a></li>
                <li><a class="dropdown-item" href="<?php echo e(route('thongke.index', ['filter' => 'year'])); ?>">Năm nay</a></li>
            </ul>
        </div>
    </div>

    <!-- Tổng quan thống kê -->
    <div class="row mb-4">
        <!-- Doanh thu -->
        <div class="col-md-3 col-sm-6 mb-3">
            <div class="card shadow-sm border-0">
                <div class="card-body d-flex align-items-center">
                    <span class="icon bg-primary text-white rounded-circle p-3 me-3">
                        <i class="bi bi-currency-dollar fs-4"></i>
                    </span>
                    <div>
                        <h5 class="card-title mb-1">Doanh thu</h5>
                        <p class="card-text fw-bold text-primary"><?php echo e(number_format($doanhThu, 0, ',', '.')); ?> VNĐ</p>
                    </div>
                </div>
            </div>
        </div>

        <!-- Số đơn hàng -->
        <div class="col-md-3 col-sm-6 mb-3">
            <div class="card shadow-sm border-0">
                <div class="card-body d-flex align-items-center">
                    <span class="icon bg-success text-white rounded-circle p-3 me-3">
                        <i class="bi bi-bag-check fs-4"></i>
                    </span>
                    <div>
                        <h5 class="card-title mb-1">Số đơn hàng</h5>
                        <p class="card-text fw-bold text-success"><?php echo e($soDonHang); ?></p>
                    </div>
                </div>
            </div>
        </div>

        <!-- Lượng khách hàng -->
        <div class="col-md-3 col-sm-6 mb-3">
            <div class="card shadow-sm border-0">
                <div class="card-body d-flex align-items-center">
                    <span class="icon bg-info text-white rounded-circle p-3 me-3">
                        <i class="bi bi-people fs-4"></i>
                    </span>
                    <div>
                        <h5 class="card-title mb-1">Lượng khách hàng</h5>
                        <p class="card-text fw-bold text-info"><?php echo e($soKhachHang); ?></p>
                    </div>
                </div>
            </div>
        </div>

        <!-- Lượng đánh giá -->
        <div class="col-md-3 col-sm-6 mb-3">
            <div class="card shadow-sm border-0">
                <div class="card-body d-flex align-items-center">
                    <span class="icon bg-warning text-white rounded-circle p-3 me-3">
                        <i class="bi bi-star fs-4"></i>
                    </span>
                    <div>
                        <h5 class="card-title mb-1">Lượng đánh giá</h5>
                        <p class="card-text fw-bold text-warning"><?php echo e($soDanhGia); ?></p>
                    </div>
                </div>
            </div>
        </div>

        <!-- Số bài viết mới -->
        <div class="col-md-3 col-sm-6 mb-3">
            <div class="card shadow-sm border-0">
                <div class="card-body d-flex align-items-center">
                    <span class="icon bg-secondary text-white rounded-circle p-3 me-3">
                        <i class="bi bi-file-earmark-text fs-4"></i>
                    </span>
                    <div>
                        <h5 class="card-title mb-1">Bài viết mới</h5>
                        <p class="card-text fw-bold text-secondary"><?php echo e($soBaiVietMoi); ?></p>
                    </div>
                </div>
            </div>
        </div>

        <!-- Sản phẩm nổi bật -->
        <div class="col-md-3 col-sm-6 mb-3">
            <div class="card shadow-sm border-0">
                <div class="card-body d-flex align-items-center">
                    <span class="icon bg-danger text-white rounded-circle p-3 me-3">
                        <i class="bi bi-fire fs-4"></i>
                    </span>
                    <div>
                        <h5 class="card-title mb-1">Sản phẩm nổi bật</h5>
                        <p class="card-text fw-bold text-danger"><?php echo e($soSanPhamNoiBat); ?></p>
                    </div>
                </div>
            </div>
        </div>

        <!-- Khuyến mãi đang hoạt động -->
        <div class="col-md-3 col-sm-6 mb-3">
            <div class="card shadow-sm border-0">
                <div class="card-body d-flex align-items-center">
                    <span class="icon bg-purple text-white rounded-circle p-3 me-3">
                        <i class="bi bi-ticket-perforated fs-4"></i>
                    </span>
                    <div>
                        <h5 class="card-title mb-1">Khuyến mãi hoạt động</h5>
                        <p class="card-text fw-bold text-purple"><?php echo e($soKhuyenMaiHoatDong); ?></p>
                    </div>
                </div>
            </div>
        </div>
    </div>

    <!-- Bảng thống kê chi tiết -->
    <div class="row mb-4">
        <!-- Sản phẩm bán chạy -->
        <div class="col-md-6 mb-4">
            <div class="card shadow-sm border-0">
                <div class="card-header bg-light">
                    <h5 class="card-title mb-0">Sản phẩm bán chạy</h5>
                </div>
                <div class="card-body">
                    <div class="table-responsive">
                        <table class="table table-hover align-middle">
                            <thead class="table-light">
                                <tr>
                                    <th>#</th>
                                    <th>Tên sản phẩm</th>
                                    <th>Số lượng bán</th>
                                    <th>Doanh thu (VNĐ)</th>
                                </tr>
                            </thead>
                            <tbody>
                                <?php $__empty_1 = true; $__currentLoopData = $sanPhamBanChay; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $sp): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>
                                    <tr>
                                        <td><?php echo e($loop->iteration); ?></td>
                                        <td><?php echo e($sp->tensp); ?></td>
                                        <td><?php echo e($sp->soLuongBan); ?></td>
                                        <td><?php echo e(number_format($sp->doanhThu, 0, ',', '.')); ?></td>
                                    </tr>
                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>
                                    <tr>
                                        <td colspan="4" class="text-center text-muted py-4">
                                            <i class="bi bi-exclamation-circle me-2"></i> Không có sản phẩm nào.
                                        </td>
                                    </tr>
                                <?php endif; ?>
                            </tbody>
                        </table>
                    </div>
                </div>
            </div>
        </div>

        <!-- Sản phẩm sắp hết -->
        <div class="col-md-6 mb-4">
            <div class="card shadow-sm border-0">
                <div class="card-header bg-light">
                    <h5 class="card-title mb-0">Sản phẩm sắp hết</h5>
                </div>
                <div class="card-body">
                    <div class="table-responsive">
                        <table class="table table-hover align-middle">
                            <thead class="table-light">
                                <tr>
                                    <th>#</th>
                                    <th>Tên sản phẩm</th>
                                    <th>Số lượng tồn</th>
                                    <th>Trạng thái</th>
                                </tr>
                            </thead>
                            <tbody>
                                <?php $__empty_1 = true; $__currentLoopData = $sanPhamSapHet; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $sp): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>
                                    <tr>
                                        <td><?php echo e($loop->iteration); ?></td>
                                        <td><?php echo e($sp->tensp); ?></td>
                                        <td><?php echo e($sp->soluong); ?></td>
                                        <td>
                                            <span class="badge <?php echo e($sp->soluong <= 5 ? 'bg-danger' : 'bg-warning'); ?> px-2 py-1">
                                                <?php echo e($sp->soluong <= 5 ? 'Hết hàng' : 'Sắp hết'); ?>

                                            </span>
                                        </td>
                                    </tr>
                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>
                                    <tr>
                                        <td colspan="4" class="text-center text-muted py-4">
                                            <i class="bi bi-exclamation-circle me-2"></i> Không có sản phẩm nào.
                                        </td>
                                    </tr>
                                <?php endif; ?>
                            </tbody>
                        </table>
                    </div>
                </div>
            </div>
        </div>

        <!-- Bài viết mới -->
        <div class="col-md-6 mb-4">
            <div class="card shadow-sm border-0">
                <div class="card-header bg-light">
                    <h5 class="card-title mb-0">Bài viết mới</h5>
                </div>
                <div class="card-body">
                    <div class="table-responsive">
                        <table class="table table-hover align-middle">
                            <thead class="table-light">
                                <tr>
                                    <th>#</th>
                                    <th>Tiêu đề</th>
                                    <th>Danh mục</th>
                                    <th>Người tạo</th>
                                    <th>Ngày tạo</th>
                                </tr>
                            </thead>
                            <tbody>
                                <?php $__empty_1 = true; $__currentLoopData = $baiVietMoi; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $bv): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>
                                    <tr>
                                        <td><?php echo e($loop->iteration); ?></td>
                                        <td><?php echo e($bv->tieude); ?></td>
                                        <td><?php echo e($bv->danhMucBaiViet->tendm ?? 'N/A'); ?></td>
                                        <td><?php echo e($bv->nguoiTao->hoten ?? 'N/A'); ?></td>
                                        <td><?php echo e($bv->created_at->format('d/m/Y')); ?></td>
                                    </tr>
                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>
                                    <tr>
                                        <td colspan="5" class="text-center text-muted py-4">
                                            <i class="bi bi-exclamation-circle me-2"></i> Không có bài viết nào.
                                        </td>
                                    </tr>
                                <?php endif; ?>
                            </tbody>
                        </table>
                    </div>
                </div>
            </div>
        </div>

        <!-- Đánh giá mới -->
        <div class="col-md-6 mb-4">
            <div class="card shadow-sm border-0">
                <div class="card-header bg-light">
                    <h5 class="card-title mb-0">Đánh giá mới</h5>
                </div>
                <div class="card-body">
                    <div class="table-responsive">
                        <table class="table table-hover align-middle">
                            <thead class="table-light">
                                <tr>
                                    <th>#</th>
                                    <th>Sản phẩm</th>
                                    <th>Khách hàng</th>
                                    <th>Điểm</th>
                                    <th>Ngày đánh giá</th>
                                </tr>
                            </thead>
                            <tbody>
                                <?php $__empty_1 = true; $__currentLoopData = $danhGiaMoi; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $dg): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>
                                    <tr>
                                        <td><?php echo e($loop->iteration); ?></td>
                                        <td><?php echo e($dg->sanpham->tensp ?? 'N/A'); ?></td>
                                        <td><?php echo e($dg->user->hoten ?? 'N/A'); ?></td>
                                        <td><?php echo e($dg->danhgia); ?>/5</td>
                                        <td><?php echo e($dg->created_at->format('d/m/Y')); ?></td>
                                    </tr>
                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>
                                    <tr>
                                        <td colspan="5" class="text-center text-muted py-4">
                                            <i class="bi bi-exclamation-circle me-2"></i> Không có đánh giá nào.
                                        </td>
                                    </tr>
                                <?php endif; ?>
                            </tbody>
                        </table>
                    </div>
                </div>
            </div>
        </div>
    </div>

    
</div>

<!-- Script Chart.js -->
<script src="https://cdn.jsdelivr.net/npm/chart.js"></script>


<style>
    .icon {
        display: inline-flex;
        align-items: center;
        justify-content: center;
        width: 50px;
        height: 50px;
    }
    .bg-purple {
        background-color: #6f42c1 !important;
    }
    .text-purple {
        color: #6f42c1 !important;
    }
    .card {
        transition: transform 0.3s ease, box-shadow 0.3s ease;
    }
    .card:hover {
        transform: translateY(-5px);
        box-shadow: 0 10px 20px rgba(0, 0, 0, 0.1) !important;
    }
    .table th, .table td {
        vertical-align: middle;
    }
    .badge {
        font-size: 0.9rem;
    }
</style>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('admin.layout.layout', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\Users\admin\OneDrive - Đại học FPT- FPT University\Desktop\Duantotnghiep\TechViewShop\resources\views/admin/thongke/thongke.blade.php ENDPATH**/ ?>