<header class="header">
    <div class="grid container">
        <div class="header__top hide-on-mobile hide-on-tablet">
            <p class="header__top-title">Chào mừng bạn đến với TechView!</p>
            
        </div>
        <div class="header__center">
            <div class="grid">
                <div class="row">
                    <div class="col l-0 m-1 c-1">
                        <div class="header__menu-moblie" id="header__menu-icon">
                            <i class="header__menu-moblie-icon fa-solid fa-list"></i>
                        </div>
                    </div>
                    <div class="col l-3 m-10 c-10">
                        <a href="<?php echo e(route('index')); ?>" class="header__logo">
                            <img src="<?php echo e(asset('/img/logo1.png')); ?>" class="header__logo-img" alt="">
                        </a>
                    </div>
                    <div class="col l-5 hide-on-tablet hide-on-mobile ">
                        <div class="header__search">
                            <form action="<?php echo e(route('search')); ?>" method="GET" class="form-search">
                                <input type="text" id="search__product" name="key" placeholder="Nhập sản phẩm cần tìm..." autocomplete="off">
                                <button type="submit" class="btn-search">
                                    <i class="fa-solid fa-magnifying-glass"></i>
                                </button>
                            </form>
                        </div>
                    </div>
                    <div class="col l-4 m-1 c-1">
                        <div class="header__info">
                                <div class="col l-4">
                                    <div class="account hide-on-tablet hide-on-mobile">                                       
                                        <div class="account__toggle">Tài khoản</div>
                                        <div class="account__dropdown">
                                            <?php if(Auth::check()): ?>
                                                <p class="account__name"><?php echo e(Auth::user()->hoten); ?></p>
                                                <a href="<?php echo e(route('account.profile')); ?>" class="account__link">Trang cá nhân</a>
                                                <a href="<?php echo e(route('account.logout')); ?>" class="account__link">Đăng xuất</a>
                                            <?php else: ?>
                                                <a href="<?php echo e(route('account.login')); ?>" class="account__link">Đăng nhập</a>
                                                <a href="<?php echo e(route('account.register')); ?>" class="account__link">Đăng ký</a>
                                            <?php endif; ?>
                                        </div>
                                    </div>  
                                </div>
                                <div class="col l-8">
                                    <div class="header__icons">
                                        <a href="<?php echo e(route('favorite')); ?>" class="heart hide-on-tablet hide-on-mobile">
                                            <div class="heart-item">
                                                <i class="heart-icon fa-regular fa-heart"></i>
                                                <?php if($favoriteCountSession): ?>
                                                    <span class="quantity">
                                                        <?php echo e($favoriteCountSession); ?>

                                                    </span>
                                                <?php else: ?>
                                                    <span class="quantity">
                                                        <?php echo e($favoriteCount); ?>

                                                    </span>
                                                <?php endif; ?>
                                            </div>
                                        </a>
                                        <a href="<?php echo e(route('cart')); ?>" class="cart">
                                            <div class="cart-item">
                                                <i class="cart-icon fa-solid fa-cart-shopping"></i>
                                                <?php if($cartCountSession): ?>
                                                    <span class="quantity">
                                                        <?php echo e($cartCountSession); ?>

                                                    </span>
                                                <?php else: ?>
                                                    <span class="quantity">
                                                        <?php echo e($cartCount); ?>

                                                    </span>
                                                <?php endif; ?>
                                            </div>
                                            <div class="cart__desc hide-on-tablet hide-on-mobile">
                                                <?php if($cartCountSession): ?>
                                                    <p class="cart__desc-quantity">
                                                        <?php echo e($cartCountSession ?? 0); ?> sản phẩm
                                                    </p>
                                                <?php else: ?>
                                                    <p class="cart__desc-quantity">
                                                        <?php echo e($cartCount ?? 0); ?> sản phẩm
                                                    </p>
                                                <?php endif; ?>

                                                <?php if(auth()->check()): ?>
                                                    <p class="cart__desc-total">
                                                        <?php echo e(number_format($cartTotal ?? 0)); ?> VNĐ
                                                    </p>
                                                <?php elseif(isset($cartTotalSession)): ?>
                                                    <p class="cart__desc-total">
                                                        <?php echo e(number_format($cartTotalSession ?? 0)); ?> VNĐ
                                                    </p>
                                                <?php else: ?>
                                                    <p class="cart__desc-total">
                                                        0 VNĐ
                                                    </p>
                                                <?php endif; ?>
                                            </div>
                                        </a>
                                    </div>
                                </div>
                            </div>
                      
                    </div>
                </div>
            </div>
        </div>
        <div class="header__bottom">
            <div class="grid">
                <div class="row">
                    <div class="col l-3">
                        <div class="header__menu hide-on-mobile hide-on-tablet">
                            <div class="header__menu-category">
                                <a href="#" class="header__menu-title">Tất cả danh mục</a>
                                <i class="header__menu-icon fa-solid fa-sort-down"></i>
                            </div>
                           
                            <ul class="header__list <?php echo e(Request::is('/') || Request::is('home') ? 'active' : ''); ?>">
                                <?php $__currentLoopData = $categoryList; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $category): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                    <li class="list-item">
                                        <div class="list-item__group">
                                            <a href="/category/<?php echo e($category->slug); ?>" class="list-item__link"><?php echo e($category->tendm); ?></a> 
                                            <?php if($category->children->count()): ?>
                                                <i class="list-item__icon fa-solid fa-chevron-right"></i>
                                        </div>
                                        <ul class="sub-menu">
                                            <?php $__currentLoopData = $category->children; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $subcategory): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                                <li>
                                                    <a href="/category/<?php echo e($category->slug); ?>/<?php echo e($subcategory->slug); ?>"> <?php echo e($subcategory->tendm); ?> </a>
                                                </li>
                                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                        </ul>
                                        <?php endif; ?>
                                    </li>
                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                            </ul>
                            
        
                        </div>
                    </div>
                    <div class="col l-9 p-none">
                        <nav class="navbar" id="toggle-menu-icon">
                            <div class="header__mobile">
                                <a href="" class="header__mobile-link">
                                    <img src="<?php echo e(asset('/img/logo1.png')); ?>" class="header__mobile-img" alt="">
                                </a>
                                <i class="close-menu-icon fa-solid fa-xmark" id="close-menu-icon"></i>
                            </div>
                            <ul class="nav-list">
                                <li><a class="nav-item" href="<?php echo e(route('index')); ?>">Trang chủ</a></li>
                                <li><a class="nav-item" href="<?php echo e(route('product')); ?>">Sản phẩm</a></li>
                                
                                <li><a class="nav-item" href="#">Tin tức</a></li>
                                <li><a class="nav-item" href="#!">Liên hệ</a></li>
                                <li><a class="nav-item pc-none" href="<?php echo e(route('favorite')); ?>">Yêu thích</a></li> 
                                <li><a class="nav-item pc-none" href="<?php echo e(route('account.register')); ?>">Đăng kí</a></li> 
                                <li><a class="nav-item pc-none" href="<?php echo e(route('account.login')); ?>">Đăng nhập</a></li> 
                                <li class="nav-end"><a class="nav-item nav-end" href="#!">Trợ giúp</a></li>
                            </ul>

                            <div class="header__mobile">
                                <a href="#!" class="header__mobile-logout">Đăng xuất</a>
                            </div>
                        </nav>
                    </div>
                </div>
            </div>
        </div>

    </div>
</header><?php /**PATH C:\Users\admin\OneDrive - Đại học FPT- FPT University\Desktop\Duantotnghiep\TechViewShop\resources\views/client/layout/header.blade.php ENDPATH**/ ?>