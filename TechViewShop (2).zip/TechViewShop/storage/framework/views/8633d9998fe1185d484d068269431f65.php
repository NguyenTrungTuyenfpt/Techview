

<?php $__env->startSection('title', 'Edit Product Category'); ?>

<?php $__env->startSection('content'); ?>
<!-- Nội dung chính của trang sẽ nằm ở đây -->

<form action="<?php echo e(route('danhmuc.update', $danhmuc->id)); ?>" method="POST" enctype="multipart/form-data">
    <?php echo csrf_field(); ?>
    <?php echo method_field('PUT'); ?>

    <div class="container">
        <h4 class="fw-bold mt-4">Sửa danh mục</h4>
        <p><a href="/">Trang chủ</a> / <span class="text-primary">Sửa danh mục</span></p>

        <div class="border rounded p-3 shadow-sm bg-light">
            <h5 class="fw-bold">Thông tin danh mục</h5>
            <div class="row">
                <div class="col-md-4 mt-3">
                    <label class="form-label">Tên danh mục cũ: <?php echo e($danhmuc->tendm); ?></label> <br>
                    <label class="form-label">Tên mới</label>
                    <input type="text" name="tendm" value="<?php echo e(old('tendm', $danhmuc->tendm)); ?>" class="form-control" required>
                </div>

                <div class="col-md-4 mt-3">
                    <label class="form-label">Mô tả cũ: <?php echo e($danhmuc->mota); ?></label> <br>
                    <label class="form-label">Mô tả mới</label>
                    <input type="text" name="mota" value="<?php echo e(old('mota', $danhmuc->mota)); ?>" class="form-control">
                </div>

                <div class="col-md-4 mt-3">
                    <label class="form-label">Thứ tự cũ: <?php echo e($danhmuc->thutu); ?></label> <br>
                    <label class="form-label">Thứ tự mới</label>
                    <input type="number" name="thutu" value="<?php echo e(old('thutu', $danhmuc->thutu)); ?>" class="form-control">
                </div>

                <div class="col-md-4 mt-3">
                    <label class="form-label d-block">Trạng thái hiển thị</label>

                    <div class="form-check form-check-inline">
                        <input class="form-check-input" type="radio" name="anhien" id="hienRadio" value="1"
                            <?php echo e(old('anhien', $danhmuc->anhien) == 1 ? 'checked' : ''); ?>>
                        <label class="form-check-label" for="hienRadio">Hiển thị</label>
                    </div>

                    <div class="form-check form-check-inline">
                        <input class="form-check-input" type="radio" name="anhien" id="anRadio" value="0"
                            <?php echo e(old('anhien', $danhmuc->anhien) == 0 ? 'checked' : ''); ?>>
                        <label class="form-check-label" for="anRadio">Ẩn</label>
                    </div>
                </div>

                <!-- Hình ảnh cũ và mới -->
                <div class="col-md-4 mt-3">
                    <label class="form-label">Hình ảnh cũ</label>
                    <div class="mb-2">
                        <?php if($danhmuc->hinh): ?>
                        <img src="<?php echo e(asset('uploads/danhmuc/' . $danhmuc->hinh)); ?>" class="img-fluid" width="150" alt="Hình ảnh cũ">
                        <?php else: ?>
                        <p>Chưa có hình ảnh</p>
                        <?php endif; ?>
                    </div>
                    <label class="form-label">Hình ảnh mới</label>
                    <input type="file" name="hinh" class="form-control">
                </div>
                <!-- Chọn danh mục cha -->
                <div class="col-md-4 mt-3">
                    <label class="form-label">Danh mục cha</label>
                    <select name="id_danhmuc_cha" class="form-control">
                        <!-- Kiểm tra nếu có danh mục cha thì hiển thị tên, nếu không thì hiển thị 'Không có' -->
                       <option value="">Chọn danh mục cha </option>

                        <?php $__currentLoopData = $danhmucAll; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $dm): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <option value="<?php echo e($dm->id); ?>" <?php echo e($danhmuc->id_danhmuc_cha == $dm->id ? 'selected' : ''); ?>>
                            <?php echo e($dm->tendm); ?>

                        </option>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                    </select>
                </div>

            </div>
        </div>

        <div class="d-flex justify-content-end mt-3">
            <button type="submit" class="btn btn-success me-2">Cập nhật</button>
            <a href="<?php echo e(route('danhmuc')); ?>" class="btn btn-secondary">Hủy</a>
        </div>
    </div>
</form>

<?php if(session('popup')): ?>
<script>
    document.addEventListener("DOMContentLoaded", function() {
        // Hiển thị hộp thoại confirm
        Swal.fire({
            icon: "<?php echo e(session('status', 'info')); ?>", // Loại thông báo
            title: '', // Tiêu đề có thể để trống hoặc chỉnh lại
            text: "<?php echo e(session('message')); ?>", // Nội dung thông báo
            showCancelButton: false, // Ẩn nút Cancel (nếu bạn chỉ muốn "OK")
            confirmButtonText: 'OK', // Nút xác nhận "OK"
        }).then((result) => {
            // Chỉ khi người dùng nhấn OK mới chuyển trang
            if (result.isConfirmed) {
                window.location.href = "<?php echo e(session('route')); ?>"; // Chuyển hướng
            }
        });
    });
</script>
<?php endif; ?>
</div>
</div>

<?php $__env->stopSection(); ?>
<?php echo $__env->make('admin.layout.layout', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\Users\admin\OneDrive - Đại học FPT- FPT University\Desktop\Duantotnghiep\TechViewShop\resources\views/admin/danhmucsp/suadanhmuc.blade.php ENDPATH**/ ?>