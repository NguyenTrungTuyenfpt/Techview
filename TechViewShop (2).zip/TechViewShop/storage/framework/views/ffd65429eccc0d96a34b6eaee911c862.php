
<?php $__env->startSection('title'); ?>
    Trang chủ
<?php $__env->stopSection(); ?>

<?php $__env->startSection('body'); ?>
    <!-- Banner 1-->
    <section class="section-banner hide-on-mobile hide-on-tablet">
        <div class="container">
            <div class="row">
                <div class="col l-3"></div>
                <div class="col l-9">
                    <div class="banner">
                        <div class="sub-menu"></div>
                        <div class="slideshow-container">
                            <div class="mySlides fade">
                                
                                <img class="slideshow-img" src="<?php echo e(asset('/')); ?>img/banner1.png">
                                
                            </div>
                            
                            <div class="mySlides fade">
                                
                                <img class="slideshow-img" src="<?php echo e(asset('/')); ?>img/banner2.jpg">
                                
                            </div>
                            
                            <div class="mySlides fade">
                                
                                <img class="slideshow-img" src="<?php echo e(asset('/')); ?>img/banner3.jpg">
                                
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </section>
    <!-- End banner -->

    
    <section class="featuredProduct">
        <div class="grid container">
            <div class="section-product__head">
                <h3 class="section-product__title">Sản phẩm mới</h3>
                <a href="<?php echo e(route('product')); ?>" class="section-product__link pl-none">
                    Xem tất cả
                    <i class="section-product__icon fa-solid fa-arrow-right"></i>
                </a>
            </div>
            <div class="product-slider">
                <div class="row">
                    <div class="product-container">
                        <?php $__currentLoopData = $productList; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $product): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                            <?php
                                $rating = collect($rating)->firstWhere('id_sanpham', $product->id) ?? (object) ['tb_sao' => 0, 'dem' => 0];
                            ?>
                            <div class="col l-2-4 m-4 c-6 pr-none">
                                <div class="product">
                                    <div class="product-item">
                                        <a href="product/detail/<?php echo e($product->slug); ?>" class="product-item__link">
                                            <?php if($product->giamgia): ?>
                                                <span class="product-item__discount">-<?php echo e($product->giamgia); ?>%</span>
                                            <?php endif; ?>
                                            <img src="<?php echo e(asset('/img/sanpham/'.$product->hinh)); ?>" class="product-item__img" alt="Kính thiên văn">
                                        </a>

                                        <?php if($product->tonkho == 0): ?>
                                            <div class="product-detail__status">
                                                Hết hàng
                                            </div>
                                        <?php endif; ?>
                                        <form action="<?php echo e(route('favorite.add')); ?>" method="POST">
                                            <?php echo csrf_field(); ?>
                                            <input type="hidden" name="id" value="<?php echo e($product->id); ?>">
                                            <button type="submit" class="product-item__heart-link">
                                                <i class="fa-regular fa-heart product-item__heart"></i>
                                            </button>
                                        </form>  
                                    </div>
                                    
                                    <div class="product-content">
                                        <a href="product/detail/<?php echo e($product->slug); ?>" class="product-title"> <?php echo e($product->tensp); ?> </a>
                                        
                                        <div class="product-rating">
                                            <div class="product-rating__list">
                                                <?php for($i = 0; $i < ($rating->tb_sao ?? 0) ; $i++): ?>
                                                    <i class="icon-rating fa-solid fa-star"></i>
                                                <?php endfor; ?>
                                                <?php for($i = 0; $i < (5 - ($rating->tb_sao ?? 0)) ; $i++): ?>
                                                    <i class="icon-rating-none fa-solid fa-star"></i>
                                                <?php endfor; ?>                                   
                                            </div>
                                           
                                            <?php if($rating->dem > 0): ?>
                                                <span class="product-review">
                                                    <?php echo e($rating->dem); ?>

                                                    đánh giá
                                                </span>
                                            <?php else: ?>    
                                                <span class="product-review">Chưa đánh giá</span>
                                            <?php endif; ?>
                                            
                                        </div>
                                        <div class="product-cart">
                                            <div class="product-price">
                                                <?php if($product->giamgia): ?>
                                                    <p class="old-price"><del><?php echo e(number_format($product->gia)); ?></del>đ</p>
                                                    <p class="new-price">
                                                        <?php echo e(number_format($product->gia * (1 - ($product->giamgia/100)))); ?>₫
                                                    </p>
                                                <?php else: ?>
                                                    <p class="new-price"><?php echo e(number_format($product->gia)); ?>₫</p>
                                                <?php endif; ?>
                                            </div>
                                            <?php if($product->tonkho == 0): ?>
                                                <button type="submit" class="product-cart__link">
                                                    <i class="product-cart__icon fa-solid fa-cart-shopping"></i>
                                                </button>
                                            <?php else: ?>
                                                <form action="<?php echo e(route('cart.add')); ?>" method="POST">
                                                    <?php echo csrf_field(); ?>
                                                    <input type="hidden" name="id" value="<?php echo e($product->id); ?>">
                                                    <input type="hidden" name="quantity" value="1">
                                                    <button type="submit" class="product-cart__link">
                                                        <i class="product-cart__icon fa-solid fa-cart-shopping"></i>
                                                    </button>
                                                </form>
                                            <?php endif; ?>
                                        </div>
                                        <div class="product-status">
                                            <?php if($product->tonkho == 0): ?>
                                                <svg xmlns="http://www.w3.org/2000/svg" width="15" height="16" viewBox="0 0 15 16" fill="none">
                                                    <path d="M14.1358 3.43605L8.57846 0.28359C7.91183 -0.0945299 7.08783 -0.0945299 6.42121 0.28359L0.864174 3.43605C0.686049 3.53698 0.687054 3.78823 0.866183 3.88791L7.5 7.57974L14.1342 3.88791C14.3133 3.78823 14.3143 3.53729 14.1358 3.43605ZM14.5992 4.83071L8.03571 8.48316V15.4774C8.03571 15.8799 8.48404 16.1309 8.84096 15.9284L13.9356 13.0384C14.5945 12.6647 15 11.9778 15 11.2353V5.05727C15 4.85696 14.7777 4.73134 14.5992 4.83071ZM0 5.05727V11.2353C0 11.9781 0.405469 12.6647 1.0644 13.0384L6.15904 15.9281C6.51629 16.1306 6.96429 15.8799 6.96429 15.4771V8.48316L0.400781 4.83071C0.222321 4.73134 0 4.85696 0 5.05727Z" fill="#099268"/>
                                                </svg>
                                                <span class="item-ofstock">Hết hàng</span>
                                            <?php else: ?>
                                                <svg xmlns="http://www.w3.org/2000/svg" width="15" height="16" viewBox="0 0 15 16" fill="none">
                                                    <path d="M14.1358 3.43605L8.57846 0.28359C7.91183 -0.0945299 7.08783 -0.0945299 6.42121 0.28359L0.864174 3.43605C0.686049 3.53698 0.687054 3.78823 0.866183 3.88791L7.5 7.57974L14.1342 3.88791C14.3133 3.78823 14.3143 3.53729 14.1358 3.43605ZM14.5992 4.83071L8.03571 8.48316V15.4774C8.03571 15.8799 8.48404 16.1309 8.84096 15.9284L13.9356 13.0384C14.5945 12.6647 15 11.9778 15 11.2353V5.05727C15 4.85696 14.7777 4.73134 14.5992 4.83071ZM0 5.05727V11.2353C0 11.9781 0.405469 12.6647 1.0644 13.0384L6.15904 15.9281C6.51629 16.1306 6.96429 15.8799 6.96429 15.4771V8.48316L0.400781 4.83071C0.222321 4.73134 0 4.85696 0 5.05727Z" fill="#099268"/>
                                                </svg>
                                                <span class="item-stock">Còn hàng</span>
                                            <?php endif; ?>
                                        </div>
                                    </div>
                                </div>
                            </div>                            
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                    </div>
                </div>
            </div>
            
            <!-- Dấu chấm điều hướng -->
            <div class="dots">
                <span class="dot active" onclick="moveSlide(0)"></span>
                <span class="dot" onclick="moveSlide(1)"></span>
                <span class="dot" onclick="moveSlide(2)"></span>
                <span class="dot" onclick="moveSlide(3)"></span>
                <span class="dot" onclick="moveSlide(4)"></span>
                <span class="dot" onclick="moveSlide(5)"></span>
            </div>
        </div>
    </section>

    
    <section class="banner">
        <div class="grid container">
            <div class="row">
                <div class="col l-4 m-4 c-12">
                    <a class="banner__link" href="#">
                        <img class="banner__link-img" src="<?php echo e(asset('/img/banner4.webp')); ?>" alt="">
                    </a>
                </div>
                <div class="col l-4 m-4 c-12">
                    <a class="banner__link" href="#">
                        <img class="banner__link-img" src="<?php echo e(asset('/img/banner5.webp')); ?>" alt="">
                    </a>
                </div>
                <div class="col l-4 m-4 c-12">
                    <a class="banner__link" href="#">
                        <img class="banner__link-img" src="<?php echo e(asset('/img/banner6.webp')); ?>" alt="">
                    </a>
                </div>
            </div>
        </div>
    </section>

    
    <section class="deals">
        <div class="grid container">
            <div class="section-deals__head">
                <h3 class="section-deals__title">Ưu Đãi Mới Nhất</h3>
                <a href="<?php echo e(route('product.byType', ['slug' => 'sale'])); ?>" class="section-deals__link">
                    Xem tất cả
                    <i class="section-deals__icon fa-solid fa-arrow-right"></i>
                </a>
            </div>
            <div class="product-list">
                <div class="row">
                    <?php $__currentLoopData = $productHotSaller; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $product): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <div class="col l-6 m-6 c-12">
                            <div class="deals-item">
                                <span class="product-deals__discount">-<?php echo e($product->giamgia); ?>%</span>
                                <div class="row">
                                    <div class="col l-4 m-12 c-12">
                                        <div class="deals-header">
                                            <div class="product-deals-header">
                                                <a href="product/detail/<?php echo e($product->slug); ?>" class="product-deals__link">
                                                    <img src=" <?php echo e(asset('img/sanpham/'. $product->hinh)); ?>" class="product-deals__img" alt="Kính thiên văn">
                                                </a>
                                                <?php if($product->tonkho == 0): ?>
                                                    <div class="product-detail__status">
                                                        Hết hàng
                                                    </div>
                                                <?php endif; ?>
                                                <form action="<?php echo e(route('favorite.add')); ?>" method="POST">
                                                    <?php echo csrf_field(); ?>
                                                    <input type="hidden" name="id" value="<?php echo e($product->id); ?>">
                                                    <button type="submit" class="product-item__heart-link">
                                                        <i class="fa-regular fa-heart product-item__heart"></i>
                                                    </button>
                                                </form>  
                                            </div>
                                        </div>
                                    </div>
                                    <div class="col l-8 m-12 c-12">
                                        <div class="deals-content">
                                            <a href="product/detail/<?php echo e($product->slug); ?>" class="deals-title"> <?php echo e($product->tensp); ?> </a>
                                            <div class="deals-rating">
                                                <div class="deals-rating__list">
                                                    <?php for($i = 0; $i < ($rating->tb_sao ?? 0) ; $i++): ?>
                                                        <i class="icon-rating fa-solid fa-star"></i>
                                                    <?php endfor; ?>
                                                    <?php for($i = 0; $i < (5 - ($rating->tb_sao ?? 0)) ; $i++): ?>
                                                        <i class="icon-rating-none fa-solid fa-star"></i>
                                                    <?php endfor; ?>                                   
                                                </div>
                                               
                                                <?php if($rating->dem): ?>
                                                    <span class="deals-review">
                                                        <?php echo e($rating->dem); ?>

                                                        đánh giá
                                                    </span>
                                                <?php else: ?>    
                                                    <span class="deals-review">Chưa đánh giá</span>
                                                <?php endif; ?>
                                            </div>
                                            <div class="deals-cart">
                                                <div class="deals-price">
                                                    <?php if($product->giamgia): ?>
                                                        <p class="old-price"><del> <?php echo e(number_format($product->gia)); ?> </del>₫</p>
                                                        <p class="new-price">
                                                            <?php echo e(number_format($product->gia * (1- ($product->giamgia/100)))); ?>₫
                                                        </p> 
                                                    <?php else: ?>
                                                        <p class="new-price"><?php echo e(number_format($product->gia)); ?>₫</p>
                                                    <?php endif; ?>
                                                </div>
                                                <?php if($product->tonkho == 0): ?>
                                                    <button type="submit" class="product-cart__link">
                                                        <i class="product-cart__icon fa-solid fa-cart-shopping"></i>
                                                    </button>
                                                <?php else: ?>
                                                    <form action="<?php echo e(route('cart.add')); ?>" method="POST">
                                                        <?php echo csrf_field(); ?>
                                                        <input type="hidden" name="id" value="<?php echo e($product->id); ?>">
                                                        <input type="hidden" name="quantity" value="1">
                                                        <button type="submit" class="product-cart__link">
                                                            <i class="product-cart__icon fa-solid fa-cart-shopping"></i>
                                                        </button>
                                                    </form>
                                                <?php endif; ?>
                                            </div>
                                            <div class="deals-wrapper">
                                                <div class="deals-progress">
                                                    <span class="progress" style="width: <?php echo e((($sold_quantity[$product->id] ?? 0) / $product->soluong )*100); ?>%"></span>
                                                    <span class="no-progress" style="width: <?php echo e(100 - ($product->soluong - ($sold_quantity[$product->id] ?? 0))); ?>%"></span>
                                                </div>
                                                <div class="deals-count">
                                                    <div class="available">
                                                        Có sẵn:
                                                        <strong class="available-bold"><?php echo e($product->soluong); ?></strong>
                                                    </div>
                                                    <div class="sold">
                                                        Đã bán:
                                                        <strong class="sold-bold"><?php echo e($sold_quantity[$product->id] ?? 0); ?></strong>
                                                    </div>
                                                </div>
                                            </div>
                                        </div>
                                    </div>
                                </div>
                            </div>
                        </div>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                </div>

            </div>
    </section>

    
    <?php if($coupon): ?>
        <section class="widget">
            <div class="grid container">
                <div class="row">
                    <div class="col l-12 m-12 c-12">
                        <a class="coupon-wrapper" href="#!">
                            <div class="">
                                <div class="promo-badge">🎁 KHUYẾN MÃI</div>
                                <div class="coupon-sale">
                                    -<?php echo e($coupon->hesogiamgia); ?>

                                    <span>%</span>
                                </div>
                            </div>
                            <div class="text-wrap">
                                <div class="coupon-title"><?php echo e($coupon->mota); ?></div>
                                <div class="coupon-desc">Sử dụng mã giảm giá ở trang thanh toán</div>
                            </div>
                            <div class="sale-overflow hide-on-mobile hide-on-tablet">
                                -
                                <?php echo e($coupon->hesogiamgia); ?>

                                %
                            </div>
                        
                            <button class="coupon-code" id="promoCode" onclick="copyPromoCode()"><?php echo e($coupon->makm); ?></button>
                        </a>
                    </div>
                </div>
            </div>
        </section>
    <?php endif; ?>

    
    <section class="section-product ">
        <div class="grid container">
            <div class="row">
                <div class="col l-3 m-3 c-12 p-none">
                    <div class="promo-banner" href="">
                        <div class="promo-banner__discount">-<?php echo e($coupon->hesogiamgia); ?>%</div>
                        <div class="promo-banner__text">
                            <h2 class="promo-banner__title">Sản phẩm nổi bật</h2>
                            <p class="promo-banner__desc"><?php echo e($coupon->mota); ?></p>
                        </div>
                        <a href="<?php echo e(route('product.byType', ['slug' => 'hot'])); ?>" class="promo-banner__link">Xem tất cả →</a>
                    </div>
                </div>
                <div class="col l-9 m-9 c-12 p-none">
                    <div class="row ">
                        <?php $__currentLoopData = $productHot; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $product): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                            <div class="col l-3 m-4 c-6 p-none">
                                <div class="item__list">
                                <div class="item">
                                    <div class="item-box">
                                        <a href="product/detail/<?php echo e($product->slug); ?>" class="item-box__link">
                                            <?php if($product->giamgia): ?>
                                                <span class="item-box__discount">-<?php echo e($product->giamgia); ?>%</span>
                                            <?php endif; ?>
                                            <img src="<?php echo e(asset('img/sanpham/'.$product->hinh)); ?>" class="item-box__img" alt="<?php echo e($product->hinh); ?>">
                                        </a>
                                        <?php if($product->tonkho == 0): ?>
                                            <div class="product-detail__status">
                                                Hết hàng
                                            </div>
                                        <?php endif; ?>

                                        <form action="<?php echo e(route('favorite.add')); ?>" method="POST">
                                            <?php echo csrf_field(); ?>
                                            <input type="hidden" name="id" value="<?php echo e($product->id); ?>">
                                            <button type="submit" class="product-item__heart-link">
                                                <i class="fa-regular fa-heart product-item__heart"></i>
                                            </button>
                                        </form>  
                                    </div>
                                    <div class="item-details">
                                        <a href="product/detail/<?php echo e($product->slug); ?>" class="item-title">
                                            <?php echo e($product->tensp); ?>

                                        </a>
                                        <div class="item-rating">
                                            <div class="item-rating__list">
                                                <?php for($i = 0; $i < ($rating->tb_sao ?? 0); $i++): ?>
                                                    <i class="icon-rating fa-solid fa-star"></i>
                                                <?php endfor; ?>

                                                <?php for($i = 0; $i < (5 - ($rating->tb_sao ?? 0)); $i++): ?>
                                                    <i class="icon-rating-none fa-solid fa-star"></i>
                                                <?php endfor; ?>                                        
                                            </div>
                                            <?php if($rating->dem): ?>
                                                <span class="item-review"><?php echo e($rating->dem); ?> đánh giá</span>
                                            <?php endif; ?>
                                        </div>
                                        <div class="item-cart">
                                            <div class="item-price">
                                                <?php if($product->giamgia): ?>
                                                    <p class="old-price"><del> <?php echo e(number_format($product->gia)); ?> </del>₫</p>
                                                    <p class="new-price">
                                                        <?php echo e(number_format($product->gia * (1- ($product->giamgia/100)))); ?>₫
                                                    </p> 
                                                <?php else: ?>
                                                    <p class="new-price"><?php echo e(number_format($product->gia)); ?>₫</p>
                                                <?php endif; ?>
                                            </div>
                                            <?php if($product->tonkho == 0): ?>
                                                <button type="submit" class="item-cart__link">
                                                    <i class="item-cart__icon fa-solid fa-cart-shopping"></i>
                                                </button>
                                            <?php else: ?>
                                                <form action="<?php echo e(route('cart.add')); ?>" method="POST">
                                                    <?php echo csrf_field(); ?>
                                                    <input type="hidden" name="id" value="<?php echo e($product->id); ?>">
                                                    <input type="hidden" name="quantity" value="1">
                                                    <button type="submit" class="item-cart__link">
                                                        <i class="item-cart__icon fa-solid fa-cart-shopping"></i>
                                                    </button>
                                                </form>
                                            <?php endif; ?>
                                        </div>
                                        <div class="item-status">
                                            <?php if($product->tonkho == 0): ?>
                                                <svg xmlns="http://www.w3.org/2000/svg" width="15" height="16" viewBox="0 0 15 16" fill="none">
                                                    <path d="M14.1358 3.43605L8.57846 0.28359C7.91183 -0.0945299 7.08783 -0.0945299 6.42121 0.28359L0.864174 3.43605C0.686049 3.53698 0.687054 3.78823 0.866183 3.88791L7.5 7.57974L14.1342 3.88791C14.3133 3.78823 14.3143 3.53729 14.1358 3.43605ZM14.5992 4.83071L8.03571 8.48316V15.4774C8.03571 15.8799 8.48404 16.1309 8.84096 15.9284L13.9356 13.0384C14.5945 12.6647 15 11.9778 15 11.2353V5.05727C15 4.85696 14.7777 4.73134 14.5992 4.83071ZM0 5.05727V11.2353C0 11.9781 0.405469 12.6647 1.0644 13.0384L6.15904 15.9281C6.51629 16.1306 6.96429 15.8799 6.96429 15.4771V8.48316L0.400781 4.83071C0.222321 4.73134 0 4.85696 0 5.05727Z" fill="#099268"/>
                                                </svg>
                                                <span class="item-ofstock">Hết hàng</span>
                                            <?php else: ?>
                                                <svg xmlns="http://www.w3.org/2000/svg" width="15" height="16" viewBox="0 0 15 16" fill="none">
                                                    <path d="M14.1358 3.43605L8.57846 0.28359C7.91183 -0.0945299 7.08783 -0.0945299 6.42121 0.28359L0.864174 3.43605C0.686049 3.53698 0.687054 3.78823 0.866183 3.88791L7.5 7.57974L14.1342 3.88791C14.3133 3.78823 14.3143 3.53729 14.1358 3.43605ZM14.5992 4.83071L8.03571 8.48316V15.4774C8.03571 15.8799 8.48404 16.1309 8.84096 15.9284L13.9356 13.0384C14.5945 12.6647 15 11.9778 15 11.2353V5.05727C15 4.85696 14.7777 4.73134 14.5992 4.83071ZM0 5.05727V11.2353C0 11.9781 0.405469 12.6647 1.0644 13.0384L6.15904 15.9281C6.51629 16.1306 6.96429 15.8799 6.96429 15.4771V8.48316L0.400781 4.83071C0.222321 4.73134 0 4.85696 0 5.05727Z" fill="#099268"/>
                                                </svg>
                                                <span class="item-stock">Còn hàng</span>
                                            <?php endif; ?>
                                        </div>
                                    </div>
                                </div>
                                </div>
                            </div>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                    </div>
                </div>
            </div>
        </div>
    </section>

    
    <section class="banner2">
        <div class="grid container">
            <div class="row">
                <div class="col l-6 m-6 c-12">
                    <a class="banner2__link" href="#">
                        <img class="banner2__link-img" src="<?php echo e(asset('/img/banner7.webp')); ?>" alt="">
                    </a>
                </div>
                <div class="col l-6 m-6 c-12">
                    <a class="banner2__link" href="#">
                        <img class="banner2__link-img" src="<?php echo e(asset('/img/banner8.webp')); ?>" alt="">
                    </a>
                </div>
            </div>
        </div>
    </section>

    
    <section class="sales">
        <div class="grid container">
            <div class="section-sales__head">
                <h3 class="section-sales__title">Sản Phẩm Khuyến mãi</h3>
                <?php if(isset($countdown['end_time'])): ?>
                    <div class="date-time" id="countdown" data-time=<?php echo e($countdown['end_time']); ?>>
                        <div id="days">00</div>
                        <span class="separator">:</span>
                        <div id="hours">00</div>
                        <span class="separator">:</span>
                        <div id="minutes">00</div>
                        <span class="separator">:</span>
                        <div id="seconds">00</div>
                    </div>
                <?php endif; ?>
                <a href="<?php echo e(route('product.byType', ['slug' => 'sale'])); ?>" class="section-sales__link">
                    Xem tất cả
                    <i class="section-sales__icon fa-solid fa-arrow-right"></i>
                </a>
            </div>
            <div class="row">
                <?php $__currentLoopData = $productSaller; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $product): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <div class="col l-2-4 m-4 c-6 pr-none">
                        <div class="product">
                            <div class="product-item">
                                <a href="product/detail/<?php echo e($product->slug); ?>" class="product-item__link">
                                    <?php if($product->giamgia): ?>
                                        <span class="product-item__discount">-<?php echo e($product->giamgia); ?>%</span>
                                    <?php endif; ?>
                            
                                    <img src="<?php echo e(asset('img/sanpham/'.$product->hinh)); ?>" class="product-item__img" alt="Kính thiên văn">
                                </a>
                                <?php if($product->tonkho == 0): ?>
                                    <div class="product-detail__status">
                                        Hết hàng
                                    </div>
                                <?php endif; ?> 

                                <form action="<?php echo e(route('favorite.add')); ?>" method="POST">
                                    <?php echo csrf_field(); ?>
                                    <input type="hidden" name="id" value="<?php echo e($product->id); ?>">
                                    <button type="submit" class="product-item__heart-link">
                                        <i class="fa-regular fa-heart product-item__heart"></i>
                                    </button>
                                </form>  
                            </div>
                            
                            <div class="product-content">
                                <a href="product/detail/<?php echo e($product->slug); ?>" class="product-title"> <?php echo e($product->tensp); ?> </a>
                                <div class="product-rating">
                                    <div class="product-rating__list">
                                        <?php for($i = 0; $i < ($rating->tb_sao ?? 0); $i++): ?>
                                            <i class="icon-rating fa-solid fa-star"></i>    
                                        <?php endfor; ?>
                                        <?php for($i = 0; $i < (5 - ($rating->tb_sao ?? 0)); $i++): ?>
                                            <i class="icon-rating-none fa-solid fa-star"></i>    
                                        <?php endfor; ?>                                       
                                    </div>
                                    <?php if($rating->dem): ?>
                                        <span class="product-review"><?php echo e($rating->dem); ?></span>      
                                    <?php else: ?>
                                        <span class="product-review">Chưa đánh giá</span>      
                                    <?php endif; ?>
                                </div>
                                <div class="product-cart">
                                    <div class="product-price">
                                        <p class="old-price"><del>3.200.000</del> đ</p>
                                        <p class="new-price">2.850.000₫</p>
                                    </div>
                                    <?php if($product->tonkho == 0): ?>
                                        <button type="submit" class="product-cart__link">
                                            <i class="product-cart__icon fa-solid fa-cart-shopping"></i>
                                        </button>
                                    <?php else: ?>
                                        <form action="<?php echo e(route('cart.add')); ?>" method="POST">
                                            <?php echo csrf_field(); ?>
                                            <input type="hidden" name="id" value="<?php echo e($product->id); ?>">
                                            <input type="hidden" name="quantity" value="1">
                                            <button type="submit" class="product-cart__link">
                                                <i class="product-cart__icon fa-solid fa-cart-shopping"></i>
                                            </button>
                                        </form>
                                    <?php endif; ?>                                       
                                </div>

                                <div class="product-status">
                                    <?php if($product->tonkho == 0): ?>
                                        <svg xmlns="http://www.w3.org/2000/svg" width="15" height="16" viewBox="0 0 15 16" fill="none">
                                            <path d="M14.1358 3.43605L8.57846 0.28359C7.91183 -0.0945299 7.08783 -0.0945299 6.42121 0.28359L0.864174 3.43605C0.686049 3.53698 0.687054 3.78823 0.866183 3.88791L7.5 7.57974L14.1342 3.88791C14.3133 3.78823 14.3143 3.53729 14.1358 3.43605ZM14.5992 4.83071L8.03571 8.48316V15.4774C8.03571 15.8799 8.48404 16.1309 8.84096 15.9284L13.9356 13.0384C14.5945 12.6647 15 11.9778 15 11.2353V5.05727C15 4.85696 14.7777 4.73134 14.5992 4.83071ZM0 5.05727V11.2353C0 11.9781 0.405469 12.6647 1.0644 13.0384L6.15904 15.9281C6.51629 16.1306 6.96429 15.8799 6.96429 15.4771V8.48316L0.400781 4.83071C0.222321 4.73134 0 4.85696 0 5.05727Z" fill="#099268"/>
                                        </svg>
                                        <span class="item-ofstock">Hết hàng</span>
                                    <?php else: ?>
                                        <svg xmlns="http://www.w3.org/2000/svg" width="15" height="16" viewBox="0 0 15 16" fill="none">
                                            <path d="M14.1358 3.43605L8.57846 0.28359C7.91183 -0.0945299 7.08783 -0.0945299 6.42121 0.28359L0.864174 3.43605C0.686049 3.53698 0.687054 3.78823 0.866183 3.88791L7.5 7.57974L14.1342 3.88791C14.3133 3.78823 14.3143 3.53729 14.1358 3.43605ZM14.5992 4.83071L8.03571 8.48316V15.4774C8.03571 15.8799 8.48404 16.1309 8.84096 15.9284L13.9356 13.0384C14.5945 12.6647 15 11.9778 15 11.2353V5.05727C15 4.85696 14.7777 4.73134 14.5992 4.83071ZM0 5.05727V11.2353C0 11.9781 0.405469 12.6647 1.0644 13.0384L6.15904 15.9281C6.51629 16.1306 6.96429 15.8799 6.96429 15.4771V8.48316L0.400781 4.83071C0.222321 4.73134 0 4.85696 0 5.05727Z" fill="#099268"/>
                                        </svg>
                                        <span class="product-stock">Còn hàng</span>
                                    <?php endif; ?>
                                </div>
                            </div>
                        </div>
                    </div>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            </div>
    </section>

    
    <section class="banner">
        <div class="grid container">
            <div class="row">
                <div class="col l-12 m-12 c-12">
                    <a class="banner__link" href="#">
                        <img class="banner__link-img" src="<?php echo e(asset('/img/banner9.webp')); ?>" alt="">
                    </a>
                </div>
            </div>
        </div>
    </section>    

    
    <section class="category">
        <div class="grid container">
            <div class="section-category__head">
                <h3 class="section-category__title">Danh mục có nhiều sản phẩm</h3>
                <a href="<?php echo e(route('product')); ?>" class="section-category__link">
                    Xem tất cả
                    <i class="section-category__icon fa-solid fa-arrow-right"></i>
                </a>
            </div>
            <div class="category-list">
                <div class="row">
                    <?php $__currentLoopData = $topCategory; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $category): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <div class="col l-2 m-4 c-6 p-none">
                            <div class="category-item ">
                                <a class="category-item__link">
                                    <img src="<?php echo e(asset('img/sanpham/'.$category->hinh)); ?>" class="category-item__img" alt="Kính thiên văn">
                                </a>
                                <div class="category-content">
                                    <a href="/category/<?php echo e($category->slug); ?>" class="category-title"><?php echo e($category->tendm); ?></a>
                                    <span class="counter">
                                        <?php echo e($category->product_count); ?> sản phẩm
                                    </span>
                                </div>
                            </div>
                        </div>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                    
                </div>
            </div>
        </div>
    </section>

    
    <section class="customer">
        <div class="grid container">
            <div class="row">
                <div class="col l-12 m-12 c-12">
                    <div class="customer-head">
                        <h3 class="customer-title">Nhận Xét Của Khách Hàng</h3>
                        <p class="customer-desc hide-on-mobile hide-on-table">
                            Kính thiên văn sắc nét, dễ sử dụng. 
                            Giao hàng nhanh, đóng gói cẩn thận. 
                            Dịch vụ tư vấn nhiệt tình, rất hài lòng. Sẽ ủng hộ TechView lâu dài!
                        </p>
                    </div>
                </div>
            </div>
            <div class="customer-list">
                <div class="row">
                    <div class="col l-4 m-4 c-12">
                        <div class="customer-item">
                            <div class="customer-avatar">
                                <img src="<?php echo e(asset('img/avatar1.jpg')); ?>" alt="" class="customer-avatar__img">
                            </div>
                            <div class="customer-content">
                                <div class="customer-content__stars">
                                    <i class="customer-rating__icon fa-solid fa-star"></i>
                                    <i class="customer-rating__icon fa-solid fa-star"></i>
                                    <i class="customer-rating__icon fa-solid fa-star"></i>
                                    <i class="customer-rating__icon fa-solid fa-star"></i>
                                    <i class="customer-rating__icon fa-solid fa-star"></i> 
                                </div>
                                <div class="customer-name">Nguyễn Long Tuấn Kiệt</div>
                                <div class="customer-mission">Quản trị nhà hàng</div>
                                <div class="customer-description">
                                    <p>Sản phẩm tuyệt vời! Hình ảnh sắc nét, dễ sử dụng, rất phù hợp cho người mới bắt đầu quan sát thiên văn</p>
                                </div>
                            </div>
                        </div>
                    </div>
                    <div class="col l-4 m-4 c-12">
                        <div class="customer-item">
                            <div class="customer-avatar">
                                <img src="<?php echo e(asset('img/avatar2.jpg')); ?>" alt="" class="customer-avatar__img">
                            </div>
                            <div class="customer-content">
                                <div class="customer-content__stars">
                                    <i class="customer-rating__icon fa-solid fa-star"></i>
                                    <i class="customer-rating__icon fa-solid fa-star"></i>
                                    <i class="customer-rating__icon fa-solid fa-star"></i>
                                    <i class="customer-rating__icon fa-solid fa-star"></i>
                                    <i class="customer-rating__icon fa-solid fa-star"></i> 
                                </div>
                                <div class="customer-name">Trần Văn Nam</div>
                                <div class="customer-mission">Quản trị nhà hàng</div>
                                <div class="customer-description">
                                    <p>Chất lượng kính rất tốt, giao hàng nhanh, đóng gói cẩn thận. Nhân viên tư vấn nhiệt tình, rất hài lòng!</p>
                                </div>
                            </div>
                        </div>
                    </div>
                    <div class="col l-4 m-4 c-12">
                        <div class="customer-item">
                            <div class="customer-avatar">
                                <img src="<?php echo e(asset('img/avatar3.jpg')); ?>" alt="" class="customer-avatar__img">
                            </div>
                            <div class="customer-content">
                                <div class="customer-content__stars">
                                    <i class="customer-rating__icon fa-solid fa-star"></i>
                                    <i class="customer-rating__icon fa-solid fa-star"></i>
                                    <i class="customer-rating__icon fa-solid fa-star"></i>
                                    <i class="customer-rating__icon fa-solid fa-star"></i>
                                    <i class="customer-rating__icon fa-solid fa-star"></i> 
                                </div>
                                <div class="customer-name">Nguyễn Vân Anh</div>
                                <div class="customer-mission">Diễn Viên</div>
                                <div class="customer-description">
                                    <p>Giá hợp lý, kính thiên văn hoạt động tốt, nhìn rõ Mặt Trăng và các hành tinh. Sẽ ủng hộ lần sau!</p>
                                </div>
                            </div>
                        </div>
                    </div>
                    
                </div>
            </div>
        </div>
    </section>

    
    <?php if($coupon): ?>
        <section class="coupon">
            <div class="grid container">
                <div class="row">
                    <div class="col l-12 m-12 c-12">
                        <a class="coupon-wrapper" href="#!">
                            <div class="coupon-title mb-none mb-moblie">
                                <?php echo e($coupon->mota); ?>

                            </div>
                            <div class="coupon-code__mess mb-moblie">
                                <span> <?php echo e($coupon->makm); ?></span>
                            </div>
                            <div class="coupon-desc" id="promoCode" onclick="copyPromoCode()">
                                <p>Sử dụng mã giảm giá ở trạng thái thanh toán</p>
                            </div>
                        </a>
                    </div>
                </div>
            </div>
        </section>
    <?php endif; ?>

    
    <section class="news">
        <div class="grid container">
            <div class="section-category__head">
                <h3 class="section-category__title">Tin tức mới nhất</h3>
                <a href="#" class="section-category__link">
                    Xem tất cả
                    <i class="section-category__icon fa-solid fa-arrow-right"></i>
                </a>
            </div>
            <div class="news-list">
                <div class="row">
                    <?php $__currentLoopData = $blogs; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $blog): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <div class="col l-4 m-4 c-12">
                            <div class="news-item">
                                <a class="news-item__link">
                                    <img src="<?php echo e(asset('img/baiviet/'. $blog->hinh)); ?>" alt="" class="news-item__link-img">
                                </a>
                                <div class="news-body">
                                    <div class="news-published"><?php echo e(\Carbon\Carbon::parse($blog->created_at)->format('d-m-Y')); ?></div>

                                    <a href="#!" class="news-title"><?php echo e($blog->tieude); ?></a>
                                    <div class="news-content">
                                        <?php echo e($blog->noidung); ?>

                                    </div>
                                    <div class="news-meta">
                                        <div class="news-auth">
                                            <p>Được viết bởi</p>
                                            <p class="news-authby"><?php echo e($blog->user->hoten); ?></p>
                                        </div>
                                        <div class="news-comment">
                                            <p>Bình luận</p>
                                            <p class="news-count"><?php echo e($blog->comments_count ?? 0); ?></p>
                                        </div>
                                    </div>
                                </div>
                            </div>
                        </div>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                </div>
            </div>
        </div>
    </section>
    

    <script>
         function copyPromoCode() {
            const code = document.getElementById('promoCode').textContent;
            navigator.clipboard.writeText(code).then(() => {
                alert("Mã giảm giá đã được sao chép!");
            });
        }
    </script>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('client.layout.layout', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\Users\admin\OneDrive - Đại học FPT- FPT University\Desktop\Duantotnghiep\TechViewShop\resources\views/client/pages/home.blade.php ENDPATH**/ ?>