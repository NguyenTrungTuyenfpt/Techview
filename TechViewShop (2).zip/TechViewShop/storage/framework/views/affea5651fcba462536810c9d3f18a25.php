

<?php $__env->startSection('title', 'Thêm mã khuyến mãi'); ?>

<?php $__env->startSection('content'); ?>
<!-- Nội dung chính của trang sẽ nằm ở đây -->

<form action="<?php echo e(route('khuyenmai.store')); ?>" method="POST">
    <?php echo csrf_field(); ?>
    <div class="container">
        <h4 class="fw-bold mt-4">Thêm khuyến mãi</h4>
        <p><a href="/">Trang chủ</a> / <span class="text-primary">Thêm khuyến mãi</span></p>
        <div class="add-product">
            <div class="row">
                <!-- Thông tin sản phẩm -->
                <div class="col-md-12">
                    <div class="border rounded p-3">
                        <h5 class="fw-bold">Thông tin </h5>
                        <div class="row">
                            <div class="col-md-4 mt-3">
                                <label class="form-label">Mã</label>
                                <input type="text" name="makm" class="form-control" placeholder="Nhập tại đây">
                                <?php $__errorArgs = ['makm'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                    <div class="text-danger mt-1"><?php echo e($message); ?></div>
                                <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                            </div>
                            <div class="col-md-4 mt-3">
                                <label class="form-label">Mô tả</label>
                                <input type="text" name="mota" class="form-control" placeholder="Nhập tại đây">
                                <?php $__errorArgs = ['mota'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                    <div class="text-danger mt-1"><?php echo e($message); ?></div>
                                <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                            </div>
                            <div class="col-md-4 mt-3">
                                <label class="form-label">Ngày bắt đầu</label>
                                <input type="date" name="ngaybatdau" class="form-control" placeholder="Nhập tại đây">
                                <?php $__errorArgs = ['ngaybatdau'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                    <div class="text-danger mt-1"><?php echo e($message); ?></div>
                                <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                            </div>

                            <div class="col-md-4 mt-3">
                                <label class="form-label">Ngày kết thúc </label>
                                <input type="date" name="ngayketthuc" class="form-control" placeholder="Nhập tại đây">
                                <?php $__errorArgs = ['ngayketthuc'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                    <div class="text-danger mt-1"><?php echo e($message); ?></div>
                                <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                            </div>

                            <div class="col-md-4 mt-3">
                                <label class="form-label">Hệ số giảm giá (%) </label>
                                <input type="number" name="hesogiamgia" class="form-control" placeholder="Nhập tại đây">
                                <?php $__errorArgs = ['hesogiamgia'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                    <div class="text-danger mt-1"><?php echo e($message); ?></div>
                                <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                            </div>

                            <div class="col-md-4 mt-3">
                                <label class="form-label">Số tiền đơn hàng được áp dụng (VND)   </label>
                                <input type="number" name="sotientoithieu" class="form-control" placeholder="Nhập tại đây">
                               
                            </div>

                            <div class="col-md-4 mt-3">
                                <label class="form-label">Số tiền được giảm tối đa (VND)   </label>
                                <input type="number" name="sotiengiamtoida" class="form-control" placeholder="Nhập tại đây">
                               
                            </div>

                            <div class="col-md-4 mt-3">
                                <label class="form-label">Giới hạn sử dụng     </label>
                                <input type="number" name="gioihan" min="1" class="form-control" placeholder="Nhập tại đây">
                               
                            </div>

                            <div class="col-md-4 mt-3">
                                <label class="form-label">Trạng thái hoạt động</label>
                                <div class="form-check">
                                    <input class="form-check-input" type="radio" name="hoatdong" id="hien" value="1" checked>
                                    <label class="form-check-label" for="hien">Hoạt động </label>
                                </div>                               
                                <div class="form-check">
                                    <input class="form-check-input" type="radio" name="hoatdong" id="an" value="0">
                                    <label class="form-check-label" for="an">Ngừng hoạt động</label>
                                </div>
                               

                            </div>


                           

                        </div>
                    </div>
                </div>



            </div>

            <!-- Buttons -->
            <div class="d-flex justify-content-end mt-2">
                <button class="btn btn-primary me-2">Thêm</button>
                <button class="btn btn-danger">Hủy</button>
            </div>
        </div>
    </div>

</form>

</div>
</div>


<?php if(session('popup')): ?>
<script>
    window.onload = function() {
        if (confirm("<?php echo e(session('message')); ?>")) {
            window.location.href = "<?php echo e(route('khuyenmai')); ?>";
        }
    };
</script>
<?php endif; ?>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('admin.layout.layout', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\Users\admin\OneDrive - Đại học FPT- FPT University\Desktop\Duantotnghiep\TechViewShop\resources\views/admin/khuyenmai/themkhuyenmai.blade.php ENDPATH**/ ?>