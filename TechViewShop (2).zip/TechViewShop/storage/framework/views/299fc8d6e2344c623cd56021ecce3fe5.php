

<?php $__env->startSection('title', 'Them banner'); ?>

<?php $__env->startSection('content'); ?>
<!-- Nội dung chính của trang sẽ nằm ở đây -->
<div class="container">
    <h4 class="fw-bold mt-4">Thêm banner</h4>
    <p><a href="/">Trang chủ</a> / <span class="text-primary">Thêm banner</span></p>

    <form action="<?php echo e(route('banner.store')); ?>" method="POST" enctype="multipart/form-data">
        <?php echo csrf_field(); ?>
        <!-- Toàn bộ phần giao diện thêm sp ở trong đây -->
        <div class="add-product">
            <div class="row">
                <!-- Thông tin sản phẩm -->
                <div class="col-md-12">
                    <div class="border rounded p-3">
                        <h5 class="fw-bold">Thông tin banner</h5>
                        <div class="row">
                            <div class="col-md-4 mt-3">
                                <label class="form-label">Tên </label>
                                <input type="text" name="ten" class="form-control" placeholder="Nhập tại đây">
                            </div>
                            <div class="col-md-4 mt-3">
                                <label class="form-label">Mo ta</label>
                                <input type="text" name="mota" class="form-control" placeholder="Nhập tại đây">
                            </div>
                            <div class="col-md-4 mt-3">
                                <label class="form-label">Link</label>
                                <input type="text" name="link" class="form-control" placeholder="Nhập tại đây">
                            </div>
                            <div class="col-md-4 mt-3">
                                <label class="form-label">Vi tri</label>
                                <input type="text" name="vitri" class="form-control" placeholder="Nhập tại đây">
                            </div>

                            <!-- Thứ tự ưu tiên -->
                            <div class="col-md-4 mt-3">
                                <label class="form-label">Thứ tự</label>
                                <input type="number" name="thutu" class="form-control" placeholder="Thứ tự ưu tiên"  required>
                               
                            </div>


                            <div class="col-md-4 mt-3">
                                <!-- Trạng thái Hiển thị -->
                                <label class="form-label d-block">Trạng thái hiển thị</label>
                                <div class="form-check form-check-inline">
                                    <input class="form-check-input" type="radio" name="anhien" id="hienthiRadio" value="1" checked>
                                    <label class="form-check-label" for="hienthiRadio">Hiển thị</label>
                                </div>
                                <div class="form-check form-check-inline">
                                    <input class="form-check-input" type="radio" name="anhien" id="anRadio" value="0">
                                    <label class="form-check-label" for="anRadio">Ẩn</label>
                                </div>

                            </div>





                        </div>
                    </div>
                </div>

            </div>
            <!-- Image Upload -->
            <div class="border rounded p-4 text-center mt-2">
                <i class="bi bi-image" style="font-size: 60px; color: #ccc;"></i>
                <p class="text-muted">Ảnh </p>
                <input type="file" name="hinh" class="form-control mt-2" multiple required>
            </div>



            <!-- Buttons -->
            <div class="d-flex justify-content-end mt-2">
                <button type="submit" class="btn btn-primary me-2">Thêm </button>
                <button class="btn btn-danger">Hủy</button>
            </div>
        </div>
    </form>

</div>

</div>
</div>

<?php if($errors->any()): ?>
<div class="alert alert-danger">
    <ul>
        <?php $__currentLoopData = $errors->all(); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $error): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
        <li><?php echo e($error); ?></li>
        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
    </ul>
</div>
<?php endif; ?>


<?php if(session('popup')): ?>
<script>
    window.onload = function() {
        if (confirm("<?php echo e(session('message')); ?>")) {
            window.location.href = "<?php echo e(route('banner')); ?>";
        }
    };
</script>
<?php endif; ?>


<?php $__env->stopSection(); ?>
<?php echo $__env->make('admin.layout.layout', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\Users\admin\OneDrive - Đại học FPT- FPT University\Desktop\Duantotnghiep\TechViewShop\resources\views/admin/banner/thembanner.blade.php ENDPATH**/ ?>