

<?php $__env->startSection('title', 'Khách hàng'); ?>

<?php $__env->startSection('content'); ?>
<div class="container mt-5">
    <div class="row justify-content-center">
        <div class="col-lg-12">
            <!-- Header -->
            <div class="d-flex justify-content-between align-items-center mb-4">
                <h2 class="fw-bold text-primary">Danh sách tài khoản khách hàng</h2>
                <a href="#" class="btn btn-primary">
                    <i class="bi bi-plus-lg"></i> Thêm khách hàng
                </a>
            </div>

            <!-- Card chính -->
            <div class="card border-0 shadow-lg rounded-3">
                <div class="card-body p-4">
                    <!-- Tìm kiếm và sắp xếp -->
                    <div class="row mb-4">
                        <div class="col-md-6 mb-3 mb-md-0">
                            <form method="GET" action="<?php echo e(route('khachhang')); ?>">
                                <div class="input-group">
                                    <input type="text" name="search" class="form-control" placeholder="Tìm theo tên, email, SDT..." value="<?php echo e($search); ?>">
                                    <button class="btn btn-primary" type="submit">
                                        <i class="bi bi-search"></i> Tìm kiếm
                                    </button>
                                </div>
                            </form>
                        </div>
                        <div class="col-md-6 text-md-end">
                            <div class="btn-group">
                                <a href="<?php echo e(request()->fullUrlWithQuery(['sort' => 'id', 'direction' => $sort == 'id' && $direction == 'asc' ? 'desc' : 'asc'])); ?>"
                                   class="btn btn-outline-primary btn-sm">
                                    Theo ID
                                    <i class="bi <?php echo e($sort == 'id' && $direction == 'asc' ? 'bi-sort-down' : 'bi-sort-up'); ?>"></i>
                                </a>
                                <a href="<?php echo e(request()->fullUrlWithQuery(['sort' => 'hoten', 'direction' => $sort == 'hoten' && $direction == 'asc' ? 'desc' : 'asc'])); ?>"
                                   class="btn btn-outline-primary btn-sm">
                                    Theo Tên
                                    <i class="bi <?php echo e($sort == 'hoten' && $direction == 'asc' ? 'bi-sort-down' : 'bi-sort-up'); ?>"></i>
                                </a>
                                <a href="<?php echo e(request()->fullUrlWithQuery(['sort' => 'so_don_hoanthanh', 'direction' => $sort == 'so_don_hoanthanh' && $direction == 'asc' ? 'desc' : 'asc'])); ?>"
                                   class="btn btn-outline-primary btn-sm">
                                    Theo Đơn HT
                                    <i class="bi <?php echo e($sort == 'so_don_hoanthanh' && $direction == 'asc' ? 'bi-sort-down' : 'bi-sort-up'); ?>"></i>
                                </a>
                                <a href="<?php echo e(request()->fullUrlWithQuery(['sort' => 'tong_tien_dachi', 'direction' => $sort == 'tong_tien_dachi' && $direction == 'asc' ? 'desc' : 'asc'])); ?>"
                                   class="btn btn-outline-primary btn-sm">
                                    Theo Tổng chi
                                    <i class="bi <?php echo e($sort == 'tong_tien_dachi' && $direction == 'asc' ? 'bi-sort-down' : 'bi-sort-up'); ?>"></i>
                                </a>
                            </div>
                        </div>
                    </div>

                    <!-- Bảng dữ liệu -->
                    <div class="table-responsive">
                        <table class="table table-hover align-middle">
                            <thead class="table-light">
                                <tr>
                                    <th>#</th>
                                    <th>Họ tên</th>
                                    <th>SDT</th>
                                    <th>Email</th>
                                    <th>Địa chỉ</th>
                                    <th>Giới tính</th>
                                    <th>Hoàn thành</th>
                                    <th>Chưa thanh toán</th>
                                    <th>Tổng đơn</th>
                                    <th>Tổng chi</th>
                                    <th>Trạng thái</th>
                                    <th>Hành động</th>
                                </tr>
                            </thead>
                            <tbody>
                                <?php $__empty_1 = true; $__currentLoopData = $khachhang; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $index => $kh): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>
                                    <tr>
                                        <td><?php echo e($index + 1); ?></td>
                                        <td>
                                            <a class="text-decoration-none text-dark fw-semibold" href="<?php echo e(route('khachhang.show', $kh->id)); ?>">
                                                <?php echo e($kh->hoten); ?>

                                            </a>
                                        </td>
                                        <td><?php echo e($kh->sodienthoai); ?></td>
                                        <td><?php echo e($kh->email); ?></td>
                                        <td><?php echo e($kh->diachi); ?></td>
                                        <td>
                                            <?php if($kh->gioitinh == 'nam'): ?>
                                                Nam
                                            <?php elseif($kh->gioitinh == 'nữ'): ?>
                                                Nữ
                                            <?php else: ?>
                                                Khác
                                            <?php endif; ?>
                                        </td>
                                        <td><?php echo e($kh->so_don_hoanthanh ?? 0); ?> đơn</td>
                                        <td><?php echo e($kh->so_don_chuathanhtoan ?? 0); ?> đơn</td>
                                        <td><?php echo e($kh->donhangs_count ?? 0); ?> đơn</td> <!-- Sửa $tongDon thành $kh->donhangs_count -->
                                        <td><?php echo e(number_format($kh->tong_tien_dachi ?? 0, 0, ',', '.')); ?> đ</td>
                                        <td>
                                            <span class="badge <?php echo e($kh->trangthai == 1 ? 'bg-success' : 'bg-danger'); ?> px-2 py-1">
                                                <?php echo e($kh->trangthai == 1 ? 'Hoạt động' : 'Khóa'); ?>

                                            </span>
                                        </td>
                                        <td>
                                            <div class="d-flex align-items-center gap-2">
                                                <form action="<?php echo e(route('khachhang.lock', $kh->id)); ?>" method="POST" class="d-inline-block">
                                                    <?php echo csrf_field(); ?>
                                                    <button type="submit" class="btn btn-sm btn-success">
                                                        <i class="bi bi-pencil"></i> Cập nhật
                                                    </button>
                                                </form>

                                                <form id="form-xoa-<?php echo e($kh->id); ?>" action="<?php echo e(route('khachhang.destroy', $kh->id)); ?>" method="POST" class="d-inline-block" onsubmit="return false;">
                                                    <?php echo csrf_field(); ?>
                                                    <?php echo method_field('DELETE'); ?>
                                                    <button type="button" onclick="confirmXoaKhachHang(<?php echo e($kh->id); ?>, <?php echo e($kh->donhangs_count ?? 0); ?>)" class="btn btn-sm btn-danger">
                                                        <i class="bi bi-trash3"></i> Xóa
                                                    </button>
                                                </form>
                                            </div>
                                        </td>
                                    </tr>
                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>
                                    <tr>
                                        <td colspan="12" class="text-center text-muted py-4">
                                            <i class="bi bi-exclamation-circle me-2"></i> Không có dữ liệu khách hàng nào.
                                        </td>
                                    </tr>
                                <?php endif; ?>
                            </tbody>
                        </table>
                    </div>

                    <!-- Phân trang -->
                    <div class="mt-4">
                        <?php echo e($khachhang->appends(request()->query())->links('pagination::bootstrap-5')); ?>

                    </div>
                </div>
            </div>
        </div>
    </div>
</div>

<!-- Script SweetAlert2 -->
<script src="https://cdn.jsdelivr.net/npm/sweetalert2@11"></script>
<script>
    function confirmXoaKhachHang(id, donHangCount) { // Đổi tongDon thành donHangCount để nhất quán
        console.log('ID:', id, 'DonHangCount:', donHangCount); // Debug để kiểm tra giá trị
        if (donHangCount > 0) {
            Swal.fire({
                title: 'Khách hàng có đơn hàng',
                text: "Không thể xóa khách hàng này vì họ có đơn hàng. Bạn có muốn ngừng hoạt động tài khoản này không?",
                icon: 'warning',
                showCancelButton: true,
                confirmButtonText: 'Ngừng hoạt động',
                cancelButtonText: 'Hủy',
                confirmButtonColor: '#3085d6',
                cancelButtonColor: '#aaa',
            }).then((result) => {
                if (result.isConfirmed) {
                    document.getElementById('form-xoa-' + id).submit();
                }
            });
        } else {
            Swal.fire({
                title: 'Xóa khách hàng?',
                text: "Hành động này không thể hoàn tác!",
                icon: 'warning',
                showCancelButton: true,
                confirmButtonText: 'Xóa',
                cancelButtonText: 'Hủy',
                confirmButtonColor: '#d33',
                cancelButtonColor: '#3085d6',
            }).then((result) => {
                if (result.isConfirmed) {
                    document.getElementById('form-xoa-' + id).submit();
                }
            });
        }
    }
</script>

<!-- CSS tùy chỉnh -->
<style>
    .card {
        transition: transform 0.3s ease, box-shadow 0.3s ease;
    }
    .card:hover {
        transform: translateY(-5px);
        box-shadow: 0 10px 20px rgba(0, 0, 0, 0.1) !important;
    }
    .btn-sm {
        padding: 0.4rem 0.8rem;
    }
    .table th, .table td {
        vertical-align: middle;
    }
    .form-control:focus {
        border-color: #0d6efd;
        box-shadow: 0 0 5px rgba(13, 110, 253, 0.2);
    }
    .btn-group .btn {
        transition: all 0.3s ease;
    }
    .btn-group .btn:hover {
        background-color: #0d6efd;
        color: white;
    }
</style>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('admin.layout.layout', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\Users\admin\OneDrive - Đại học FPT- FPT University\Desktop\Duantotnghiep\TechViewShop\resources\views/admin/users/khachhang.blade.php ENDPATH**/ ?>