<?php $__env->startSection('title'); ?>
    Trạng thái thanh toán
<?php $__env->stopSection(); ?>

<?php $__env->startSection('body'); ?>
    <div class="success-content">
        <i class="fa-solid fa-check icon-pay-success"></i>
        <h2 class="btn-pay-title">Thanh toán thành công</h2>
        <p class="btn-pay-desc">Đơn hàng sẽ được chuẩn bị và chuyển đi trong thời gian sớm nhất</p>
        <div class="btn-pay-success">
            <a href="<?php echo e(route('account.profile')); ?>" class="btn-pay-success__link">Theo dõi đơn hàng</a>
        </div>
    </div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('client.layout.layout', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\Users\admin\OneDrive - Đại học FPT- FPT University\Desktop\Duantotnghiep\TechViewShop\resources\views/client/pages/payment/success.blade.php ENDPATH**/ ?>