
<?php $__env->startSection('title'); ?>
    Đăng kí
<?php $__env->stopSection(); ?>

<?php $__env->startSection('body'); ?>
<section class="section-register">
    <div class="grid wide container">
        <div class="row">
            <div class="register col l-6 l-o-3 m-10 m-o-1 c-12">
                <div class="register-title">
                    <a class="login__link auth-link" href="<?php echo e(route('account.login')); ?>">Đăng nhập</a>
                    <a class="register__link auth-link" href="<?php echo e(route('account.register')); ?>">Đăng kí</a>
                </div>

                <form class="register-form" method="post">
                    <?php echo csrf_field(); ?>
                    <div class="form-group">
                        <label class="label-reg" for="name">Họ tên<span class="required"></span>:</label>
                        <input class="input-field" type="text" name="name" id="name">
                    </div>
                    <?php $__errorArgs = ['name'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                        <div class="message"><?php echo e($message); ?></div>
                    <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>

                    <div class="form-group">
                        <label class="label-reg" for="email">Email<span class="required"></span>:</label>
                        <input class="input-field" type="email" name="email" id="email">
                    </div>
                    <?php $__errorArgs = ['email'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                        <div class="message"><?php echo e($message); ?></div>
                    <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>

                    <div class="form-group">
                        <label class="label-reg" for="password">Mật khẩu<span class="required"></span>:</label>
                        <div class="input-item">
                            <input class="input-field" type="password" name="password" id="password">
                            <i class="input-icon fa-regular fa-eye toggle-password" data-target="password"></i>
                        </div>
                    </div>
                    <?php $__errorArgs = ['password'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                        <div class="message"><?php echo e($message); ?></div>
                    <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                    <div class="form-group">
                        <label class="label-reg" for="confirm_password">Nhập lại mật khẩu<span class="required"></span>:</label>
                        <div class="input-item">
                            <input class="input-field" type="password" name="confirm_password" id="confirm_password">
                            <i class="input-icon fa-regular fa-eye toggle-password" data-target="confirm_password"></i>
                        </div>
                    </div>
                    <?php $__errorArgs = ['confirm_password'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                        <div class="message"><?php echo e($message); ?></div>
                    <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>

                    <?php if(session('error')): ?>
                        <div class="message">
                            <?php echo e(session('error')); ?>

                        </div>
                    <?php elseif(session('success')): ?> 
                        <div class="success">
                            <?php echo e(session('success')); ?>

                        </div>
                    <?php endif; ?>
                    
                    <button type="submit" class="btn-reg">ĐĂNG KÍ</button>
                </form>
            </div>
        </div>
    </div>
</section>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('client.layout.layout', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\Users\admin\OneDrive - Đại học FPT- FPT University\Desktop\Duantotnghiep\TechViewShop\resources\views/client/pages/register.blade.php ENDPATH**/ ?>