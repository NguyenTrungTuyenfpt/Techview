

<?php $__env->startSection('title', 'Thành viên'); ?>

<?php $__env->startSection('content'); ?>

<div class="container my-4">
    <?php if(session('success')): ?>
    <div class="alert alert-success">
        <?php echo e(session('success')); ?>

    </div>
    <?php endif; ?>
    <h2 class="mb-4">Chi tiết nhân viên</h2>
    <div class="row">
        <!-- Cột trái: Thông tin cá nhân -->
        <div class="col-md-4 mb-3">
            <div class="card">
                <div class="card-body text-center">
                    <img src="<?php echo e(asset('uploads/Users/' . $nhanvien->hinh) ?? 'https://via.placeholder.com/100'); ?>" class="rounded-circle mb-3 w-75" alt="Avatar">
                    <h5 class="card-title"><?php echo e($nhanvien->hoten); ?></h5>
                    <p class="text-muted mb-1"><i class="bi bi-envelope"></i> <?php echo e($nhanvien->email); ?></p>
                    <p class="text-muted mb-1"><i class="bi bi-telephone"></i> <?php echo e($nhanvien->sodienthoai ?? 'Chưa cập nhật'); ?></p>
                    <p class="text-muted mb-1">Vai trò:
                        <span class="badge bg-primary">
                            <?php if($nhanvien->phanquyen == 1): ?>
                            Quản trị
                            <?php elseif($nhanvien->phanquyen == 2): ?>
                            Cộng tác viên 1
                            <?php elseif($nhanvien->phanquyen == 3): ?>
                            Cộng tác viên 2
                            <?php else: ?>
                            Chưa cập nhật
                            <?php endif; ?>
                        </span>
                    </p>

                    <p class="text-muted mb-1">Trạng thái:
                        <span class="badge <?php echo e($nhanvien->trangthai ? 'bg-success' : 'bg-danger'); ?>">
                            <?php echo e($nhanvien->trangthai ? 'Hoạt động' : 'Khóa'); ?>

                        </span>
                    </p>
                    <p class="text-muted">Ngày tạo: <?php echo e($nhanvien->created_at->format('d/m/Y')); ?></p>
                    <!-- Nút khóa/mở tài khoản -->
                    <div class="d-grid gap-2 mt-3">
                        <button class="btn btn-<?php echo e($nhanvien->trangthai == 1 ? 'danger' : 'success'); ?> btn-sm" data-bs-toggle="modal" data-bs-target="#lockAccountModal">
                            <?php echo e($nhanvien->trangthai == 1 ? 'Khóa tài khoản' : 'Mở tài khoản'); ?>

                        </button>
                    </div>
                </div>
            </div>
        </div>

        <!-- Cột phải: Tabs chi tiết -->
        <div class="col-md-8">
            <ul class="nav nav-tabs mb-3" id="memberTab" role="tablist">
                <li class="nav-item" role="presentation">
                    <button class="nav-link active" id="role-tab" data-bs-toggle="tab" data-bs-target="#role" type="button" role="tab">Nhật ký hoạt động</button>
                </li>
                <li class="nav-item" role="presentation">
                    <button class="nav-link" id="activity-tab" data-bs-toggle="tab" data-bs-target="#activity" type="button" role="tab">Quyền hạn</button>
                </li>
            </ul>
            <div class="tab-content" id="memberTabContent">
                <!-- Nhật ký hoạt động -->
                <div class="tab-pane fade show active" id="role" role="tabpanel">
                    <ul class="list-group">
                        <?php $__empty_1 = true; $__currentLoopData = $activities; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $activity): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>
                        <li class="list-group-item">
                            <i class="bi <?php echo e($activity['icon']); ?> me-2 <?php echo e($activity['color']); ?>"></i><?php echo e($activity['message']); ?>

                        </li>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>
                        <li class="list-group-item">Chưa có hoạt động nào được ghi nhận.</li>
                        <?php endif; ?>
                    </ul>
                    <div class="mt-4">
                        <?php echo e($activities->appends(request()->query())->links('pagination::bootstrap-5')); ?>

                    </div>
                </div>

                <!-- Phân quyền -->
                <div class="tab-pane fade" id="activity" role="tabpanel">
                    <h5>
                        <p class="text-muted mb-1">Vai trò:
                            <span class="badge bg-primary">
                                <?php if($nhanvien->phanquyen == 1): ?>
                                Quản trị
                                <?php elseif($nhanvien->phanquyen == 2): ?>
                                Cộng tác viên 1
                                <?php elseif($nhanvien->phanquyen == 3): ?>
                                Cộng tác viên 2
                                <?php else: ?>
                                Chưa cập nhật
                                <?php endif; ?>
                            </span>
                        </p>
                    </h5>
                    <ul class="list-group list-group-flush mb-3">
                        <?php if($nhanvien->phanquyen == 1): ?>
                        <li class="list-group-item"><i class="bi bi-box-seam me-2 text-primary"></i>Quản lý sản phẩm</li>
                        <li class="list-group-item"><i class="bi bi-cart-check me-2 text-primary"></i>Quản lý đơn hàng</li>
                        <?php elseif($nhanvien->phanquyen == 2): ?>
                        <li class="list-group-item"><i class="bi bi-journal-text me-2 text-primary"></i>Quản lý bài viết</li>
                        <li class="list-group-item"><i class="bi bi-folder-plus me-2 text-primary"></i>Quản lý danh mục</li>
                        <?php elseif($nhanvien->phanquyen == 3): ?>
                        <li class="list-group-item"><i class="bi bi-gift me-2 text-primary"></i>Quản lý khuyến mãi</li>
                        <?php else: ?>
                        <li class="list-group-item">Chưa phân quyền cụ thể</li>
                        <?php endif; ?>
                    </ul>

                    <!-- Form chỉnh sửa quyền -->
                    <form action="<?php echo e(route('nhanvien.phanquyen', $nhanvien->id)); ?>" method="POST">
                        <?php echo csrf_field(); ?>
                        <?php echo method_field('PUT'); ?>

                        <div class="form-check">
                            <input class="form-check-input" type="radio" name="phanquyen" id="phanquyen1" value="1" <?php echo e($nhanvien->phanquyen == 1 ? 'checked' : ''); ?>>
                            <label class="form-check-label" for="phanquyen1">
                                Quản trị 1 (Quản lý tất cả)
                            </label>
                        </div>
                        <div class="form-check">
                            <input class="form-check-input" type="radio" name="phanquyen" id="phanquyen2" value="2" <?php echo e($nhanvien->phanquyen == 2 ? 'checked' : ''); ?>>
                            <label class="form-check-label" for="phanquyen2">
                                Cộng tác 1 (Quản lý bài viết và danh mục)
                            </label>
                        </div>
                        <div class="form-check">
                            <input class="form-check-input" type="radio" name="phanquyen" id="phanquyen3" value="3" <?php echo e($nhanvien->phanquyen == 3 ? 'checked' : ''); ?>>
                            <label class="form-check-label" for="phanquyen3">
                                Cộng tác 2 (Quản lý khuyến mãi)
                            </label>
                        </div>

                        <button type="submit" class="btn btn-primary mt-3">Cập nhật quyền hạn</button>
                    </form>
                </div>
            </div>

        </div>
    </div>
</div>


<!-- Modal: Khóa / Mở tài khoản -->
<div class="modal fade" id="lockAccountModal" tabindex="-1" aria-labelledby="lockAccountModalLabel" aria-hidden="true">
    <div class="modal-dialog">
        <div class="modal-content">
            <div class="modal-header">
                <h5 class="modal-title" id="lockAccountModalLabel"><?php echo e($nhanvien->trangthai == 1 ? 'Khóa tài khoản' : 'Mở tài khoản'); ?></h5>
                <button type="button" class="btn-close" data-bs-dismiss="modal" aria-label="Close"></button>
            </div>
            <div class="modal-body">
                Bạn có chắc chắn muốn <?php echo e($nhanvien->trangthai == 1 ? 'khóa' : 'mở'); ?> tài khoản của <strong><?php echo e($nhanvien->hoten); ?></strong>?
            </div>
            <div class="modal-footer">
                <form action="<?php echo e(route('nhanvien.lock', $nhanvien->id)); ?>" method="POST">
                    <?php echo csrf_field(); ?>
                    <?php echo method_field('PUT'); ?>
                    <button type="button" class="btn btn-secondary" data-bs-dismiss="modal">Hủy</button>
                    <button type="submit" class="btn btn-<?php echo e($nhanvien->trangthai == 1 ? 'danger' : 'success'); ?>">
                        <?php echo e($nhanvien->trangthai == 1 ? 'Khóa tài khoản' : 'Mở tài khoản'); ?>

                    </button>
                </form>
            </div>
        </div>
    </div>
</div>



<script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.3/dist/js/bootstrap.bundle.min.js"></script>



<?php $__env->stopSection(); ?>
<?php echo $__env->make('admin.layout.layout', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\Users\admin\OneDrive - Đại học FPT- FPT University\Desktop\Duantotnghiep\TechViewShop\resources\views/admin/users/chitiettaikhoan_nhanvien.blade.php ENDPATH**/ ?>