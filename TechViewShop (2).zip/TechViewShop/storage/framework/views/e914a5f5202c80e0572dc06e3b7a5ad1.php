

<?php $__env->startSection('title', 'Sửa Khuyến Mãi'); ?>

<?php $__env->startSection('content'); ?>
<!-- Nội dung chính của trang sẽ nằm ở đây -->

<p><a href="/">Trang chủ</a> / <span class="text-primary">Sửa khuyến mãi </span></p>

<form action="<?php echo e(route('khuyenmai.update', $khuyenmai->id)); ?>" method="POST" enctype="multipart/form-data">
    <?php echo csrf_field(); ?>
    <?php echo method_field('PUT'); ?>

    <?php if($errors->any()): ?>
    <div class="alert alert-danger">
        <ul>
            <?php $__currentLoopData = $errors->all(); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $error): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                <li><?php echo e($error); ?></li>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
        </ul>
    </div>
<?php endif; ?>

    
    <div class="add-product">
        <div class="row">
            <!-- Thông tin sản phẩm -->
            <div class="col-md-12">
                <div class="border rounded p-3">
                    <h5 class="fw-bold">Thông tin </h5>
                    <div class="row">
                        <!-- Tên sản phẩm -->
                        <div class="col-md-4 mt-3">
                            <label class="form-label">Mã </label>
                            <input type="text" name="makm" class="form-control" value="<?php echo e($khuyenmai->makm); ?>" required>
                        </div>

                        <!-- Giá sản phẩm -->
                        <div class="col-md-4 mt-3">
                            <label class="form-label">Mo ta</label>
                            <input type="text" name="mota" class="form-control" value="<?php echo e($khuyenmai->mota); ?>" required>
                        </div>

                        <!-- Giá khuyến mãi -->
                        <div class="col-md-4 mt-3">
                            <label class="form-label">Ngay bat dau</label>
                            <input type="date" name="ngaybatdau" class="form-control" value="<?php echo e($khuyenmai->ngaybatdau); ?>">
                        </div>

                        <!-- Mô tả -->
                        <div class="col-md-4 mt-3">
                            <label class="form-label">Ngay ket thuc</label>
                            <input type="date" name="ngayketthuc" class="form-control" value="<?php echo e($khuyenmai->ngayketthuc); ?>">
                        </div>

                       

                        <!-- Mã combo -->
                        <div class="col-md-4 mt-3">
                            <label class="form-label">He so giam gia</label>
                            <input type="number" name="hesogiamgia" class="form-control" value="<?php echo e($khuyenmai->hesogiamgia); ?>">
                        </div>

                        <!-- Số lượng -->
                        <div class="col-md-4 mt-3">
                            <label class="form-label">Gia tri DH toi thieu</label>
                            <input type="number" name="sotientoithieu" class="form-control" value="<?php echo e($khuyenmai->sotientoithieu); ?>">
                           
                        </div>

                         <!-- Số lượng -->
                         <div class="col-md-4 mt-3">
                            <label class="form-label">Gioi han su dung</label>
                            <input type="number" name="gioihan" class="form-control" value="<?php echo e($khuyenmai->gioihan); ?>">
                           
                        </div>

                         <!-- Số lượng -->
                         <div class="col-md-4 mt-3">
                            <label class="form-label">So tien giam toi thieu</label>
                            <input type="number" name="sotiengiamtoida" class="form-control" value="<?php echo e($khuyenmai->sotiengiamtoida); ?>">
                        </div>

                        <!-- Trạng thái hiển thị -->
                        <div class="col-md-4 mt-3">
                            <label class="form-label d-block">Trạng thái </label>
                            <div class="form-check form-check-inline">
                                <input class="form-check-input" type="radio" name="hoatdong" value="1"
                                    <?php echo e($khuyenmai->hoatdong == 1 ? 'checked' : ''); ?>>
                                <label class="form-check-label">Hiển thị</label>
                            </div>
                            <div class="form-check form-check-inline">
                                <input class="form-check-input" type="radio" name="hoatdong" value="0"
                                    <?php echo e($khuyenmai->hoatdong == 0 ? 'checked' : ''); ?>>
                                <label class="form-check-label">Ẩn</label>
                            </div>

                            
                        </div>
                    </div>
                </div>
            </div>
        </div>

      

        <!-- Buttons -->
        <div class="d-flex justify-content-end mt-4">
            <button type="submit" class="btn btn-primary me-2">Cập nhật </button>
            <a href="<?php echo e(route('khuyenmai')); ?>" class="btn btn-danger">Hủy</a>
        </div>
    </div>
</form>





<?php if(session('popup')): ?>
<script>
    window.onload = function() {
        if (confirm("<?php echo e(session('message')); ?>")) {
            window.location.href = "<?php echo e(route('khuyenmai')); ?>";
        }
    };
</script>
<?php endif; ?>

</div>
</div>

<?php $__env->stopSection(); ?>
<?php echo $__env->make('admin.layout.layout', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\Users\admin\OneDrive - Đại học FPT- FPT University\Desktop\Duantotnghiep\TechViewShop\resources\views/admin/khuyenmai/suakhuyenmai.blade.php ENDPATH**/ ?>