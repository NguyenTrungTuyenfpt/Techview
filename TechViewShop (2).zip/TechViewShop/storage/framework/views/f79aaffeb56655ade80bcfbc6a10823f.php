

<?php $__env->startSection('title', 'Sửa bài viết'); ?>

<?php $__env->startSection('content'); ?>
<div class="container mt-3 mb-3">
    <div class="row justify-content-center">
        <div class="col-lg-11">
            <!-- Header -->
            <div class="d-flex justify-content-between align-items-center mb-4">
                <h2 class="fw-bold text-primary">Sửa bài viết</h2>
                <a href="<?php echo e(route('baiviet')); ?>" class="btn btn-outline-secondary">
                    <i class="bi bi-arrow-left"></i> Quay lại
                </a>
            </div>

            <!-- Card chính -->
            <div class="card border-0 shadow-lg rounded-3">
                <div class="card-body p-4">
                    <form action="<?php echo e(route('baiviet.update', $baiViet->id)); ?>" method="POST" enctype="multipart/form-data">
                        <?php echo csrf_field(); ?>
                        <?php echo method_field('PUT'); ?>

                        <!-- Tiêu đề -->
                        <div class="mb-3">
                            <label for="tieude" class="form-label fw-semibold">Tiêu đề</label>
                            <input type="text" name="tieude" id="tieude" class="form-control" value="<?php echo e(old('tieude', $baiViet->tieude)); ?>" required>
                            <?php $__errorArgs = ['tieude'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                <span class="text-danger"><?php echo e($message); ?></span>
                            <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                        </div>

                        <!-- Danh mục -->
                        <div class="mb-3">
                            <label for="id_danhmuc" class="form-label fw-semibold">Danh mục</label>
                            <select name="id_danhmuc" id="id_danhmuc" class="form-select" required>
                                <option value="">Chọn danh mục</option>
                                <?php $__currentLoopData = $danhMucs; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $dm): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                    <option value="<?php echo e($dm->id); ?>" <?php echo e(old('id_danhmuc', $baiViet->id_danhmuc) == $dm->id ? 'selected' : ''); ?>>
                                        <?php echo e($dm->tendm); ?>

                                    </option>
                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                            </select>
                            <?php $__errorArgs = ['id_danhmuc'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                <span class="text-danger"><?php echo e($message); ?></span>
                            <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                        </div>

                        <!-- Nội dung -->
                        <div class="mb-3">
                            <label for="noidung" class="form-label fw-semibold">Nội dung</label>
                            <textarea name="noidung" id="noidung" class="form-control" rows="5"><?php echo e(old('noidung', $baiViet->noidung)); ?></textarea>
                            <?php $__errorArgs = ['noidung'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                <span class="text-danger"><?php echo e($message); ?></span>
                            <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                        </div>

                        <!-- Hình ảnh -->
                        <div class="mb-3">
                            <label for="hinh" class="form-label fw-semibold">Hình ảnh</label>
                            <?php if($baiViet->hinh): ?>
                                <div class="mb-2">
                                <img src="<?php echo e(asset('uploads/baiviet/' . $baiViet->hinh)); ?>" alt="Hình ảnh bài viết" class="img-thumbnail" style="max-width: 150px;">

                                </div>
                            <?php endif; ?>
                            <input type="file" name="hinh" id="hinh" class="form-control">
                            <?php $__errorArgs = ['hinh'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                <span class="text-danger"><?php echo e($message); ?></span>
                            <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                        </div>

                        <!-- Ẩn/Hiện -->
                        <div class="mb-3">
                            <label class="form-label fw-semibold">Trạng thái</label>
                            <div class="form-check">
                                <input type="checkbox" name="anhien" id="anhien" class="form-check-input" value="1" <?php echo e(old('anhien', $baiViet->anhien) ? 'checked' : ''); ?>>
                                <label for="anhien" class="form-check-label">Hiển thị</label>
                            </div>
                        </div>

                        <!-- Nút submit -->
                        <button type="submit" class="btn btn-primary w-100">Cập nhật bài viết</button>
                    </form>
                </div>
            </div>
        </div>
    </div>
</div>

<style>
    .card {
        transition: transform 0.3s ease, box-shadow 0.3s ease;
    }
    .card:hover {
        transform: translateY(-5px);
        box-shadow: 0 10px 20px rgba(0, 0, 0, 0.1) !important;
    }
    .form-control:focus, .form-select:focus {
        border-color: #0d6efd;
        box-shadow: 0 0 5px rgba(13, 110, 253, 0.2);
    }
</style>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('admin.layout.layout', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\Users\admin\OneDrive - Đại học FPT- FPT University\Desktop\Duantotnghiep\TechViewShop\resources\views/admin/baiviet/sua.blade.php ENDPATH**/ ?>