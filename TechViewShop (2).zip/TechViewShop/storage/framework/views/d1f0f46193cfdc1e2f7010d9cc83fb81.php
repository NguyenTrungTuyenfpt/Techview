

<?php $__env->startSection('title', 'Doanh thu'); ?>

<?php $__env->startSection('content'); ?>
            <!-- Nội dung chính của trang sẽ nằm ở đây -->
            <div class="container">
                <div class="revenue-section">
                    <h2>Quản lý doanh thu</h2>
                
                    <!-- Tổng quan doanh thu -->
                    <div class="revenue-summary">
                        <div class="summary-card">
                            <span class="icon bg-light-blue"><i class="bi bi-currency-dollar"></i></span>
                            <div>
                                <h4>Doanh thu</h4>
                                <p>50,000,000 VNĐ</p>
                            </div>
                        </div>
                
                        <div class="summary-card">
                            <span class="icon bg-light-green"><i class="bi bi-bag-check"></i></span>
                            <div>
                                <h4>Đơn hàng</h4>
                                <p>320</p>
                            </div>
                        </div>
                
                        <div class="summary-card">
                            <span class="icon bg-light-yellow"><i class="bi bi-graph-up"></i></span>
                            <div>
                                <h4>Lợi nhuận</h4>
                                <p>15,000,000 VNĐ</p>
                            </div>
                        </div>
                    </div>
                
                    <!-- Bảng thống kê doanh thu -->
                    <table class="revenue-table">
                        <thead>
                            <tr>
                                <th>Tháng</th>
                                <th>Doanh thu (VNĐ)</th>
                                <th>Đơn hàng</th>
                                <th>Lợi nhuận (VNĐ)</th>
                            </tr>
                        </thead>
                        <tbody>
                            <tr>
                                <td>Tháng 1</td>
                                <td>10,000,000</td>
                                <td>120</td>
                                <td>3,500,000</td>
                            </tr>
                            <tr>
                                <td>Tháng 2</td>
                                <td>15,000,000</td>
                                <td>140</td>
                                <td>4,500,000</td>
                            </tr>
                            <tr>
                                <td>Tháng 3</td>
                                <td>25,000,000</td>
                                <td>200</td>
                                <td>7,000,000</td>
                            </tr>
                        </tbody>
                    </table>
                </div>
                <div class="invoice-section">
                    <h2>Quản lý Hóa Đơn</h2>
                
                    <!-- Bảng danh sách đơn hàng -->
                    <table class="invoice-table">
                        <thead>
                            <tr>
                                <th>Mã đơn</th>
                                <th>Khách hàng</th>
                                <th>Ngày đặt</th>
                                <th>Tổng tiền</th>
                                <th>Trạng thái</th>
                                <th>Xuất hóa đơn</th>
                            </tr>
                        </thead>
                        <tbody>
                            <tr>
                                <td>#10234</td>
                                <td>Nguyễn Văn A</td>
                                <td>12/03/2025</td>
                                <td>2,500,000 VNĐ</td>
                                <td>Đã thanh toán</td>
                                <td><button class="btn-export" onclick="exportInvoice('#10234')">Xuất</button></td>
                            </tr>
                            <tr>
                                <td>#10235</td>
                                <td>Trần Thị B</td>
                                <td>14/03/2025</td>
                                <td>1,200,000 VNĐ</td>
                                <td>Đã thanh toán</td>
                                <td><button class="btn-export" onclick="exportInvoice('#10235')">Xuất</button></td>
                            </tr>
                        </tbody>
                    </table>
                </div>
                
                <!-- Khu vực in hóa đơn (ẩn) -->
                <div id="invoice-print" style="display: none;">
                    <h2>Hóa đơn</h2>
                    <p>Mã đơn: <span id="invoice-id"></span></p>
                    <p>Khách hàng: <span id="invoice-customer"></span></p>
                    <p>Ngày đặt: <span id="invoice-date"></span></p>
                    <p>Tổng tiền: <span id="invoice-total"></span></p>
                    <button onclick="printInvoice()">In hóa đơn</button>
                </div>
                
            </div>
        </div>
    </div>
  
    <?php $__env->stopSection(); ?>
<?php echo $__env->make('admin.layout.layout', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\Users\admin\OneDrive - Đại học FPT- FPT University\Desktop\Duantotnghiep\TechViewShop\resources\views/admin/doanhthu/doanhthu.blade.php ENDPATH**/ ?>