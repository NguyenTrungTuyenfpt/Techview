

<?php $__env->startSection('title', 'Sửa sản phẩm'); ?>

<?php $__env->startSection('content'); ?>
<div class="container mt-5">
    <div class="row justify-content-center">
        <div class="col-lg-12">
            <!-- Breadcrumb -->
            <nav aria-label="breadcrumb" class="mb-4">
                <ol class="breadcrumb">
                    <li class="breadcrumb-item"><a href="/" class="text-muted text-decoration-none">Trang chủ</a></li>
                    <li class="breadcrumb-item active text-primary" aria-current="page">Sửa sản phẩm</li>
                </ol>
            </nav>

            <!-- Card chính -->
            <div class="card border-0 shadow-lg rounded-3">
                <div class="card-header bg-primary text-white p-4 rounded-top">
                    <h2 class="mb-0">Sửa sản phẩm: <?php echo e($sanpham->tensp); ?></h2>
                </div>
                <div class="card-body p-4">
                    <!-- Hiển thị thông báo lỗi -->
                    <?php if($errors->any()): ?>
                    <div class="alert alert-danger alert-dismissible fade show" role="alert">
                        <ul class="mb-0">
                            <?php $__currentLoopData = $errors->all(); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $error): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                            <li><?php echo e($error); ?></li>
                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                        </ul>
                        <button type="button" class="btn-close" data-bs-dismiss="alert" aria-label="Close"></button>
                    </div>
                    <?php endif; ?>

                    <!-- Form chỉnh sửa -->
                    <form action="<?php echo e(route('sanpham.update', $sanpham->id)); ?>" method="POST" enctype="multipart/form-data">
                        <?php echo csrf_field(); ?>
                        <?php echo method_field('PUT'); ?>

                        <!-- Thông tin sản phẩm -->
                        <div class="mb-4">
                            <h5 class="text-primary mb-3">Thông tin sản phẩm</h5>
                            <div class="p-3 bg-light rounded">
                                <div class="row">
                                    <!-- Tên sản phẩm -->
                                    <div class="col-md-4 mb-3">
                                        <label for="tensp" class="form-label fw-semibold">Tên sản phẩm <span class="text-danger">*</span></label>
                                        <input type="text" name="tensp" id="tensp" class="form-control" value="<?php echo e(old('tensp', $sanpham->tensp)); ?>" required>
                                        <?php $__errorArgs = ['tensp'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                        <small class="text-danger"><?php echo e($message); ?></small>
                                        <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                                    </div>

                                    <!-- Giá sản phẩm -->
                                    <div class="col-md-4 mb-3">
                                        <label for="gia" class="form-label fw-semibold">Giá sản phẩm <span class="text-danger">*</span></label>
                                        <input type="number" name="gia" id="gia" class="form-control" value="<?php echo e(old('gia', $sanpham->gia)); ?>" required>
                                        <?php $__errorArgs = ['gia'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                        <small class="text-danger"><?php echo e($message); ?></small>
                                        <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                                    </div>

                                    <!-- Giá khuyến mãi -->
                                    <div class="col-md-4 mb-3">
                                        <label for="giamgia" class="form-label fw-semibold">% Khuyến mãi</label>
                                        <input type="number" name="giamgia" id="giamgia" class="form-control" value="<?php echo e(old('giamgia', $sanpham->giamgia)); ?>">
                                        <?php $__errorArgs = ['giamgia'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                        <small class="text-danger"><?php echo e($message); ?></small>
                                        <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                                    </div>

                                    <!-- Mô tả -->
                                    <div class="col-md-4 mb-3">
                                        <label for="mota" class="form-label fw-semibold">Mô tả</label>
                                        <textarea name="mota" id="mota" class="form-control" rows="3"><?php echo e(old('mota', $sanpham->mota)); ?></textarea>
                                        <?php $__errorArgs = ['mota'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                        <small class="text-danger"><?php echo e($message); ?></small>
                                        <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                                    </div>

                                    <!-- Danh mục -->
                                    <div class="col-md-4 mb-3">
                                        <label for="id_danhmuc" class="form-label fw-semibold">Danh mục</label>
                                        <select name="id_danhmuc" id="id_danhmuc" class="form-select">
                                            <?php $__currentLoopData = $danhmuc; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $dm): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                            <option value="<?php echo e($dm->id); ?>" <?php echo e(old('id_danhmuc', $sanpham->id_danhmuc) == $dm->id ? 'selected' : ''); ?>>
                                                <?php echo e($dm->tendm); ?>

                                            </option>
                                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                        </select>
                                        <?php $__errorArgs = ['id_danhmuc'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                        <small class="text-danger"><?php echo e($message); ?></small>
                                        <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                                    </div>

                                    <!-- Nhà cung cấp -->
                                    <div class="col-md-4 mb-3">
                                        <label for="id_nhacungcap" class="form-label fw-semibold">Nhà cung cấp</label>
                                        <select name="id_nhacungcap" id="id_nhacungcap" class="form-select">
                                            <?php $__currentLoopData = $nhacungcap; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $cc): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                            <option value="<?php echo e($cc->id); ?>" <?php echo e(old('id_nhacungcap', $sanpham->id_nhacungcap) == $cc->id ? 'selected' : ''); ?>>
                                                <?php echo e($cc->ten_ncc); ?>

                                            </option>
                                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                        </select>
                                        <?php $__errorArgs = ['id_nhacungcap'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                        <small class="text-danger"><?php echo e($message); ?></small>
                                        <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                                    </div>

                                    <!-- Thương hiệu -->
                                    <div class="col-md-4 mb-3">
                                        <label for="thuonghieu" class="form-label fw-semibold">Thương hiệu</label>
                                        <input type="text" name="thuonghieu" id="thuonghieu" class="form-control" value="<?php echo e(old('thuonghieu', $sanpham->thuonghieu)); ?>">
                                        <?php $__errorArgs = ['thuonghieu'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                        <small class="text-danger"><?php echo e($message); ?></small>
                                        <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                                    </div>

                                    <!-- Số lượng -->
                                    <div class="col-md-4 mb-3">
                                        <label for="soluong" class="form-label fw-semibold">Số lượng</label>
                                        <input type="number" name="soluong" id="soluong" class="form-control" value="<?php echo e(old('soluong', $sanpham->soluong)); ?>">
                                        <?php $__errorArgs = ['soluong'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                        <small class="text-danger"><?php echo e($message); ?></small>
                                        <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                                    </div>

                                    <div class="col-md-4 mt-3">
                                        <label class="form-label">Tên thông số sản phẩm</label>
                                        <input type="text" name="tenthongso" class="form-control" placeholder="Nhập tại đây" >
                                    </div>
                                    <div class="col-md-4 mt-3">
                                        <label class="form-label">Giá trị thông số của sản phẩm</label>
                                        <input type="text" name="giatrithongso" class="form-control" placeholder="Nhập tại đây">
                                    </div>

                                    <!-- Trạng thái hiển thị và nổi bật -->
                                    <div class="col-md-4 mb-3">
                                        <label class="form-label fw-semibold">Trạng thái hiển thị</label>
                                        <div class="d-flex mb-3">
                                            <div class="form-check me-3">
                                                <input class="form-check-input" type="radio" name="anhien" id="anhien1" value="1" <?php echo e(old('anhien', $sanpham->anhien) == 1 ? 'checked' : ''); ?>>
                                                <label class="form-check-label" for="anhien1">Hiển thị</label>
                                            </div>
                                            <div class="form-check">
                                                <input class="form-check-input" type="radio" name="anhien" id="anhien0" value="0" <?php echo e(old('anhien', $sanpham->anhien) == 0 ? 'checked' : ''); ?>>
                                                <label class="form-check-label" for="anhien0">Ẩn</label>
                                            </div>
                                        </div>
                                        <?php $__errorArgs = ['anhien'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                        <small class="text-danger"><?php echo e($message); ?></small>
                                        <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>

                                        <label class="form-label fw-semibold">Trạng thái nổi bật</label>
                                        <div class="d-flex">
                                            <div class="form-check me-3">
                                                <input class="form-check-input" type="radio" name="noibat" id="noibat1" value="1" <?php echo e(old('noibat', $sanpham->noibat) == 1 ? 'checked' : ''); ?>>
                                                <label class="form-check-label" for="noibat1">Nổi bật</label>
                                            </div>
                                            <div class="form-check">
                                                <input class="form-check-input" type="radio" name="noibat" id="noibat0" value="0" <?php echo e(old('noibat', $sanpham->noibat) == 0 ? 'checked' : ''); ?>>
                                                <label class="form-check-label" for="noibat0">Không nổi bật</label>
                                            </div>
                                        </div>
                                        <?php $__errorArgs = ['noibat'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                        <small class="text-danger"><?php echo e($message); ?></small>
                                        <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                                    </div>
                                </div>
                            </div>
                        </div>

                        <!-- Ảnh chính -->
                        <div class="mb-4">
                            <h5 class="text-primary mb-3">Ảnh chính</h5>
                            <div class="p-3 bg-light rounded text-center">
                                <?php if($sanpham->hinh): ?>
                                <img src="<?php echo e(asset('uploads/sanpham/' . $sanpham->hinh)); ?>"
                                    class="img-fluid rounded shadow-sm border mb-3"
                                    style="max-height: 150px; object-fit: cover;"
                                    alt="Ảnh chính hiện tại">
                                <p class="text-muted mb-2">Ảnh chính hiện tại</p>
                                <?php else: ?>
                                <div class="bg-white rounded p-3 border mb-3" style="width: 150px; height: 150px; margin: 0 auto;">
                                    <i class="bi bi-image text-muted" style="font-size: 2rem;"></i>
                                    <p class="text-muted mt-2 small">Chưa có ảnh chính</p>
                                </div>
                                <?php endif; ?>
                                <label for="anhchinh" class="form-label fw-semibold">Chọn ảnh mới (nếu muốn thay đổi)</label>
                                <input type="file" name="anhchinh" id="anhchinh" class="form-control w-50 mx-auto">
                                <?php $__errorArgs = ['anhchinh'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                <small class="text-danger"><?php echo e($message); ?></small>
                                <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                            </div>
                        </div>

                        <!-- Ảnh phụ hiện tại -->
                        <div class="mb-4">
                            <h5 class="text-primary mb-3">Ảnh phụ hiện tại</h5>
                            <div class="p-3 bg-light rounded">
                                <?php if(count($sanpham->anhsanpham) > 0): ?>
                                <div class="row">
                                    <?php $__currentLoopData = $sanpham->anhsanpham; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $anh): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                    <div class="col-md-3 col-sm-6 mb-3 text-center">
                                        <img src="<?php echo e(asset('uploads/sanpham/' . $anh->src)); ?>"
                                            class="img-fluid rounded shadow-sm border"
                                            style="max-height: 120px; object-fit: cover;"
                                            alt="Ảnh phụ">
                                        <div class="form-check mt-2">
                                            <input class="form-check-input" type="checkbox" name="xoa_anhphu[]" id="xoa_anhphu_<?php echo e($anh->id); ?>" value="<?php echo e($anh->id); ?>">
                                            <label class="form-check-label" for="xoa_anhphu_<?php echo e($anh->id); ?>">Xóa ảnh này</label>
                                        </div>
                                    </div>
                                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                </div>
                                <?php else: ?>
                                <div class="alert alert-info text-center" role="alert">
                                    <i class="bi bi-info-circle me-2"></i> Không có ảnh phụ nào.
                                </div>
                                <?php endif; ?>
                            </div>
                        </div>

                        <!-- Thêm ảnh phụ mới -->
                        <div class="mb-4">
                            <h5 class="text-primary mb-3">Thêm ảnh phụ mới</h5>
                            <div class="p-3 bg-light rounded">
                                <label for="anhphu" class="form-label fw-semibold">Chọn ảnh phụ mới (có thể chọn nhiều ảnh)</label>
                                <input type="file" name="anhphu[]" id="anhphu" class="form-control w-50" multiple>
                                <?php $__errorArgs = ['anhphu.*'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                <small class="text-danger"><?php echo e($message); ?></small>
                                <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                            </div>
                        </div>

                        <!-- Nút hành động -->
                        <div class="text-end">
                            <button type="submit" class="btn btn-success me-2">
                                <i class="bi bi-check-circle"></i> Cập nhật sản phẩm
                            </button>
                            <a href="<?php echo e(route('sanpham')); ?>" class="btn btn-outline-danger">
                                <i class="bi bi-x-circle"></i> Hủy
                            </a>
                        </div>
                    </form>
                </div>
            </div>
        </div>
    </div>
</div>

<?php if(session('popup')): ?>
<script>
    window.onload = function() {
        if (confirm("<?php echo e(session('message')); ?>")) {
            window.location.href = "<?php echo e(route('sanpham')); ?>";
        }
    };
</script>
<?php endif; ?>

<style>
    .card {
        transition: transform 0.3s ease, box-shadow 0.3s ease;
    }

    .card:hover {
        transform: translateY(-5px);
        box-shadow: 0 10px 20px rgba(0, 0, 0, 0.1) !important;
    }

    .form-control,
    .form-select {
        transition: border-color 0.3s ease;
    }

    .form-control:focus,
    .form-select:focus {
        border-color: #0d6efd;
        box-shadow: 0 0 5px rgba(13, 110, 253, 0.2);
    }

    .img-fluid {
        transition: transform 0.3s ease;
    }

    .img-fluid:hover {
        transform: scale(1.05);
    }
</style>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('admin.layout.layout', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\Users\admin\OneDrive - Đại học FPT- FPT University\Desktop\Duantotnghiep\TechViewShop\resources\views/admin/sanpham/suasanpham.blade.php ENDPATH**/ ?>