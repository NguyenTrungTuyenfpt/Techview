

<?php $__env->startSection('title', 'Chi tiết sản phẩm'); ?>

<?php $__env->startSection('content'); ?>
<div class="container mt-5">
    <div class="row justify-content-center">
        <div class="col-lg-12">
            <!-- Breadcrumb -->
            <nav aria-label="breadcrumb" class="mb-4">
                <ol class="breadcrumb">
                    <li class="breadcrumb-item"><a href="/" class="text-muted text-decoration-none">Trang chủ</a></li>
                    <li class="breadcrumb-item active text-primary" aria-current="page">Chi tiết sản phẩm</li>
                </ol>
            </nav>

            <!-- Card chính -->
            <div class="card border-0 shadow-lg rounded-3">
                <div class="card-header bg-primary text-white p-4 rounded-top">
                    <h2 class="mb-0">Sản phẩm: <?php echo e($sanpham->tensp); ?></h2>
                </div>
                <div class="card-body p-4">
                    <!-- Thông tin sản phẩm -->
                    <div class="row mb-4">
                        <div class="col-md-4 mb-3">
                            <div class="text-center">
                                <img src="<?php echo e(asset('uploads/sanpham/' . $sanpham->hinh)); ?>"
                                     class="img-fluid rounded shadow-sm border"
                                     alt="<?php echo e($sanpham->tensp); ?>"
                                     style="max-height: 300px; object-fit: cover;">
                            </div>
                        </div>
                        <div class="col-md-8">
                            <div class="p-3 bg-light rounded">
                                <h5 class="text-muted mb-3">Thông tin cơ bản</h5>
                                <div class="row">
                                    <div class="col-md-6">
                                        <ul class="list-unstyled">
                                            <li class="mb-2">
                                                <strong class="text-dark">Giá gốc:</strong>
                                                <span class="text-secondary fw-bold"><?php echo e(number_format($sanpham->gia)); ?> VNĐ</span>
                                            </li>
                                            <li class="mb-2">
                                                <strong class="text-dark">Giá bán:</strong>
                                                <span class="text-danger fw-bold"><?php echo e(number_format($sanpham->gia * (1 - $sanpham->giamgia / 100))); ?> VNĐ</span>
                                            </li>
                                            <li class="mb-2">
                                                <strong class="text-dark">Khuyến mãi:</strong>
                                                <span class="text-success fw-bold"><?php echo e(number_format($sanpham->giamgia)); ?>%</span>
                                            </li>
                                            <li class="mb-2">
                                                <strong class="text-dark">Số lượng còn lại:</strong>
                                                <span><?php echo e($sanpham->soluong); ?></span>
                                            </li>
                                            <li class="mb-2">
                                                <strong class="text-dark">Đã bán:</strong>
                                                <span class="text-muted"><?php echo e($sanpham->da_ban ?? 0); ?></span>
                                            </li>
                                        </ul>
                                    </div>
                                    <div class="col-md-6">
                                        <ul class="list-unstyled">
                                            <li class="mb-2">
                                                <strong class="text-dark">Danh mục:</strong>
                                                <span><?php echo e($sanpham->danhmuc->tendm); ?></span>
                                            </li>
                                            <li class="mb-2">
                                                <strong class="text-dark">Nhà cung cấp:</strong>
                                                <span><?php echo e($sanpham->nhacungcap ? $sanpham->nhacungcap->tenncc : 'Chưa cập nhật'); ?></span>
                                            </li>
                                            <li class="mb-2">
                                                <strong class="text-dark">Trạng thái:</strong>
                                                <?php if($sanpham->trangthai == 1): ?>
                                                    <span class="badge bg-success px-2 py-1">Đang hiển thị</span>
                                                <?php else: ?>
                                                    <span class="badge bg-secondary px-2 py-1">Đang ẩn</span>
                                                <?php endif; ?>
                                            </li>
                                            <li class="mb-2">
                                                <strong class="text-dark">Nổi bật:</strong>
                                                <?php if($sanpham->noibat == 1): ?>
                                                    <span class="badge bg-warning text-dark px-2 py-1">Nổi bật</span>
                                                <?php else: ?>
                                                    <span class="text-muted">Không</span>
                                                <?php endif; ?>
                                            </li>
                                            <li class="mb-2">
                                                <strong class="text-dark">Slug:</strong>
                                                <span><?php echo e($sanpham->slug); ?></span>
                                            </li>
                                        </ul>
                                    </div>
                                </div>
                            </div>
                        </div>
                    </div>

                    <!-- Mô tả sản phẩm -->
                    <div class="mb-4">
                        <h5 class="text-primary mb-3">Mô tả sản phẩm</h5>
                        <div class="p-3 bg-light rounded text-muted">
                            <?php echo nl2br(e($sanpham->mota)); ?>

                        </div>
                    </div>

                    <!-- Thời gian -->
                    <div class="mb-4">
                        <h5 class="text-primary mb-3">Thông tin thời gian</h5>
                        <div class="p-3 bg-light rounded">
                            <div class="row">
                                <div class="col-md-6">
                                    <p><strong class="text-dark">Ngày tạo:</strong> <?php echo e($sanpham->created_at->format('d/m/Y H:i')); ?></p>
                                </div>
                                <div class="col-md-6">
                                    <p><strong class="text-dark">Cập nhật:</strong> <?php echo e($sanpham->updated_at->format('d/m/Y H:i')); ?></p>
                                </div>
                            </div>
                        </div>
                    </div>

                    <!-- Ảnh phụ -->
                    <div class="mb-4">
                        <h5 class="text-primary mb-3">Ảnh phụ hiện tại</h5>
                        <div class="p-3 bg-light rounded">
                            <?php if(count($sanpham->anhsanpham) > 0): ?>
                                <div class="row">
                                    <?php $__currentLoopData = $sanpham->anhsanpham; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $anh): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                        <div class="col-md-3 col-sm-6 mb-3 text-center">
                                            <img src="<?php echo e(asset('uploads/sanpham/' . $anh->src)); ?>"
                                                 class="img-fluid rounded shadow-sm border"
                                                 style="max-height: 120px; object-fit: cover;"
                                                 alt="Ảnh phụ">
                                        </div>
                                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                </div>
                            <?php else: ?>
                                <div class="alert alert-info text-center" role="alert">
                                    <i class="bi bi-info-circle me-2"></i> Không có ảnh phụ nào.
                                </div>
                            <?php endif; ?>
                        </div>
                    </div>

                    <!-- Nút hành động -->
                    <div class="text-end">
                        <a href="<?php echo e(route('sanpham.edit', $sanpham->id)); ?>" class="btn btn-success btn-sm me-2">
                            <i class="bi bi-pencil-square"></i> Sửa
                        </a>
                        <form action="<?php echo e(route('sanpham.destroy', $sanpham->id)); ?>" method="POST" class="d-inline" onsubmit="return confirm('Bạn có chắc muốn xoá?')">
                            <?php echo csrf_field(); ?>
                            <?php echo method_field('DELETE'); ?>
                            <button type="submit" class="btn btn-danger btn-sm me-2">
                                <i class="bi bi-trash3"></i> Xoá
                            </button>
                        </form>
                        <a href="<?php echo e(route('sanpham')); ?>" class="btn btn-outline-secondary btn-sm">
                            <i class="bi bi-arrow-left"></i> Quay lại
                        </a>
                    </div>
                </div>
            </div>
        </div>
    </div>
</div>

<?php if(session('popup')): ?>
<script>
    window.onload = function() {
        if (confirm("<?php echo e(session('message')); ?>")) {
            window.location.href = "<?php echo e(route('chiTietSanPham', ['id' => $sanpham->id])); ?>";
        }
    };
</script>
<?php endif; ?>

<style>
    .card {
        transition: transform 0.3s ease, box-shadow 0.3s ease;
    }
    .card:hover {
        transform: translateY(-5px);
        box-shadow: 0 10px 20px rgba(0, 0, 0, 0.1) !important;
    }
    .btn-sm {
        padding: 0.4rem 0.8rem;
    }
    .img-fluid {
        transition: transform 0.3s ease;
    }
    .img-fluid:hover {
        transform: scale(1.05);
    }
</style>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('admin.layout.layout', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\Users\admin\OneDrive - Đại học FPT- FPT University\Desktop\Duantotnghiep\TechViewShop\resources\views/admin/sanpham/chitietsanpham.blade.php ENDPATH**/ ?>