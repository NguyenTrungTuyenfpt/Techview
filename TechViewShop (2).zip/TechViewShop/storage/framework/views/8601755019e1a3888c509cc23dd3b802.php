

<?php $__env->startSection('title', 'Chi tiết đơn hàng'); ?>

<?php $__env->startSection('content'); ?>
<div class="container">
    <h4 class="fw-bold mt-4">Chi tiết đơn hàng #<?php echo e($donhang->madonhang); ?></h4>

    <div class="border rounded p-3 shadow-sm bg-light">
        <h5 class="fw-bold">Thông tin đơn hàng</h5>
        <p><strong>Người nhận:</strong> <?php echo e($donhang->tennguoinhan); ?></p>
        <p><strong>Số điện thoại:</strong> <?php echo e($donhang->sodienthoai); ?></p>
        <p><strong>Địa chỉ:</strong> <?php echo e($donhang->diachi); ?></p>
        <p><strong>Tổng tiền:</strong> <?php echo e(number_format($donhang->tongtien, 0, ',', '.')); ?> VNĐ</p>
        <p><strong>Trạng thái:</strong> <?php echo e($donhang->trangthai); ?></p>
        <p><strong>Trạng thái thanh toán:</strong> <?php echo e($donhang->trangthaithanhtoan); ?></p>
        <p><strong>Ngày tạo:</strong> <?php echo e(date('d/m/Y H:i', strtotime($donhang->ngaytao))); ?></p>
    </div>

    <div class="border rounded p-3 shadow-sm bg-light mt-3">
        <h5 class="fw-bold">Danh sách sản phẩm trong đơn hàng này</h5>
        <table class="table">
            <thead>
                <tr>
                    <th>#</th>
                    <th>Sản phẩm</th>
                    <th>Giá</th>
                    <th>Số lượng</th>
                    <th>Thành tiền</th>
                </tr>
            </thead>
            <tbody>
                <?php $__currentLoopData = $donhang->chitietdonhang; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $index => $chitiet): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                <tr>
                    <td><?php echo e($index + 1); ?></td>
                    <td><?php echo e($chitiet->sanpham->tensp ?? 'Sản phẩm đã bị xóa'); ?></td>
                    <td><?php echo e(number_format($chitiet->gia, 0, ',', '.')); ?> VNĐ</td>
                    <td><?php echo e($chitiet->soluong); ?></td>
                    <td><?php echo e(number_format($chitiet->gia * $chitiet->soluong, 0, ',', '.')); ?> VNĐ</td>
                </tr>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            </tbody>
        </table>
    </div>

    <div class="d-flex justify-content-end mt-3">
        <a href="<?php echo e(route('donhang')); ?>" class="btn btn-secondary">Quay lại</a>
    </div>
</div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('admin.layout.layout', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\Users\admin\OneDrive - Đại học FPT- FPT University\Desktop\Duantotnghiep\TechViewShop\resources\views/admin/donhang/chitietdonhang.blade.php ENDPATH**/ ?>