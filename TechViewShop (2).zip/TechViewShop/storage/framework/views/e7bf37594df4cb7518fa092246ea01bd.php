

<?php $__env->startSection('title', 'Banner'); ?>

<?php $__env->startSection('content'); ?>

<!-- Nội dung chính của trang sẽ nằm ở đây -->
<div class="container">
    <div class="category-list mt-4 d-flex justify-content-between align-items-center">
        <h4 class="fw-bold">DANH SÁCH BANNER</h4>
        <a href="<?php echo e(route('banner.create')); ?>"><button class="btn btn-primary"><i class="bi bi-plus-lg"></i> Thêm sản banner</button></a>
    </div>
    <div class="table-responsive border-1">
        <table class="table table-hover align-middle">
            <thead class="table-primary">
                <tr>
                    <th>ID</th>
                    <th>Tên </th>
                    <th>Hình </th>
                    <th>Mô tả </th>
                    <th>Link </th>
                    <th>Vị trí</th>
                    <th>Ẩn/hiện</th>
                    <th>Thứ tự</th>
                    <th>Thao tác</th>
                </tr>
            </thead>
            <tbody>

                <?php $__currentLoopData = $banners; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $bn): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>

                <tr>
                    <td><?php echo e($bn->id); ?></td>
                    <td>
                        <a class="text-dark text-decoration-none" href="">
                            <?php echo e($bn->ten); ?>

                        </a>
                    </td>

                 
                    <td style="width: 15%">
                    <img src="<?php echo e(asset('uploads/banner/' . $bn->hinh)); ?>" class="img-thumbnail" style="width: 100%;">
                    </td>
                    <td><?php echo e($bn->mota); ?></td>
                    <td><?php echo e($bn->link); ?></td>
                    <td><?php echo e($bn->vitri); ?></td>
                 
                    <td>
                        <span class="badge <?php echo e($bn->anhien == 1 ? 'bg-success bg-opacity-10 text-success' : 'bg-danger bg-opacity-10 text-danger'); ?> p-2">
                            <?php echo e($bn->anhien == 1? 'Hiện' : 'Ẩn'); ?>

                        </span>
                    </td>

                    <td><?php echo e($bn->thutu); ?></td>

            
                    <td>
                        <div class="d-flex align-items-center gap-2">
                            <a href="<?php echo e(route('banner.edit', $bn->id)); ?>">
                                <span class="badge bg-success bg-opacity-10 text-success p-2">
                                    <i class="bi bi-pencil"></i> Sửa
                                </span>
                            </a>

                            <form action="<?php echo e(route('banner.destroy', $bn->id)); ?>" method="POST" onsubmit="return confirm('Bạn có chắc muốn xoá?')">
                                <?php echo csrf_field(); ?>
                                <?php echo method_field('DELETE'); ?>
                                <button type="submit" class="badge bg-danger bg-opacity-10 text-danger p-2 border-0"> <i class="bi bi-trash3"></i>Xoá</button>
                            </form>
                        </div>

                    </td>
                </tr>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>


            </tbody>
        </table>
    </div>
</div>
<!-- <nav aria-label="Page navigation example">
    <ul class="pagination justify-content-end">
        <li class="page-item disabled">
            <a class="page-link">Previous</a>
        </li>
        <li class="page-item"><a class="page-link" href="#">1</a></li>
        <li class="page-item"><a class="page-link" href="#">2</a></li>
        <li class="page-item"><a class="page-link" href="#">3</a></li>
        <li class="page-item">
            <a class="page-link" href="#">Next</a>
        </li>
    </ul>
</nav> -->

<!-- Phân trang động với Bootstrap 5 -->
<div class="d-flex justify-content-end mt-3">
        <?php echo e($banners->links('pagination::bootstrap-5')); ?>

    </div>
</div>

</div>

<?php $__env->stopSection(); ?>
<?php echo $__env->make('admin.layout.layout', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\Users\admin\OneDrive - Đại học FPT- FPT University\Desktop\Duantotnghiep\TechViewShop\resources\views/admin/banner/banner.blade.php ENDPATH**/ ?>