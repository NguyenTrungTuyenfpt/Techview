
<?php $__env->startSection('title'); ?>
    Trang sản phẩm yêu thích
<?php $__env->stopSection(); ?>

<?php $__env->startSection('body'); ?>
    <div class="wishlist">
        <div class="grid container">
            <div class="row">
                <div class="col l-12 m-12 c-12">
                    <?php if(session('success')): ?>
                        <div class="success">
                            <?php echo e(session('success')); ?>

                        </div>
                    <?php endif; ?>
                    <?php if(count($favoriteList) > 0): ?>
                        <div class="table-responsive">
                            <table class="product-table">
                                <thead>
                                    <tr>
                                        <th class="product-table-mobile" width="50%" colspan="2">Sản phẩm</th>
                                        <th class="product-table-mobile" width="10%">Giá</th>
                                        <th class="product-table-mobile" width="15%">Ngày thêm</th>
                                        <th class="product-table-mobile" width="10%">Còn hàng</th>
                                        <th class="product-table-mobile" width="15%">Thêm vào giỏ hàng</th>
                                    </tr>
                                </thead>
                                <tbody>
                                    <?php $__currentLoopData = $favoriteList; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $favorite): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                        <tr>
                                            <td>
                                                <img src="<?php echo e(asset('/img/sanpham/'.$favorite->product->hinh)); ?>" alt="No image" class="">
                                            </td>
                                            <td>
                                                <span class="product-table__item-name"> <?php echo e($favorite->product->tensp); ?> </span>
                                            </td>
                                            <td>
                                                <?php if($favorite->product->giamgia): ?>
                                                    <p><del><?php echo e(number_format($favorite->product->gia)); ?>₫</del></p>
                                                    <span class="discounted">
                                                        <?php echo e(number_format($favorite->product->gia*(1 - ($favorite->product->giamgia/100)))); ?>₫
                                                    </span>
                                                <?php else: ?>
                                                    <span class="discounted">
                                                        <?php echo e(number_format($favorite->product->gia)); ?>₫
                                                    </span>
                                                <?php endif; ?>
                                            </td>
                                            <td><span class="product-table__item-name"><?php echo e($favorite->ngaythem); ?></span></td>
    
                                            <?php if($favorite->product->tonkho > 0): ?>
                                                <td class="stock in-stock product-table__item-name">
                                                    Còn hàng
                                                </td>
                                            <?php elseif($favorite->product->tonkho == 0): ?>
                                                <td class="stock item-ofstock product-table__item-name">
                                                    Hết hàng
                                                </td>
                                            <?php endif; ?>
    
                                            <td class="addcart" >
                                                <?php if($favorite->product->tonkho == 0): ?>
                                                    <button type="submit" class="add-to-cart hide-on-mobile hide-on-table">Thêm vào giỏ</button>
                                                <?php else: ?>
                                                    <form action="<?php echo e(route('cart.add')); ?>" method="post">
                                                        <?php echo csrf_field(); ?>
                                                        <input type="hidden" name="id" value="<?php echo e($favorite->product->id); ?>">
                                                        <input type="hidden" class="qty-input" name="quantity" value="1" min="1" max="<?php echo e($favorite->product->tonkho); ?>">
                                                        <button type="submit" class="add-to-cart hide-on-mobile hide-on-table">Thêm vào giỏ</button>
                                                    </form>
                                                <?php endif; ?>
                                                
                                                <form action="<?php echo e(route('favorite.delete', $favorite->id)); ?>" 
                                                    method="POST" 
                                                    onsubmit="return confirm('Bạn có chắc chắn muốn xóa không?')"
                                                >
                                                    <?php echo csrf_field(); ?>
                                                    <button type="submit" class="addcart-icon__link">
                                                        <i class="addcart-icon__link-icon fa-solid fa-xmark"></i>
                                                    </button>
                                                </form>
                                            </td>
                                        </tr>
                                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                </tbody>
                            </table>
                        </div>
                    <?php else: ?>
                        <p class="product-table-empty">Bạn chưa có sản phẩm yêu thích</p>
                    <?php endif; ?>
                </div>
            </div>

            <?php if(count($favoriteList) > 0): ?>
                <div class="row">
                    <div class="col l-12">
                        <a href="javascript:void(0)" onclick="history.back()" class="shopingcart-link ">
                            <i class="shopingcart-link__icon fa-solid fa-arrow-left"></i>
                            Quay lại trang chủ
                        </a>
                    </div>
                </div>
            <?php endif; ?>
        </div>

    </div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('client.layout.layout', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\Users\admin\OneDrive - Đại học FPT- FPT University\Desktop\Duantotnghiep\TechViewShop\resources\views/client/pages/favorite.blade.php ENDPATH**/ ?>