

<?php $__env->startSection('title', 'Sua Banner'); ?>

<?php $__env->startSection('content'); ?>
<!-- Nội dung chính của trang sẽ nằm ở đây -->

<p><a href="/">Trang chủ</a> / <span class="text-primary">Sửa Banner</span></p>

<form action="<?php echo e(route('banner.update', $banner->id)); ?>" method="POST" enctype="multipart/form-data">
    <?php echo csrf_field(); ?>
    <?php echo method_field('PUT'); ?>
    
    <div class="add-product">
        <div class="row">
            <!-- Thông tin sản phẩm -->
            <div class="col-md-12">
                <div class="border rounded p-3">
                    <h5 class="fw-bold">Thông tin </h5>
                    <div class="row">
                        <!-- Tên sản phẩm -->
                        <div class="col-md-4 mt-3">
                            <label class="form-label">Tên </label>
                            <input type="text" name="ten" class="form-control" value="<?php echo e($banner->ten); ?>" required>
                            <?php $__errorArgs = ['ten'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> <small class="text-danger"><?php echo e($message); ?></small> <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                        </div>

                        <!-- Giá sản phẩm -->
                        <div class="col-md-4 mt-3">
                            <label class="form-label">Mo ta</label>
                            <input type="text" name="mota" class="form-control" value="<?php echo e($banner->mota); ?>" required>
                            <?php $__errorArgs = ['gia'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> <small class="text-danger"><?php echo e($message); ?></small> <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                        </div>

                        <!-- Giá khuyến mãi -->
                        <div class="col-md-4 mt-3">
                            <label class="form-label">Vi tri</label>
                            <input type="text" name="giagiam" class="form-control" value="<?php echo e($banner->vitri); ?>">
                            <?php $__errorArgs = ['vitri'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> <small class="text-danger"><?php echo e($message); ?></small> <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                        </div>

                        <!-- Mô tả -->
                        <div class="col-md-4 mt-3">
                            <label class="form-label">link</label>
                            <input type="text" name="link" class="form-control" value="<?php echo e($banner->link); ?>">
                            <?php $__errorArgs = ['link'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> <small class="text-danger"><?php echo e($message); ?></small> <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                        </div>

                        <!-- Thứ tự ưu tiên -->
                        <div class="col-md-4 mt-3">
                            <label class="form-label">Thứ tự</label>
                            <input type="number" name="thutu" class="form-control" value="<?php echo e($banner->thutu); ?>" required>
                            <?php $__errorArgs = ['gia'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> <small class="text-danger"><?php echo e($message); ?></small> <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                        </div>


                        <!-- Trạng thái hiển thị -->
                        <div class="col-md-4 mt-3">
                            <label class="form-label d-block">Trạng thái hiển thị</label>
                            <div class="form-check form-check-inline">
                                <input class="form-check-input" type="radio" name="anhien" value="1"
                                    <?php echo e($banner->anhien == 1 ? 'checked' : ''); ?>>
                                <label class="form-check-label">Hiển thị</label>
                            </div>
                            <div class="form-check form-check-inline">
                                <input class="form-check-input" type="radio" name="anhien" value="0"
                                    <?php echo e($banner->anhien == 0 ? 'checked' : ''); ?>>
                                <label class="form-check-label">Ẩn</label>
                            </div>
                            <?php $__errorArgs = ['trangthai'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> <small class="text-danger d-block"><?php echo e($message); ?></small> <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>

                           
                        </div>


                    </div>
                </div>
            </div>
        </div>

        <!-- Ảnh chính hiện tại -->
        <div class="border rounded p-4 text-center mt-3">
            <p class="text-muted">Ảnh hiện tại</p>
            <?php if($banner->hinh): ?>
                <img src="<?php echo e(asset('uploads/banner/' . $banner->hinh)); ?>" width="150" class="img-thumbnail" alt="Ảnh chính hiện tại">
            <?php else: ?>
                <p class="text-muted">Chưa có ảnh </p>
            <?php endif; ?>
            <p class="text-muted mt-2">Chọn ảnh mới </p>
            <input type="file" name="hinh" class="form-control mt-2">
            <?php $__errorArgs = ['hinh'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> <small class="text-danger"><?php echo e($message); ?></small> <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
        </div>

       

        <!-- Buttons -->
        <div class="d-flex justify-content-end mt-4">
            <button type="submit" class="btn btn-primary me-2">Cập nhật </button>
            <a href="<?php echo e(route('banner')); ?>" class="btn btn-danger">Hủy</a>
        </div>
    </div>
</form>





<?php if(session('popup')): ?>
<script>
    window.onload = function() {
        if (confirm("<?php echo e(session('message')); ?>")) {
            window.location.href = "<?php echo e(route('banner')); ?>";
        }
    };
</script>
<?php endif; ?>

</div>
</div>

<?php $__env->stopSection(); ?>
<?php echo $__env->make('admin.layout.layout', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\Users\admin\OneDrive - Đại học FPT- FPT University\Desktop\Duantotnghiep\TechViewShop\resources\views/admin/banner/suabanner.blade.php ENDPATH**/ ?>