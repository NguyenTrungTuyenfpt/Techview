
<?php $__env->startSection('title'); ?>
Trang chi tiết sản phẩm
<?php $__env->stopSection(); ?>

<?php $__env->startSection('body'); ?>
<div class="site-primary">
    <div class="site-content">
        <div class="shop-deitail-container">
            <div class="row main-product-deitail">
                <div class="cell-product-gallery col 1-6 right">
                    <div class="product-gallery">
                        <div class="main-image">
                            <img id="mainImage" src="<?php echo e(asset('/img/sanpham/'.$product->hinh)); ?>" alt="Product Image">
                        </div>
                        <div class="thumbnails">
                            <img onclick="changeImage(this)" src="<?php echo e(asset('/img/sanpham/'.$product->hinh)); ?>" alt="Product Image">
                            <?php $__currentLoopData = $product->images; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $img): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                            <img src="<?php echo e(asset('/img/sanpham/'.$img->hinh)); ?>" onclick="changeImage(this)" alt="Thumbnail 1">
                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                        </div>
                    </div>
                    <script>
                        function changeImage(element) {
                            document.getElementById('mainImage').src = element.src;
                        }
                    </script>
                </div>
                <div class="cell-product-content col 1-6 left">
                    <h1 class="product_title entry-title">
                        <?php echo e($product->tensp); ?>

                    </h1>
                    <?php if($product->luotxem > 0): ?>
                    <span class="product-detail-review">
                        Lượt xem: <?php echo e($product->luotxem); ?>

                    </span>
                    <?php endif; ?>
                    <div class="product-meta">
                        <div class="woocommerce-product-rating">
                            <div class="woocommerce-product-rating">
                                <?php
                                $rating = collect($rating)->firstWhere('id_sanpham', $product->id) ?? (object) ['tb_sao' => 0, 'dem' => 0];
                                ?>
                                <div class="product-rating__list">
                                    <?php for($i = 0; $i < ($rating->tb_sao ?? 0) ; $i++): ?>
                                        <i class="icon-rating fa-solid fa-star"></i>
                                        <?php endfor; ?>
                                        <?php for($i = 0; $i < (5 - ($rating->tb_sao ?? 0)) ; $i++): ?>
                                            <i class="icon-rating-none fa-solid fa-star"></i>
                                            <?php endfor; ?>
                                </div>
                                <?php if($rating->dem > 0): ?>
                                <span class="product-detail-review">
                                    <?php echo e($rating->dem); ?>

                                    đánh giá
                                </span>
                                <?php else: ?>
                                <span class="product-detail-review">Chưa đánh giá</span>
                                <?php endif; ?>

                            </div>
                        </div>
                    </div>
                    <div class="price">
                        <?php if($product->giamgia): ?>
                        <p class="old-price"><del><?php echo e(number_format($product->gia)); ?></del>đ</p>
                        <p class="new-price">
                            <?php echo e(number_format($product->gia * (1 - ($product->giamgia/100)))); ?>₫
                        </p>
                        <?php else: ?>
                        <p class="new-price"><?php echo e(number_format($product->gia)); ?>₫</p>
                        <?php endif; ?>
                    </div>
                    <p class="product-branch">Thương hiệu: <?php echo e($product->thuonghieu); ?> </p>
                    <div class="product-short-description">
                        <h3 class="description-title">Thông số kỹ thuật</h3>
                        <ul class="short-description-list">
                            <?php if($product->specs->isNotEmpty()): ?>
                            <?php $__currentLoopData = $product->specs; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $specsItem): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                            <li><?php echo e($specsItem->ten); ?>: <?php echo e($specsItem->giatri); ?></li>
                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                            <?php else: ?>
                            <li>Đang cập nhật</li>
                            <?php endif; ?>
                        </ul>
                    </div>

                    <?php if(session('success')): ?>
                    <div class="success">
                        <?php echo e(session('success')); ?>

                    </div>
                    <?php endif; ?>


                    <form action="<?php echo e(route('cart.add')); ?>" method="post">
                        <?php echo csrf_field(); ?>
                        <input type="hidden" name="id" value="<?php echo e($product->id); ?>">
                        <div class="product-detail-addcart">
                            <div class="product-detail-quantity">
                                <input type="number" class="qty-input" name="quantity" value="1" min="1" max="<?php echo e($product->tonkho); ?>">
                            </div>
                            <?php if($product->tonkho > 0): ?>
                            <button class="btn-cart">
                                <div class="icon-addtocart"><i class="fa-solid fa-cart-shopping"></i></div>
                                Thêm vào giỏ hàng
                            </button>
                            <?php else: ?>
                            <div class="btn-cart">
                                <div class="icon-addtocart"><i class="fa-solid fa-cart-shopping"></i></div>
                                Thêm vào giỏ hàng
                            </div>
                            <?php endif; ?>
                        </div>
                    </form>
                    <div class="product-wishlist">
                        <p>Thêm vào danh sách sản phẩm yêu thích</p>
                        <form action="<?php echo e(route('favorite.add')); ?>" method="POST">
                            <?php echo csrf_field(); ?>
                            <input type="hidden" name="id" value="<?php echo e($product->id); ?>">
                            <button type="submit" class="product-detail-addFav">
                                <i class="fa-regular fa-heart product-item__heart"></i>
                            </button>
                        </form>
                    </div>
                    <div class="product-meta bottom product_meta">
                        <div class="product-categories posted_in">
                            <span>Danh mục:</span>
                            <a href="" rel="tag"><?php echo e($product->category->tendm); ?></a>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </div>
    <div class="product-tabs">
        <ul class="tab-list">
            <li class="tab-item active"><a href="#tab-desc">Mô tả</a></li>
            <li class="tab-item"><a href="#tab-info">Thông tin bổ sung</a></li>
            <li class="tab-item"><a href="#tab-reviews">Đánh giá</a></li>
        </ul>
        <div class="tab-content active" id="tab-desc">
            <h2><?php echo e($product->tensp); ?></h2>
            <p><?php echo e($product->mota); ?></p>
        </div>
        <div class="tab-content" id="tab-info">
            <h2>Additional Info</h2>
            <div class="product-extra-detailss">
                <table class="product-attributes">
                    <tbody>
                        <tr>
                            <th>Năm</th>
                            <td>2014, 2015, 2016, 2017, 2018</td>
                        </tr>
                        <tr>
                            <th>Hãng xe</th>
                            <td>Thành phố, Civic, Honda</td>
                        </tr>
                        <tr>
                            <th>Kiểu dáng thân máy</th>
                            <td>Xe Jeep, xe mui kín</td>
                        </tr>
                        <tr>
                            <th>Thương hiệu</th>
                            <td>ACDelco, COMSOON</td>
                        </tr>
                    </tbody>
                </table>
            </div>
        </div>
        <div class="tab-content" id="tab-reviews">
            <div class="review-section">
                <h2 class="review-title"><?php echo e(count($product->danhGiaSanPham)); ?> đánh giá cho <span><?php echo e($product->tensp); ?></span></h2>
                <ul class="review-list">
                    <?php $__currentLoopData = $product->danhGiaSanPham; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $dg): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <li class="review-item">
                        <div class="review-container">
                            <img class="review-avatar" src="<?php echo e(asset('images/default-avatar.png')); ?>" alt="User Avatar">
                            <div class="review-content">
                                <div class="review-header">
                                    <div class="review-rating">
                                        <span class="stars-review">
                                            <?php for($i = 1; $i <= 5; $i++): ?>
                                                <i class="fa-solid fa-star <?php echo e($i <= $dg->danhgia ? 'text-yellow-400' : 'text-gray-300'); ?>"></i>
                                                <?php endfor; ?>
                                        </span>
                                    </div>
                                    <p class="review-meta">
                                        <strong class="review-author"><?php echo e($dg->user->name ?? 'Ẩn danh'); ?></strong>
                                        <span class="review-divider">-</span>
                                        <time class="review-date"><?php echo e($dg->created_at->translatedFormat('d \t\h\á\n\g m \n\ă\m Y')); ?></time>
                                    </p>
                                </div>
                                <div class="review-text">
                                    <p><?php echo e($dg->noidung); ?></p>
                                </div>


                                
                                <?php if($dg->phanHoi): ?>
                               
                                                <span class="text-sm font-semibold text-gray-800"><?php echo e($dg->phanHoi->user->name ?? 'TechViewShop'); ?>:</span>
                                                <span class="text-sm text-gray-700"><?php echo e($dg->phanHoi->noidung); ?></span>
                                           
                                <?php endif; ?>
                            </div>
                        </div>


                    </li>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>

                </ul>
            </div>
            <?php if(Auth::check() && $canReview): ?>
            <div class="review-form">
                <h2>Thêm Đánh Giá</h2>
                <form method="POST" action="<?php echo e(route('danhgia.sp', $product->id)); ?>">
                    <?php echo csrf_field(); ?>
                    <?php if($errors->any()): ?>
                    <div class=" alert alert-danger">
                        <ul>
                            <?php $__currentLoopData = $errors->all(); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $error): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                            <li><?php echo e($error); ?></li>
                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                        </ul>
                    </div>
                    <?php endif; ?>

                    <div class="stars" id="starRating">
                        <input type="radio" id="danhgia1" name="danhgia" value="1">
                        <label for="danhgia1"><i class="fa-solid fa-star cursor-pointer"></i></label>

                        <input type="radio" id="danhgia2" name="danhgia" value="2">
                        <label for="danhgia2"><i class="fa-solid fa-star cursor-pointer"></i></label>

                        <input type="radio" id="danhgia3" name="danhgia" value="3">
                        <label for="danhgia3"><i class="fa-solid fa-star cursor-pointer"></i></label>

                        <input type="radio" id="danhgia4" name="danhgia" value="4">
                        <label for="danhgia4"><i class="fa-solid fa-star cursor-pointer"></i></label>

                        <input type="radio" id="danhgia5" name="danhgia" value="5">
                        <label for="danhgia5"><i class="fa-solid fa-star cursor-pointer"></i></label>
                    </div>



                    <div class="input-group">
                        <label for="noidung">Đánh giá *</label>
                        <textarea name="noidung" rows="4" required class="w-full border p-2 rounded"></textarea>
                    </div>
                    <button type="submit" class="submit-btn bg-blue-500 text-white px-4 py-2 rounded mt-2">Gửi Đánh Giá</button>
                </form>
            </div>
            <?php endif; ?>
        </div>
    </div>
    <section class="featuredProduct">
        <div class="grid container">
            <div class="section-product__head">
                <h3 class="section-product__title">Sản phẩm liên quan</h3>
                <a href="/category/<?php echo e($product->category->slug); ?>" class="section-product__link pl-none">
                    Xem tất cả
                    <i class="section-product__icon fa-solid fa-arrow-right"></i>
                </a>
            </div>
            <div class="product-slider">
                <div class="row">
                    <div class="product-container">
                        <?php $__currentLoopData = $relatedProducts; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $product): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <?php
                        $relatedRating = [
                        'tb_sao' => $product->danhGiaSanPham->avg('danhgia') ?? 0,
                        'dem' => $product->danhGiaSanPham->count(),
                        ];
                        ?>
                        <div class="col l-2-4 m-4 c-6 product-border">
                            <div class="product">
                                <div class="product-item">
                                    <a href="/product/detail/<?php echo e($product->slug); ?>" class="product-item__link">
                                        <?php if($product->giamgia): ?>
                                        <span class="product-item__discount">-<?php echo e($product->giamgia); ?>%</span>
                                        <?php endif; ?>
                                        <img src="<?php echo e(asset('/img/sanpham/'.$product->hinh)); ?>" class="product-item__img" alt="Kính thiên văn">
                                    </a>
                                    <form action="<?php echo e(route('favorite.add')); ?>" method="POST">
                                        <?php echo csrf_field(); ?>
                                        <input type="hidden" name="id" value="<?php echo e($product->id); ?>">
                                        <button type="submit" class="product-item__heart-link">
                                            <i class="fa-regular fa-heart product-item__heart"></i>
                                        </button>
                                    </form>
                                </div>
                                <div class="product-content">
                                    <a href="/product/detail/<?php echo e($product->slug); ?>" class="product-title"> <?php echo e($product->tensp); ?> </a>
                                    <div class="product-rating">
                                        <div class="product-rating__list">
                                            <?php for($i = 0; $i < round($relatedRating['tb_sao']); $i++): ?>
                                                <i class="icon-rating fa-solid fa-star"></i>
                                                <?php endfor; ?>
                                                <?php for($i = 0; $i < (5 - round($relatedRating['tb_sao'])); $i++): ?>
                                                    <i class="icon-rating-none fa-solid fa-star"></i>
                                                    <?php endfor; ?>
                                        </div>
                                        <?php if($relatedRating['dem'] > 0): ?>
                                        <span class="product-review"><?php echo e($relatedRating['dem']); ?> đánh giá</span>
                                        <?php else: ?>
                                        <span class="product-review">Chưa đánh giá</span>
                                        <?php endif; ?>
                                    </div>
                                    <div class="product-cart">
                                        <div class="product-price">
                                            <?php if($product->giamgia): ?>
                                            <p class="old-price"><del><?php echo e(number_format($product->gia)); ?></del>đ</p>
                                            <p class="new-price"><?php echo e(number_format($product->gia * (1 - ($product->giamgia/100)))); ?>₫</p>
                                            <?php else: ?>
                                            <p class="new-price"><?php echo e(number_format($product->gia)); ?>₫</p>
                                            <?php endif; ?>
                                        </div>
                                        <form action="<?php echo e(route('cart.add')); ?>" method="POST">
                                            <?php echo csrf_field(); ?>
                                            <input type="hidden" name="id" value="<?php echo e($product->id); ?>">
                                            <input type="hidden" name="quantity" value="1">
                                            <button type="submit" class="product-cart__link">
                                                <i class="product-cart__icon fa-solid fa-cart-shopping"></i>
                                            </button>
                                        </form>
                                    </div>
                                    <div class="product-status">
                                        <svg xmlns="http://www.w3.org/2000/svg" width="15" height="16" viewBox="0 0 15 16" fill="none">
                                            <path d="M14.1358 3.43605L8.57846 0.28359C7.91183 -0.0945299 7.08783 -0.0945299 6.42121 0.28359L0.864174 3.43605C0.686049 3.53698 0.687054 3.78823 0.866183 3.88791L7.5 7.57974L14.1342 3.88791C14.3133 3.78823 14.3143 3.53729 14.1358 3.43605ZM14.5992 4.83071L8.03571 8.48316V15.4774C8.03571 15.8799 8.48404 16.1309 8.84096 15.9284L13.9356 13.0384C14.5945 12.6647 15 11.9778 15 11.2353V5.05727C15 4.85696 14.7777 4.73134 14.5992 4.83071ZM0 5.05727V11.2353C0 11.9781 0.405469 12.6647 1.0644 13.0384L6.15904 15.9281C6.51629 16.1306 6.96429 15.8799 6.96429 15.4771V8.48316L0.400781 4.83071C0.222321 4.73134 0 4.85696 0 5.05727Z" fill="#099268" />
                                        </svg>
                                        <?php if($product->tonkho == 0): ?>
                                        <span class="product-stock">Hết hàng</span>
                                        <?php else: ?>
                                        <span class="product-stock">Còn hàng</span>
                                        <?php endif; ?>
                                    </div>
                                </div>
                            </div>
                        </div>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                    </div>
                </div>
            </div>
    </section>
</div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('client.layout.layout', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\Users\admin\OneDrive - Đại học FPT- FPT University\Desktop\Duantotnghiep\TechViewShop\resources\views/client/pages/product-detail.blade.php ENDPATH**/ ?>