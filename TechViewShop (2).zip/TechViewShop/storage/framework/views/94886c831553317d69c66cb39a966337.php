

<?php $__env->startSection('title', 'Danh sách danh mục bài viết'); ?>

<?php $__env->startSection('content'); ?>
<div class="container mt-5">
    <div class="row justify-content-center">
        <div class="col-lg-12">
            <!-- Header -->
            <div class="d-flex justify-content-between align-items-center mb-4">
                <h2 class="fw-bold text-primary">Danh sách danh mục bài viết</h2>
                <a href="<?php echo e(route('danhmucbaiviet.create')); ?>" class="btn btn-primary">
                    <i class="bi bi-plus-lg"></i> Thêm danh mục bài viết
                </a>
            </div>

            <!-- Card chính -->
            <div class="card border-0 shadow-lg rounded-3">
                <div class="card-body p-4">
                    <!-- Tìm kiếm và sắp xếp -->
                    <div class="row mb-4">
                        <div class="col-md-6 mb-3 mb-md-0">
                            <form method="GET" action="<?php echo e(route('danhmucbaiviet.index')); ?>">
                                <div class="input-group">
                                    <input type="text" name="search" class="form-control" placeholder="Tìm kiếm danh mục bài viết" value="<?php echo e(request('search')); ?>">
                                    <button class="btn btn-primary" type="submit">
                                        <i class="bi bi-search"></i> Tìm kiếm
                                    </button>
                                </div>
                            </form>
                        </div>
                        <div class="col-md-6 text-md-end">
                            <div class="btn-group">
                                <a href="<?php echo e(route('danhmucbaiviet.index', ['sort' => 'id', 'direction' => request('direction', 'asc') == 'asc' ? 'desc' : 'asc'])); ?>"
                                   class="btn btn-outline-primary btn-sm">
                                    Theo ID
                                    <i class="bi <?php echo e(request('sort') == 'id' && request('direction') == 'asc' ? 'bi-sort-down' : 'bi-sort-up'); ?>"></i>
                                </a>
                                <a href="<?php echo e(route('danhmucbaiviet.index', ['sort' => 'tendm', 'direction' => request('direction', 'asc') == 'asc' ? 'desc' : 'asc'])); ?>"
                                   class="btn btn-outline-primary btn-sm">
                                    Theo Tên
                                    <i class="bi <?php echo e(request('sort') == 'tendm' && request('direction') == 'asc' ? 'bi-sort-down' : 'bi-sort-up'); ?>"></i>
                                </a>
                                <a href="<?php echo e(route('danhmucbaiviet.index', ['sort' => 'baiviets_count', 'direction' => request('direction', 'asc') == 'asc' ? 'desc' : 'asc'])); ?>"
                                   class="btn btn-outline-primary btn-sm">
                                    Theo Số lượng bài viết
                                    <i class="bi <?php echo e(request('sort') == 'baiviets_count' && request('direction') == 'asc' ? 'bi-sort-down' : 'bi-sort-up'); ?>"></i>
                                </a>
                            </div>
                        </div>
                    </div>

                    <!-- Bảng danh mục bài viết -->
                    <div class="table-responsive">
                        <table class="table table-hover align-middle">
                            <thead class="table-light">
                                <tr>
                                    <th>ID</th>
                                    <th>Tên danh mục</th>
                                    <th>Số lượng bài viết</th>
                                    <th>Ẩn/Hiện</th>
                                    <th>Hành động</th>
                                </tr>
                            </thead>
                            <tbody>
                                <?php $__empty_1 = true; $__currentLoopData = $danhMucBaiViets; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $dm): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>
                                    <tr>
                                        <td><?php echo e($dm->id); ?></td>
                                        <td>
                                            <a class="text-decoration-none text-dark fw-semibold" href="<?php echo e(route('danhmucbaiviet.show', $dm->id)); ?>">
                                                <?php echo e($dm->tendm); ?>

                                            </a>
                                        </td>
                                        <td>
                                            <span><?php echo e($dm->baiviets_count); ?></span>
                                        </td>
                                        <td>
                                            <span class="badge <?php echo e($dm->anhien == 1 ? 'bg-primary' : 'bg-secondary'); ?> px-2 py-1">
                                                <?php echo e($dm->anhien == 1 ? 'Hiện' : 'Ẩn'); ?>

                                            </span>
                                        </td>
                                        <td>
                                            <div class="d-flex align-items-center gap-2">
                                                <a href="<?php echo e(route('danhmucbaiviet.edit', $dm->id)); ?>" class="btn btn-sm btn-success">
                                                    <i class="bi bi-pencil"></i> Sửa
                                                </a>
                                                <form id="form-xoa-<?php echo e($dm->id); ?>" action="<?php echo e(route('danhmucbaiviet.destroy', $dm->id)); ?>" method="POST" class="d-inline-block" onsubmit="return false;">
                                                    <?php echo csrf_field(); ?>
                                                    <?php echo method_field('DELETE'); ?>
                                                    <button type="button"
                                                            onclick="confirmXoaDanhMuc(<?php echo e($dm->id); ?>, <?php echo e($dm->baiviets_count); ?>)"
                                                            class="btn btn-sm btn-danger">
                                                        <i class="bi bi-trash3"></i> Xoá
                                                    </button>
                                                </form>
                                            </div>
                                        </td>
                                    </tr>
                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>
                                    <tr>
                                        <td colspan="5" class="text-center text-muted py-4">
                                            <i class="bi bi-exclamation-circle me-2"></i> Không có danh mục bài viết nào.
                                        </td>
                                    </tr>
                                <?php endif; ?>
                            </tbody>
                        </table>
                    </div>

                    <!-- Phân trang -->
                    <div class="mt-4">
                        <?php echo e($danhMucBaiViets->appends(request()->query())->links('pagination::bootstrap-5')); ?>

                    </div>
                </div>
            </div>
        </div>
    </div>
</div>

<script>
    function confirmXoaDanhMuc(id, soLuongBaiViet) {
        if (soLuongBaiViet > 0) {
            Swal.fire({
                title: 'Danh mục có bài viết',
                text: "Không thể xoá danh mục này vì nó có bài viết. Bạn có muốn ẩn danh mục này không?",
                icon: 'warning',
                showCancelButton: true,
                confirmButtonText: 'Ẩn danh mục',
                cancelButtonText: 'Hủy',
                confirmButtonColor: '#3085d6',
                cancelButtonColor: '#aaa',
            }).then((result) => {
                if (result.isConfirmed) {
                    document.getElementById('form-xoa-' + id).submit();
                }
            });
        } else {
            Swal.fire({
                title: 'Xoá danh mục bài viết?',
                text: "Hành động này không thể hoàn tác!",
                icon: 'warning',
                showCancelButton: true,
                confirmButtonText: 'Xoá',
                cancelButtonText: 'Hủy',
                confirmButtonColor: '#d33',
                cancelButtonColor: '#3085d6',
            }).then((result) => {
                if (result.isConfirmed) {
                    document.getElementById('form-xoa-' + id).submit();
                }
            });
        }
    }
</script>

<style>
    .card {
        transition: transform 0.3s ease, box-shadow 0.3s ease;
    }
    .card:hover {
        transform: translateY(-5px);
        box-shadow: 0 10px 20px rgba(0, 0, 0, 0.1) !important;
    }
    .btn-sm {
        padding: 0.4rem 0.8rem;
    }
    .table th, .table td {
        vertical-align: middle;
    }
    .form-control:focus {
        border-color: #0d6efd;
        box-shadow: 0 0 5px rgba(13, 110, 253, 0.2);
    }
</style>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('admin.layout.layout', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\Users\admin\OneDrive - Đại học FPT- FPT University\Desktop\Duantotnghiep\TechViewShop\resources\views/admin/danhmucbaiviet/danhmucbaiviet.blade.php ENDPATH**/ ?>