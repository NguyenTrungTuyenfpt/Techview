

<?php $__env->startSection('title', 'Thêm danh mục bài viết'); ?>

<?php $__env->startSection('content'); ?>
<div class="container-fluid mt-5">
    <form action="<?php echo e(route('danhmucbaiviet.store')); ?>" method="POST" style="max-width: 98%; margin: auto;">
        <?php echo csrf_field(); ?>
        <div class="row w-100">
            <div class="col-xl-8 col-lg-8 col-sm-12 col-12 m-auto">
                <?php if(Session::has('message')): ?>
                <div class="alert alert-success alert-dismissible">
                    <button type="button" class="close" data-dismiss="alert">×</button>
                    <?php echo e(Session::get('message')); ?>

                </div>
                <?php elseif(Session::has('failed')): ?>
                <div class="alert alert-danger alert-dismissible">
                    <button type="button" class="close" data-dismiss="alert">×</button>
                    <?php echo e(Session::get('failed')); ?>

                </div>
                <?php endif; ?>
                <div class="card shadow">
                    <div class="card-header d-flex justify-content-between align-items-center mb-4">
                        <h4 class="card-title fw-bold text-primary mb-0">Thêm danh mục bài viết</h4>
                        <a href="<?php echo e(route('danhmucbaiviet.index')); ?>" class="btn btn-outline-secondary">
                            <i class="bi bi-arrow-left"></i> Quay lại
                        </a>
                    </div>
                    <div class="card-body">
                        <!-- Tên danh mục -->
                        <div class="form-group mb-3">
                            <label for="tendm" class="form-label fw-semibold">Tên danh mục</label>
                            <input type="text" class="form-control" id="tendm" name="tendm" placeholder="Nhập tên danh mục" value="<?php echo e(old('tendm')); ?>" required>
                            <?php $__errorArgs = ['tendm'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                <span class="text-danger"><?php echo e($message); ?></span>
                            <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                        </div>

                        <!-- Ẩn/Hiện -->
                        <div class="mb-3">
                            <label class="form-label fw-semibold">Trạng thái</label>
                            <div class="form-check">
                                <input type="checkbox" name="anhien" id="anhien" class="form-check-input" value="1" <?php echo e(old('anhien') ? 'checked' : ''); ?>>
                                <label for="anhien" class="form-check-label">Hiển thị</label>
                            </div>
                        </div>
                    </div>

                    <div class="card-footer">
                        <button type="submit" class="btn btn-success">Lưu</button>
                    </div>
                </div>
            </div>
        </div>
    </form>
</div>

<script src="https://ajax.googleapis.com/ajax/libs/jquery/3.6.4/jquery.min.js"></script>
<script src="https://cdn.jsdelivr.net/npm/bootstrap@5.2.3/dist/js/bootstrap.bundle.min.js"></script>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('admin.layout.layout', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\Users\admin\OneDrive - Đại học FPT- FPT University\Desktop\Duantotnghiep\TechViewShop\resources\views/admin/danhmucbaiviet/them.blade.php ENDPATH**/ ?>