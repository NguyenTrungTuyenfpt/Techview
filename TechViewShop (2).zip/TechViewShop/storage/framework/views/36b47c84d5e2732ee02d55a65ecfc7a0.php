

<?php $__env->startSection('title', 'Sửa nhà cung cấp'); ?>

<?php $__env->startSection('content'); ?>

<form action="<?php echo e(route('nhacungcap.update', $nhacungcap->id)); ?>" method="POST" enctype="multipart/form-data">
    <?php echo csrf_field(); ?>
    <?php echo method_field('PUT'); ?>

    <?php if($errors->any()): ?>
    <div class="alert alert-danger">
        <ul class="mb-0">
            <?php $__currentLoopData = $errors->all(); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $error): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
            <li><?php echo e($error); ?></li>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
        </ul>
    </div>
    <?php endif; ?>

    <div class="container">
        <h4 class="fw-bold mt-4">Sửa nhà cung cấp</h4>
        <p><a href="/">Trang chủ</a> / <span class="text-primary">Sửa nhà cung cấp</span></p>
        <div class="add-product">
            <div class="row">
                <div class="col-md-12">
                    <div class="border rounded p-3">
                        <h5 class="fw-bold">Thông tin</h5>
                        <div class="row">
                            <div class="col-md-4 mt-3">
                                <label class="form-label">Tên nhà cung cấp</label>
                                <input type="text" name="tenncc" value="<?php echo e(old('tenncc', $nhacungcap->tenncc)); ?>" class="form-control" required>
                            </div>
                            <div class="col-md-4 mt-3">
                                <label class="form-label">Email</label>
                                <input type="email" name="email" value="<?php echo e(old('email', $nhacungcap->email)); ?>" class="form-control">
                            </div>
                            <div class="col-md-4 mt-3">
                                <label class="form-label">Số điện thoại</label>
                                <input type="text" name="sodienthoai" value="<?php echo e(old('sodienthoai', $nhacungcap->sodienthoai)); ?>" class="form-control">
                            </div>

                            <div class="col-md-4 mt-3">
                                <label class="form-label">Địa chỉ</label>
                                <input type="text" name="diachi" value="<?php echo e(old('diachi', $nhacungcap->diachi)); ?>" class="form-control">
                            </div>

                            <div class="col-md-4 mt-3">
                                <label class="form-label">Mô tả</label>
                                <input type="text" name="mota" value="<?php echo e(old('mota', $nhacungcap->mota)); ?>" class="form-control">
                            </div>

                            <div class="col-md-4 mt-3">
                                <label class="form-label">Thứ tự</label>
                                <input type="number" name="thutu" value="<?php echo e(old('thutu', $nhacungcap->thutu)); ?>" class="form-control">
                            </div>

                            <div class="col-md-4 mt-3">
                                <label class="form-label">Trạng thái hiển thị</label>
                                <div class="form-check">
                                    <input class="form-check-input" type="radio" name="anhien" id="hien" value="1" <?php echo e($nhacungcap->anhien == 1 ? 'checked' : ''); ?>>
                                    <label class="form-check-label" for="hien">Hiển thị</label>
                                </div>
                                <div class="form-check">
                                    <input class="form-check-input" type="radio" name="anhien" id="an" value="0" <?php echo e($nhacungcap->anhien == 0 ? 'checked' : ''); ?>>
                                    <label class="form-check-label" for="an">Ẩn</label>
                                </div>
                            </div>

                            <div class="border rounded p-4 text-center mt-2">
                                <?php if($nhacungcap->hinh): ?>
                                    <img src="<?php echo e(asset('uploads/nhacungcap/' . $nhacungcap->hinh)); ?>" alt="Hình hiện tại" class="img-thumbnail mb-2" style="max-height: 200px;">
                                <?php endif; ?>
                                <p class="text-muted">Cập nhật ảnh </p>
                                <input type="file" name="hinh" class="form-control mt-2">
                            </div>

                            <?php if($errors->has('hinh')): ?>
                            <div class="alert alert-danger mt-2">
                                <?php echo e($errors->first('hinh')); ?>

                            </div>
                            <?php endif; ?>

                        </div>
                    </div>
                </div>
            </div>

            <!-- Buttons -->
            <div class="d-flex justify-content-end mt-2">
                <button class="btn btn-primary me-2">Cập nhật</button>
                <a href="<?php echo e(route('nhacungcap')); ?>" class="btn btn-secondary">Hủy</a>
            </div>
        </div>
    </div>

</form>
<?php if(session('popup')): ?>
    <script>
        document.addEventListener("DOMContentLoaded", function() {
            // Hiển thị hộp thoại confirm
            Swal.fire({
                icon: "<?php echo e(session('status', 'info')); ?>", // Loại thông báo
                title: '',  // Tiêu đề có thể để trống hoặc chỉnh lại
                text: "<?php echo e(session('message')); ?>",  // Nội dung thông báo
                showCancelButton: false, // Ẩn nút Cancel (nếu bạn chỉ muốn "OK")
                confirmButtonText: 'OK', // Nút xác nhận "OK"
            }).then((result) => {
                // Chỉ khi người dùng nhấn OK mới chuyển trang
                if (result.isConfirmed) {
                    window.location.href = "<?php echo e(session('route')); ?>"; // Chuyển hướng
                }
            });
        });
    </script>
<?php endif; ?>





<?php $__env->stopSection(); ?>

<?php echo $__env->make('admin.layout.layout', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\Users\admin\OneDrive - Đại học FPT- FPT University\Desktop\Duantotnghiep\TechViewShop\resources\views/admin/nhacungcap/nhacungcap_edit.blade.php ENDPATH**/ ?>