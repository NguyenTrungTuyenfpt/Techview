<!DOCTYPE html>
<html>
<head>
    <title>Xác thực Email</title>
    <link rel="stylesheet" href="<?php echo e(asset('/css/email.css')); ?>">
</head>
<body>
    <div class="email">
        <h2 class="email-title">TechView Shop</h2>
        <div class="email-content">
            <h4 class="email-desc">Xin chào, <?php echo e($user->hoten); ?></h4>
            <p>Bấm vào link dưới đây để xác thực email của bạn:</p>
            <a href="<?php echo e(route('account.verifyemail', ['id' => $user->id])); ?>" class="email-link">Xác thực email</a>
        </div>
    </div>
</body>
</html>
<?php /**PATH C:\Users\admin\OneDrive - Đại học FPT- FPT University\Desktop\Duantotnghiep\TechViewShop\resources\views/client/emails/verify-email.blade.php ENDPATH**/ ?>