

<?php $__env->startSection('title', 'Trang chủ Admin'); ?>

<?php $__env->startSection('content'); ?>
<div class="container-fluid mt-5">
    <!-- Thông báo -->
    <?php if(session('error')): ?>
        <div class="alert alert-danger alert-dismissible fade show shadow-sm" role="alert" style="border-radius: 8px;">
            <i class="bi bi-exclamation-circle me-2"></i> <?php echo e(session('error')); ?>

            <button type="button" class="btn-close" data-dismiss="alert" aria-label="Close"></button>
        </div>
    <?php endif; ?>
    <?php if(session('message')): ?>
        <div class="alert alert-success alert-dismissible fade show shadow-sm" role="alert" style="border-radius: 8px;">
            <i class="bi bi-check-circle me-2"></i> <?php echo e(session('message')); ?>

            <button type="button" class="btn-close" data-dismiss="alert" aria-label="Close"></button>
        </div>
    <?php endif; ?>

    <!-- Card thông tin tổng quan -->
    <div class="row mb-4">
        <!-- Doanh thu -->
        <div class="col-md-3 col-sm-6 mb-3">
            <div class="card shadow-sm border-0">
                <div class="card-body d-flex align-items-center">
                    <span class="icon bg-primary text-white rounded-circle p-3 me-3">
                        <i class="bi bi-currency-dollar fs-4"></i>
                    </span>
                    <div>
                        <h5 class="card-title mb-1">Doanh thu</h5>
                        <p class="card-text fw-bold text-primary"><?php echo e(number_format($doanhThu, 0, ',', '.')); ?> VNĐ</p>
                        <small class="text-success"><i class="bi bi-arrow-up"></i> <?php echo e($doanhThuTang); ?>%</small>
                    </div>
                </div>
            </div>
        </div>

        <!-- Tổng đơn hàng -->
        <div class="col-md-3 col-sm-6 mb-3">
            <div class="card shadow-sm border-0">
                <div class="card-body d-flex align-items-center">
                    <span class="icon bg-success text-white rounded-circle p-3 me-3">
                        <i class="bi bi-bag-check fs-4"></i>
                    </span>
                    <div>
                        <h5 class="card-title mb-1">Tổng đơn hàng</h5>
                        <p class="card-text fw-bold text-success"><?php echo e($tongDonHang); ?></p>
                        <small class="text-danger"><i class="bi bi-arrow-down"></i> <?php echo e($donHangTang); ?>%</small>
                    </div>
                </div>
            </div>
        </div>

        <!-- Lượt xem website -->
        <div class="col-md-3 col-sm-6 mb-3">
            <div class="card shadow-sm border-0">
                <div class="card-body d-flex align-items-center">
                    <span class="icon bg-info text-white rounded-circle p-3 me-3">
                        <i class="bi bi-star fs-4"></i>
                    </span>
                    <div>
                        <h5 class="card-title mb-1">Lượt đánh giá tốt</h5>
                        <p class="card-text fw-bold text-info"><?php echo e(number_format($luotXem, 0, ',', '.')); ?></p>
                        <small class="text-primary"><i class="bi bi-arrow-up"></i> <?php echo e($luotXemTang); ?>%</small>
                    </div>
                </div>
            </div>
        </div>

        <!-- Tổng khách hàng -->
        <div class="col-md-3 col-sm-6 mb-3">
            <div class="card shadow-sm border-0">
                <div class="card-body d-flex align-items-center">
                    <span class="icon bg-warning text-white rounded-circle p-3 me-3">
                        <i class="bi bi-people fs-4"></i>
                    </span>
                    <div>
                        <h5 class="card-title mb-1">Tổng khách hàng</h5>
                        <p class="card-text fw-bold text-warning"><?php echo e($tongKhachHang); ?></p>
                        <small class="text-warning"><i class="bi bi-arrow-up"></i> <?php echo e($khachHangTang); ?>%</small>
                    </div>
                </div>
            </div>
        </div>
    </div>

    <!-- Đơn hàng mới cần xử lý -->
    <div class="card shadow-sm border-0 mb-4">
        <div class="card-header bg-light d-flex justify-content-between align-items-center">
            <h5 class="card-title mb-0 fw-bold">Đơn hàng mới cần xử lý</h5>
            <a href="<?php echo e(route('donhang')); ?>" class="btn btn-outline-primary btn-sm">Xem tất cả</a>
        </div>
        <div class="card-body">
            <div class="table-responsive">
                <table class="table table-hover align-middle">
                    <thead class="table-light">
                        <tr>
                            <th>#</th>
                            <th>Mã đơn hàng</th>
                            <th>Người nhận</th>
                            <th>SĐT</th>
                            <th>Tổng tiền</th>
                            <th>Trạng thái</th>
                            <th>Ngày tạo</th>
                            <th>Thao tác</th>
                        </tr>
                    </thead>
                    <tbody>
                        <?php $__empty_1 = true; $__currentLoopData = $donhangs; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $index => $donhang): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>
                            <tr>
                                <td><?php echo e($index + 1); ?></td>
                                <td><?php echo e($donhang->madonhang); ?></td>
                                <td><?php echo e($donhang->tennguoinhan); ?></td>
                                <td><?php echo e($donhang->sodienthoai); ?></td>
                                <td><?php echo e(number_format($donhang->tongtien, 0, ',', '.')); ?> VNĐ</td>
                                <td>
                                    <?php if($donhang->trangthai == 'pending'): ?>
                                        <span class="badge bg-warning">Chờ xử lý</span>
                                    <?php elseif($donhang->trangthai == 'completed'): ?>
                                        <span class="badge bg-success">Hoàn thành</span>
                                    <?php elseif($donhang->trangthai == 'canceled'): ?>
                                        <span class="badge bg-danger">Đã hủy</span>
                                    <?php else: ?>
                                        <span class="badge bg-secondary"><?php echo e($donhang->trangthai); ?></span>
                                    <?php endif; ?>
                                </td>
                                <td><?php echo e($donhang->created_at->format('d/m/Y H:i')); ?></td>
                                <td>
                                    <a href="<?php echo e(route('donhang.show', $donhang->id)); ?>" class="btn btn-info btn-sm me-1">
                                        <i class="bi bi-eye"></i> Chi tiết
                                    </a>
                                    <a href="<?php echo e(route('donhang.update', $donhang->id)); ?>" class="btn btn-primary btn-sm me-1">
                                        <i class="bi bi-pencil"></i> Cập nhật
                                    </a>
                                    <form action="<?php echo e(route('donhang.huy', $donhang->id)); ?>" method="POST" style="display:inline;">
                                        <?php echo csrf_field(); ?>
                                        <?php echo method_field('DELETE'); ?>
                                        <button type="submit" class="btn btn-danger btn-sm" onclick="return confirm('Bạn có chắc muốn hủy đơn hàng này?')">
                                            <i class="bi bi-trash"></i> Hủy
                                        </button>
                                    </form>
                                </td>
                            </tr>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>
                            <tr>
                                <td colspan="8" class="text-center text-muted py-4">
                                    <i class="bi bi-exclamation-circle me-2"></i> Không có đơn hàng mới nào!
                                </td>
                            </tr>
                        <?php endif; ?>
                    </tbody>
                </table>
            </div>
        </div>
    </div>

    <!-- Sản phẩm bán chạy -->
    <div class="card shadow-sm border-0 mb-4">
        <div class="card-header bg-light d-flex justify-content-between align-items-center">
            <h5 class="card-title mb-0 fw-bold">Sản phẩm bán chạy</h5>
            <a href="<?php echo e(route('sanpham')); ?>" class="btn btn-outline-primary btn-sm">Xem tất cả</a>
        </div>
        <div class="card-body">
            <div class="row">
                <?php $__empty_1 = true; $__currentLoopData = $sanPhamBanChay; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $sp): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>
                    <div class="col-md-3 col-sm-6 mb-3">
                        <div class="card shadow-sm border-0 product-card">
                            <img src="<?php echo e(asset($sp->hinh)); ?>" class="card-img-top product-img img-fluid" alt="<?php echo e($sp->tensp); ?>" style="height: 150px; object-fit: cover;">
                            <div class="card-body text-center">
                                <h6 class="card-title product-name mb-1"><?php echo e($sp->tensp); ?></h6>
                                <p class="card-text product-price text-primary fw-bold"><?php echo e(number_format($sp->gia, 0, ',', '.')); ?> VNĐ</p>
                                <small class="text-muted">Đã bán: <?php echo e($sp->soLuongBan); ?></small>
                            </div>
                        </div>
                    </div>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>
                    <div class="col-12 text-center text-muted py-4">
                        <i class="bi bi-exclamation-circle me-2"></i> Không có sản phẩm bán chạy nào!
                    </div>
                <?php endif; ?>
            </div>
        </div>
    </div>
</div>

<style>
    .icon {
        display: inline-flex;
        align-items: center;
        justify-content: center;
        width: 50px;
        height: 50px;
    }
    .card {
        transition: transform 0.3s ease, box-shadow 0.3s ease;
    }
    .card:hover {
        transform: translateY(-5px);
        box-shadow: 0 10px 20px rgba(0, 0, 0, 0.1) !important;
    }
    .table th, .table td {
        vertical-align: middle;
    }
    .badge {
        font-size: 0.9rem;
    }
    .product-card {
        border-radius: 10px;
        overflow: hidden;
    }
    .product-name {
        font-size: 1rem;
        font-weight: 500;
        white-space: nowrap;
        overflow: hidden;
        text-overflow: ellipsis;
    }
    .product-price {
        font-size: 1.1rem;
    }
</style>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('admin.layout.layout', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\Users\admin\OneDrive - Đại học FPT- FPT University\Desktop\Duantotnghiep\TechViewShop\resources\views/admin/index.blade.php ENDPATH**/ ?>