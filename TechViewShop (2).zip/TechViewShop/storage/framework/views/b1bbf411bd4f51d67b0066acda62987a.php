
<?php $__env->startSection('title'); ?>
    Tài khoản
<?php $__env->stopSection(); ?>
<?php $__env->startSection('body'); ?>
    <section class="section-account">
        <div class="grid wide container">
            <div class="row">
                <div class="col l-3 m-12">
                    <div class="left-ac">
                        <h5 class="account-title">TÀI KHOẢN</h5>
                        <div class="account-avatar">
                            <img src="<?php echo e(asset($user->hinh ? '/img/'.$user->hinh : '/img/default-avatar.jpg')); ?>" alt="Avatar" class="avatar-img">
                            <div class="change-icon">
                                <div class="change-icon__link">
                                    <i class="change-icon__pen fa-solid fa-pencil"></i>
                                </div>
                            </div>
                        </div>

                        <p class="account-desc">
                            Xin chào, 
                            <span class="account-name"> <?php echo e($user->hoten); ?>&nbsp;!</span>
                        </p>
                        
                        <ul class="account__list">
                            <li class="title-info title-active"><a href="#">Thông tin tài khoản</a></li>
                            <li class="title-info"><a href="#">Đơn hàng của bạn</a></li>
                            <li class="title-info"><a href="#">Đổi mật khẩu</a></li>
                            <li class="title-info"><a href="<?php echo e(route('account.logout')); ?>">Đăng xuất</a></li>
                        </ul>
                    </div>
                </div>
                <div class="col l-9 m-12 c-12">
                    <div class="right-ac">
                        <!-- Thông tin tài khoản -->
                        <section class="account__infor content-section section-active">
                            <h1 class="title-head-info">Thông tin tài khoản</h1>
                            <button type="button" class="btn-address">Cập nhật</button>
                           
                            <div class="account__infor-name">
                                <p class="account__infor-item">
                                    <strong class="account__infor-title">Họ tên:</strong>
                                    <?php echo e($user->hoten); ?>

                                    <span class="address-default">Mặc định</span>
                                </p>

                                <?php if($user->ngaysinh): ?>
                                    <p class="account__infor-item">
                                        <strong class="account__infor-title">Ngày sinh:</strong>
                                        <?php echo e($user->ngaysinh); ?>

                                    </p>
                                <?php endif; ?>
                                
                                <?php if($user->sodienthoai): ?>
                                    <p class="account__infor-item">
                                        <strong class="account__infor-title">Số điện thoại:</strong>
                                        <?php echo e($user->sodienthoai); ?>

                                    </p>
                                <?php endif; ?>

                                <p class="account__infor-item">
                                    <strong class="account__infor-title">Email:</strong>
                                    <?php echo e($user->email); ?>

                                </p>

                                <?php if($user->diachi): ?>
                                    <p class="account__infor-item">
                                        <strong class="account__infor-title">Địa chỉ:</strong>
                                        <?php echo e($user->diachi); ?>

                                    </p>
                                <?php endif; ?>
                            </div>
                        </section> 
                        
                        <!-- Đơn hàng của bạn -->
                        <section class="order-history content-section">
                            <h1 class="title-head">Đơn hàng của bạn</h1>
                            <div class="table-responsive">
                                <table class="table-order">
                                    <thead>
                                        <tr>
                                            <th width="100px">Đơn hàng</th>
                                            <th width="120px">Ngày</th>
                                            <th class="address-column">Địa chỉ</th>
                                            <th width="130px">Giá trị đơn hàng</th>
                                            <th width="150px">PT thanh toán</th>
                                            <th width="140px">TT thanh toán</th>
                                            <th width="100px">TT đơn hàng</th>
                                        </tr>
                                    </thead>
                                    <tbody>
                                        <?php if($orders->isNotEmpty()): ?>
                                            <?php $__currentLoopData = $orders; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $order): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                                <tr>
                                                    <td> #<?php echo e($order->madonhang); ?> </td>
                                                    <td> <?php echo e(\Carbon\Carbon::parse($order->ngaytao)->format('d-m-Y H:s:m')); ?> </td>
                                                    <td> <?php echo e($order->diachi ?? $user->diachi); ?> </td>
                                                    <td class="table-text-center"> <?php echo e(number_format($order->tongtien)); ?>₫ </td>
                                                    <td class="status-load table-text-center"><?php echo e($order->phuongthucthanhtoan); ?></td>
                                                    <td class="payment-status table-text-center"><?php echo e($order->trangthaithanhtoan); ?></td>
                                                    <td class="order-status table-text-center"><?php echo e($order->trangthai); ?></td>
                                                </tr>
                                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                        <?php else: ?>
                                            <td colspan="7">Bạn chưa có đơn hàng</td>
                                        <?php endif; ?>
                                    </tbody>
                                </table>
                            </div>
                        </section>
                    
                        <!-- Đổi mật khẩu -->
                        <section class="change-password content-section">
                            <h1 class="title-head">Đổi mật khẩu</h1>
                            <form action="<?php echo e(route('account.changepassword')); ?>" method="post" class="change__password-form">
                                <?php echo csrf_field(); ?>
                                <div class="form-group">
                                    <label for="old-password" class="change-password__title">Mật khẩu cũ<span class="required">&nbsp;</span>:</label>
                                    <div class="input-item">
                                        <input class="change-password__input" type="password" name="old-password" id="old-password">
                                        <i class="input-icon fa-regular fa-eye toggle-password" data-target="old-password"></i>
                                    </div>                               
                                </div>
                                <?php $__errorArgs = ['old-password'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                    <div class="message"><?php echo e($message); ?></div>
                                <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                                <div class="form-group">
                                    <label for="new-password" class="change-password__title">Mật khẩu mới<span class="required">&nbsp;</span>:</label>
                                    <div class="input-item">
                                        <input class="change-password__input" type="password" name="new-password" id="new-password">
                                        <i class="input-icon fa-regular fa-eye toggle-password" data-target="new-password"></i>
                                    </div>
                                </div>
                                <?php $__errorArgs = ['new-password'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                    <div class="message"><?php echo e($message); ?></div>
                                <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                                <div class="form-group">
                                    <label for="confirm_password" class="change-password__title">Nhập lại mật khẩu<span class="required">&nbsp;</span>:</label>
                                    <div class="input-item">
                                        <input class="change-password__input" type="password" name="new-password_confirmation" id="confirm_password">
                                        <i class="input-icon fa-regular fa-eye toggle-password" data-target="confirm_password"></i>
                                    </div>
                                </div>
                                <?php $__errorArgs = ['new-password_confirmation'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                    <div class="message"><?php echo e($message); ?></div>
                                <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                                <?php if(session('message')): ?>
                                    <div class="message">
                                        <?php echo e(session('message')); ?>

                                    </div>
                                <?php endif; ?>
                                <button type="submit" class="btn-change">Đặt lại mật khẩu</button>
                            </form>
                        </section>
                    
                        <!-- form cập nhật thông tin -->
                        <div class="modal_overlay"></div>
                        <section class="modal_address" id="modal_address">
                            <div class="modal-header">
                                <h2 class="title-address">CẬP NHẬT THÔNG TIN</h2>
                                <i class="fa-solid fa-xmark close-modal"></i>
                            </div>
                            <form action="<?php echo e(route('account.updateprofile')); ?>" method="post" enctype="multipart/form-data" class="address-form" >
                                <?php echo csrf_field(); ?>
                                <div class="address-group">
                                    <div class="address-item address-item-gap">
                                        <label for="name" class="">Họ và tên:</label>
                                        <input type="text" class="input-address" name="name" id="name" value="<?php echo e(old('name', $user->hoten)); ?>">
                                    </div>
                                    <?php $__errorArgs = ['name'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                        <div class="message">
                                            <?php echo e($message); ?>

                                        </div>
                                    <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                                    <div class="address-item">
                                        <label for="birth">Ngày sinh:</label>
                                        <input type="date" class="input-address" name="birth" id="birth" value="<?php echo e(old('birth', $user->ngaysinh)); ?>" >
                                    </div>
                                    <?php $__errorArgs = ['birth'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                        <div class="message">
                                            <?php echo e($message); ?>

                                        </div>
                                    <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                                </div>
                                <div class="address-item">
                                    <label for="email">Email:</label>
                                    <input type="text" class="input-address" name="email" id="email" value="<?php echo e(old('email', $user->email)); ?>" >
                                </div>
                                <?php $__errorArgs = ['email'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                    <div class="message">
                                        <?php echo e($message); ?>

                                    </div>
                                <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                                <div class="account-group">
                                    <div class="address-item address-item-gap">
                                        <label for="phone">Số điện thoại:</label>
                                        <input type="text" class="input-address" name="phone" id="phone" value="<?php echo e(old('phone', $user->sodienthoai)); ?>" >
                                    </div>
                                    <?php $__errorArgs = ['phone'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                        <div class="message">
                                            <?php echo e($message); ?>

                                        </div>
                                    <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                                    <div class="account-gender">
                                        <span for="" class="gender-title">Giới tính:</span>
                                        <div class="gender-group">
                                            <input type="radio" class="gender-item" name="gender" value="nam" <?php echo e(old('gender', $user->gioitinh) == 'nam' ? 'checked' : ''); ?>>
                                            <label for="" class="gender-name">Nam</label>
                                        </div>
                                        <div class="gender-group">
                                            <input type="radio" class="gender-item" name="gender" value="nu" <?php echo e(old('gender', $user->gioitinh) == 'nu' ? 'checked' : ''); ?>>
                                            <label for="" class="gender-name">Nữ</label>
                                        </div>
                                        <div class="gender-group">
                                            <input type="radio" class="gender-item" name="gender" value="khac" <?php echo e(old('gender', $user->gioitinh) == 'khac' ? 'checked' : ''); ?>>
                                            <label for="" class="gender-name">Khác</label>
                                        </div>
                                    </div>
                                    <?php $__errorArgs = ['gender'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                        <div class="message">
                                            <?php echo e($message); ?>

                                        </div>
                                    <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                                </div>
                                <div class="address-item">
                                    <label for="address">Địa chỉ:</label>
                                    <input type="text" class="input-address" name="address" id="address" value="<?php echo e(old('address', $user->diachi)); ?>">
                                </div>
                                <?php $__errorArgs = ['address'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                    <div class="message">
                                        <?php echo e($message); ?>

                                    </div>
                                <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                                <div class="address-item">
                                    <label for="avatar">Chọn hình:</label>
                                    <input type="file" class="" name="avatar" id="avatar">
                                    <span id="file-name">
                                        <?php echo e($user->hinh ?? $user->hinh); ?>

                                    </span>
                                </div>
                                <?php $__errorArgs = ['avatar'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                    <div class="message">
                                        <?php echo e($message); ?>

                                    </div>
                                <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>

                                <?php if(session('message')): ?>
                                    <div class="message">
                                        <?php echo e(session('message')); ?>

                                    </div>
                                <?php endif; ?>
                                <div class="form-actions">
                                    <button type="submit" class="btn-update" id="openModal">CẬP NHẬT</button>
                                </div> 
                            </form>
                        </section>

                        
                        <div class="modal_overlay2"></div>
                        <section class="modal-avatar" id="modal_avatar">
                            <div class="modal-avatar__title">
                                <h2 class="title-avatar">THAY ĐỔI HÌNH ẢNH</h2>
                                <i class="fa-solid fa-xmark close-modal-avatar"></i>
                            </div>
                            <form action="<?php echo e(route('account.changeavatar')); ?>" method="post" enctype="multipart/form-data" class="address-form"> 
                                <?php echo csrf_field(); ?>
                                <div class="avater-item">
                                    <label for="avatar">Chọn ảnh:</label>
                                    <input type="file" name="avatar" accept="image/*">
                                </div>
                                <?php $__errorArgs = ['avatar'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                    <div class="message">
                                        <?php echo e($message); ?>

                                    </div>
                                <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>

                                <?php if(session('message')): ?>
                                    <div class="message">
                                        <?php echo e(session('message')); ?>

                                    </div>
                                <?php endif; ?>
                                <button type="submit" class="btn-avt" id="openAvatar">Thay đổi</button>
                            </form>
                        </section>
                    </div>

                </div>
            </div>
        </div>
    </section>


    <script>
        document.addEventListener('DOMContentLoaded', function() {
            function applyStatusStyles(selecter) {
                document.querySelectorAll(selecter).forEach(function (element) {
                    const status = element.innerText;

                    if(status === 'Hoàn thành' || status === 'Đã thanh toán') {
                        element.classList.add("status-success");
                    }
                    if(status === 'Đang xử lý' || status === 'Đã xác nhận' || status === 'Đang giao') {
                        element.classList.add("status-load");
                    } 
                    if(status === 'Chưa thanh toán') {
                        element.classList.add("status-fail");
                    }
                })
            }
            // Áp dụng style cho các cột trạng thái
            applyStatusStyles(".payment-status");
            applyStatusStyles(".order-status");
        });
    </script>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('client.layout.layout', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\Users\admin\OneDrive - Đại học FPT- FPT University\Desktop\Duantotnghiep\TechViewShop\resources\views/client/pages/profile.blade.php ENDPATH**/ ?>