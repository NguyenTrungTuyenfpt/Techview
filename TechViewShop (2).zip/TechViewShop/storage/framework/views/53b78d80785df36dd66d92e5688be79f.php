<div class="admin d-flex">
    <!-- Sidebar -->
    <!-- Sidebar (Menu trái) -->
    <nav class="admin-menu d-flex flex-column align-items-center">
        <!-- Logo -->
        <!-- <a href="#" class="navbar-logo mb-3">
            <img src="<?php echo e(asset('img/logo.png')); ?>" alt="logo">

        </a> -->
        <button class="btn btn-outline-primary d-lg-none me-3" id="toggle-menu">
            <i class="bi bi-list"></i>
        </button>

        <!-- Menu -->
        <ul class="nav flex-column w-100">
            <li class="nav-item">
                <a class="nav-link menu-item active" href="/admin"><i class="bi bi-menu-button"></i> Trang chủ</a>
            </li>
            <li class="nav-item">
                <a class="nav-link menu-item" href="<?php echo e(route('danhmuc')); ?>"><i class="bi bi-folder"></i> Danh mục sản phẩm</a>
            </li>

            <li class="nav-item">
                <a class="nav-link menu-item" href="<?php echo e(route('sanpham')); ?>"><i class="bi bi-box"></i> Sản phẩm</a>
            </li>
         
            <li class="nav-item">
                <a class="nav-link menu-item" href="<?php echo e(route('donhang')); ?>"><i class="bi bi-cart-check"></i> Đơn hàng</a>
            </li>
            <li class="nav-item">
                <a class="nav-link menu-item" href="<?php echo e(route('khachhang')); ?>"><i class="bi bi-people"></i> Khách hàng</a>
            </li>
            <li class="nav-item">
                <a class="nav-link menu-item" href="<?php echo e(route('nhanvien')); ?>"><i class="bi bi-person-gear"></i> Nhân viên</a>
            </li>
            <li class="nav-item">
                <a class="nav-link menu-item" href="<?php echo e(route('binhluan')); ?>"><i class="bi bi-chat-square-text"></i> Bình luận bài viết</a>
            </li>
            <li class="nav-item">
                <a class="nav-link menu-item" href="<?php echo e(route('danhgia')); ?>"> <i class="bi bi-star-fill"></i> Đánh giá</a>
            </li>
            <li class="nav-item">
                <a class="nav-link menu-item" href="<?php echo e(route('baiviet')); ?>"><i class="bi bi-file-earmark-text"></i> Bài viết</a>
            </li>
            <li class="nav-item">
                <a class="nav-link menu-item" href="<?php echo e(route('danhmucbaiviet.index')); ?>"><i class="bi bi-file-earmark-text"></i> Danh mục bài viết</a>
            </li>
            <li class="nav-item">
                <a class="nav-link menu-item" href="<?php echo e(route('khuyenmai')); ?>"><i class="bi bi-tags"></i> Khuyến mãi</a>
            </li>
            <li class="nav-item">
                <a class="nav-link menu-item" href="<?php echo e(route('thongke.index')); ?>"><i class="bi bi-bar-chart"></i> Thống kê</a>
            </li>
            <li class="nav-item">
                <a class="nav-link menu-item" href="<?php echo e(route('nhacungcap')); ?>"><i class="bi bi-shop"></i> Nhà cung cấp</a>
            </li>

            <li class="nav-item">
                <a class="nav-link menu-item" href="<?php echo e(route('banner')); ?>"> <i class="bi bi-image"></i> Banner</a>
            </li>
        </ul>
    </nav>
    <!-- danhmucbaiviet.index -->


    <div class="content w-100">
        <!-- Navbar Top -->
        <nav class="navbar navbar-expand-lg navbar-light bg-white border-bottom px-4 py-2">
            <div class="container-fluid">
                <!-- Ô tìm kiếm -->
                <div class="position-relative">
                    <input class="form-control search-box" type="search" placeholder="Tìm kiếm">
                    <i class="bi bi-search search-icon"></i>
                </div>

                <!-- Các icon chức năng -->
                <div class="d-flex align-items-center ms-auto">
                    <i class="bi bi-moon me-3"></i>
                    <i class="bi bi-fullscreen me-3"></i>
                    <i class="bi bi-chat-dots me-3 position-relative">
                        <span
                            class="position-absolute top-0 start-100 translate-middle p-1 bg-success border border-light rounded-circle"></span>
                    </i>
                    <i class="bi bi-bell position-relative me-3">
                        <span
                            class="position-absolute top-0 start-100 translate-middle badge rounded-pill bg-primary">4</span>
                    </i>

                    <!-- Avatar với dropdown -->
                    <div class="dropdown">
                        <a class="nav-link dropdown-toggle d-flex align-items-center" href="#" role="button"
                            data-bs-toggle="dropdown">
                            <!-- <img src="<?php echo e(asset('uploads/Users/' . auth()->user()->hinh)); ?>" alt="Avatar" class="rounded-circle me-2" width="40"
                                height="40"> -->
                            <img src="<?php echo e(auth()->user()->hinh ? asset('uploads/Users/' . auth()->user()->hinh) : asset('uploads/Users/default-avatar.png')); ?>"
                                alt="Avatar" class="rounded-circle me-2  " width="40">
                            <div>
                                <!-- <span class="fw-bold"><?php echo e(auth()->user()->hoten); ?></span>
                                <small class="d-block text-muted"><?php echo e(auth()->user()->diachi); ?></small> -->

                                <span class="fw-bold small text-muted">Xin chào, <?php echo e(auth()->user()->hoten); ?></span>
                                <small class="d-block small  text-muted "><?php echo e(auth()->user()->diachi); ?></small>

                            </div>
                        </a>
                        <ul class="dropdown-menu dropdown-menu-end">
                        <li><a class="dropdown-item" href="<?php echo e(route('user.profile')); ?>">Cập nhật</a></li>
                            <!-- <li><a class="dropdown-item text-danger" href="<?php echo e(route('auth.logout')); ?>">Đăng xuất</a></li> -->
                            <li>
                                <a href="#" class="dropdown-item text-danger" id="logout-link">Đăng xuất</a>
                                <form id="logout-form" action="<?php echo e(route('auth.logout')); ?>" method="POST" style="display: none;">
                                    <?php echo csrf_field(); ?>
                                </form>
                            </li>
                        </ul>
                    </div>
                </div>
            </div>
        </nav><?php /**PATH C:\Users\admin\OneDrive - Đại học FPT- FPT University\Desktop\Duantotnghiep\TechViewShop\resources\views/admin/layout/header.blade.php ENDPATH**/ ?>