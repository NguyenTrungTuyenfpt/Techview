

<?php $__env->startSection('title', 'Chi tiết danh mục'); ?>

<?php $__env->startSection('content'); ?>
<div class="container mt-5">
    <div class="row justify-content-center">
        <div class="col-lg-12">
            <!-- Card chính -->
            <div class="card border-0 shadow-lg rounded-3">
                <div class="card-header bg-primary text-white p-4 rounded-top">
                    <h2 class="mb-0">Chi tiết danh mục: <?php echo e($danhmuc->tendm); ?></h2>
                </div>
                <div class="card-body p-4">
                    <!-- Thông tin danh mục -->
                    <div class="row mb-4">
                        <div class="col-12">
                            <div class="p-3 bg-light rounded">
                                <h5 class="text-muted mb-3">Thông tin cơ bản</h5>
                                <div class="row align-items-center">
                                    <!-- Thông tin -->
                                    <div class="col-md-8">
                                        <ul class="list-unstyled">
                                            <li class="mb-2">
                                                <strong class="text-dark">Mô tả:</strong> 
                                                <span><?php echo e($danhmuc->mota); ?></span>
                                            </li>
                                            <li class="mb-2">
                                                <strong class="text-dark">Số sản phẩm:</strong> 
                                                <span class="badge bg-info"><?php echo e($danhmuc->sanphams->count()); ?></span>
                                            </li>
                                            <li class="mb-2">
                                                <strong class="text-dark">Thứ tự:</strong> 
                                                <span><?php echo e($danhmuc->thutu); ?></span>
                                            </li>
                                            <li>
                                                <strong class="text-dark">Ẩn/Hiện:</strong> 
                                                <?php if($danhmuc->anhien): ?>
                                                    <span class="badge bg-success px-2 py-1">Hiện</span>
                                                <?php else: ?>
                                                    <span class="badge bg-danger px-2 py-1">Ẩn</span>
                                                <?php endif; ?>
                                            </li>
                                        </ul>
                                    </div>
                                    <!-- Ảnh danh mục -->
                                    <div class="col-md-4 text-center">
                                        <?php if($danhmuc->hinh): ?>
                                            <img src="<?php echo e(asset('uploads/danhmuc/' . $danhmuc->hinh)); ?>" 
                                                 alt="<?php echo e($danhmuc->tendm); ?>" 
                                                 class="img-fluid rounded shadow-sm" 
                                                 style="max-width: 150px; max-height: 150px;">
                                            <p class="text-muted mt-2 small">Ảnh danh mục</p>
                                        <?php else: ?>
                                            <div class="bg-white rounded p-3 border" style="width: 150px; height: 150px;">
                                                <i class="bi bi-image text-muted" style="font-size: 2rem;"></i>
                                                <p class="text-muted mt-2 small">Chưa có ảnh</p>
                                            </div>
                                        <?php endif; ?>
                                    </div>
                                </div>
                            </div>
                        </div>
                    </div>

                    <!-- Nút hành động -->
                    <div class="text-end mb-4">
                        <a href="<?php echo e(route('danhmuc.edit', $danhmuc->id)); ?>" class="btn btn-success btn-sm me-2">
                            <i class="bi bi-pencil"></i> Sửa
                        </a>
                        <a href="<?php echo e(route('danhmuc')); ?>" class="btn btn-outline-secondary btn-sm">
                            <i class="bi bi-arrow-left"></i> Quay lại
                        </a>
                    </div>

                    <!-- Sản phẩm bán chạy -->
                    <div class="mt-4">
                        <h4 class="text-primary mb-3">Sản phẩm bán chạy</h4>
                        <?php if($sanphamBanChay->isNotEmpty()): ?>
                            <div class="table-responsive shadow-sm rounded">
                                <table class="table table-hover align-middle mb-0">
                                    <thead class="bg-light">
                                        <tr>
                                            <th class="ps-3">ID</th>
                                            <th>Tên sản phẩm</th>
                                            <th>Giá</th>
                                            <th>Ảnh</th>
                                            <th>Mô tả</th>
                                            <th>Đã bán</th>
                                        </tr>
                                    </thead>
                                    <tbody>
                                        <?php $__currentLoopData = $sanphamBanChay; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $sp): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                        <tr>
                                            <td class="ps-3"><?php echo e($sp->id); ?></td>
                                            <td><?php echo e($sp->tensp); ?></td>
                                            <td><?php echo e(number_format($sp->gia)); ?> đ</td>
                                            <td>
                                                <img src="<?php echo e(asset('uploads/sanpham/' . $sp->hinh)); ?>" 
                                                     alt="<?php echo e($sp->tensp); ?>" 
                                                     class="img-fluid rounded" 
                                                     style="max-width: 60px;">
                                            </td>
                                            <td><?php echo e(Str::limit($sp->mota, 50)); ?></td>
                                            <td>
                                                <span class="badge bg-primary"><?php echo e($sp->da_ban); ?></span>
                                            </td>
                                        </tr>
                                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                    </tbody>
                                </table>
                            </div>
                        <?php else: ?>
                            <div class="alert alert-warning text-center" role="alert">
                                <i class="bi bi-exclamation-triangle me-2"></i>
                                Chưa có sản phẩm nào được bán trong danh mục này.
                            </div>
                        <?php endif; ?>
                    </div>
                </div>
            </div>
        </div>
    </div>
</div>

<style>
    .card {
        transition: transform 0.3s ease, box-shadow 0.3s ease;
    }
    .card:hover {
        transform: translateY(-5px);
        box-shadow: 0 10px 20px rgba(0, 0, 0, 0.1) !important;
    }
    .table th, .table td {
        vertical-align: middle;
    }
    .btn-sm {
        padding: 0.4rem 0.8rem;
    }
</style>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('admin.layout.layout', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\Users\admin\OneDrive - Đại học FPT- FPT University\Desktop\Duantotnghiep\TechViewShop\resources\views/admin/danhmucsp/chitietdanhmuc.blade.php ENDPATH**/ ?>