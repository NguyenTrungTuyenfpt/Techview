

<?php $__env->startSection('title', 'Danh sách đơn hàng'); ?>

<?php $__env->startSection('content'); ?>
<div class="container mt-5">
    <div class="row justify-content-center">
        <div class="col-lg-12">
            <!-- Header -->
            <div class="d-flex justify-content-between align-items-center mb-4">
                <h2 class="fw-bold text-primary">Danh sách đơn hàng</h2>
            </div>

            <!-- Card chính -->
            <div class="card border-0 shadow-lg rounded-3">
                <div class="card-body p-4">
                    <!-- Tìm kiếm và sắp xếp -->
                    <div class="row mb-4">
                        <div class="col-md-6 mb-3 mb-md-0">
                            <form method="GET" action="<?php echo e(route('donhang')); ?>">
                                <div class="input-group">
                                    <input type="text" name="search" class="form-control" placeholder="Tìm kiếm đơn hàng" value="<?php echo e(request('search')); ?>">
                                    <button class="btn btn-primary" type="submit">
                                        <i class="bi bi-search"></i> Tìm kiếm
                                    </button>
                                </div>
                            </form>
                        </div>
                        <div class="col-md-6 text-md-end">
                            <div class="btn-group">
                                <a href="<?php echo e(route('donhang', ['sort' => 'id', 'direction' => request('direction', 'asc') == 'asc' ? 'desc' : 'asc'])); ?>"
                                   class="btn btn-outline-primary btn-sm">
                                    Theo ID
                                    <i class="bi <?php echo e(request('sort') == 'id' && request('direction') == 'asc' ? 'bi-sort-down' : 'bi-sort-up'); ?>"></i>
                                </a>
                                <a href="<?php echo e(route('donhang', ['sort' => 'ngaytao', 'direction' => request('direction', 'asc') == 'asc' ? 'desc' : 'asc'])); ?>"
                                   class="btn btn-outline-primary btn-sm">
                                    Theo Ngày tạo
                                    <i class="bi <?php echo e(request('sort') == 'ngaytao' && request('direction') == 'asc' ? 'bi-sort-down' : 'bi-sort-up'); ?>"></i>
                                </a>
                            </div>
                        </div>
                    </div>

                    <!-- Thông báo lỗi -->
                    <?php if($errors->any()): ?>
                        <div class="alert alert-danger alert-dismissible fade show" role="alert">
                            <ul class="mb-0">
                                <?php $__currentLoopData = $errors->all(); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $error): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                    <li><?php echo e($error); ?></li>
                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                            </ul>
                            <button type="button" class="btn-close" data-bs-dismiss="alert" aria-label="Close"></button>
                        </div>
                    <?php endif; ?>

                    <!-- Bảng đơn hàng -->
                    <div class="table-responsive">
                        <table class="table table-hover align-middle">
                            <thead class="table-light">
                                <tr>
                                    <th>ID</th>
                                    <th>Mã đơn hàng</th>
                                    <th>Người nhận</th>
                                    <th>SĐT</th>
                                    <th>Tổng tiền</th>
                                    <th>Trạng thái</th>
                                    <th>Ngày tạo</th>
                                    <th>Thao tác</th>
                                </tr>
                            </thead>
                            <tbody>
                                <?php $__empty_1 = true; $__currentLoopData = $donhangs; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $donhang): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>
                                    <tr>
                                        <td><?php echo e($donhang->id); ?></td>
                                        <td><?php echo e($donhang->madonhang); ?></td>
                                        <td><?php echo e($donhang->tennguoinhan); ?></td>
                                        <td><?php echo e($donhang->sodienthoai); ?></td>
                                        <td><?php echo e(number_format($donhang->tongtien, 0, ',', '.')); ?> VNĐ</td>
                                        <td>
                                            <?php if($donhang->trangthai == 'pending'): ?>
                                            <span class="badge bg-warning">Chờ xử lý</span>
                                            <?php elseif($donhang->trangthai == 'completed'): ?>
                                            <span class="badge bg-success">Hoàn thành</span>
                                            <?php elseif($donhang->trangthai == 'canceled'): ?>
                                            <span class="badge bg-danger">Đã hủy</span>
                                            <?php else: ?>
                                            <span class="badge bg-secondary"><?php echo e($donhang->trangthai); ?></span>
                                            <?php endif; ?>
                                        </td>
                                        <td><?php echo e(date('d/m/Y H:i', strtotime($donhang->ngaytao))); ?></td>
                                        <td>
                                            <a href="<?php echo e(route('donhang.show', $donhang->id)); ?>" class="btn btn-info btn-sm">Chi tiết</a>
                                            <?php if($donhang->trangthai != 'hoàn thành' && $donhang->trangthai != 'đã hủy'): ?>
                                            <button type="button" class="btn btn-primary" id="btnUpdate<?php echo e($donhang->id); ?>">Cập nhật</button>

                                            <!-- Form ẩn, chỉ hiển thị khi click vào nút Cập nhật -->
                                            <div id="formUpdate<?php echo e($donhang->id); ?>" style="display: none;">
                                                <form action="<?php echo e(route('donhang.update', $donhang->id)); ?>" method="POST">
                                                    <?php echo csrf_field(); ?>
                                                    <?php echo method_field('PUT'); ?>

                                                    <div class="mb-3">
                                                        <label for="trangthai" class="form-label small text-muted">Trạng thái:</label>
                                                        <div class="d-flex align-items-center">
                                                            <select name="trangthai" id="trangthai" class="form-select me-1">
                                                                <option value="đang xử lý" <?php echo e($donhang->trangthai == 'đang xử lý' ? 'selected' : ''); ?>>Đang xử lý</option>
                                                                <option value="đã xác nhận" <?php echo e($donhang->trangthai == 'đã xác nhận' ? 'selected' : ''); ?>>Đã xác nhận</option>
                                                                <option value="hoàn thành" <?php echo e($donhang->trangthai == 'hoàn thành' ? 'selected' : ''); ?>>Hoàn thành</option>
                                                                <option value="đã hủy" <?php echo e($donhang->trangthai == 'đã hủy' ? 'selected' : ''); ?>>Đã hủy</option>
                                                            </select>
                                                            <button type="submit" class="small btn btn-primary btn-sm">Cập nhật</button>
                                                        </div>
                                                    </div>
                                                </form>
                                            </div>
                                            <?php endif; ?>

                                            <?php if($donhang->trangthai != 'hoàn thành' && $donhang->trangthai != 'đã hủy'): ?>
                                            <form action="<?php echo e(route('donhang.huy', $donhang->id)); ?>" method="POST" style="display:inline;">
                                                <?php echo csrf_field(); ?>
                                                <?php echo method_field('DELETE'); ?>
                                                <button type="submit" class="btn btn-danger btn-sm" onclick="return confirm('Bạn có chắc muốn xóa đơn hàng này?')">Hủy</button>
                                            </form>
                                            <?php endif; ?>
                                        </td>
                                    </tr>
                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>
                                    <tr>
                                        <td colspan="8" class="text-center text-muted py-4">
                                            <i class="bi bi-exclamation-circle me-2"></i> Không có đơn hàng nào.
                                        </td>
                                    </tr>
                                <?php endif; ?>
                            </tbody>
                        </table>
                    </div>

                    <!-- Phân trang -->
                    <div class="mt-4">
                        <?php echo e($donhangs->appends(request()->query())->links('pagination::bootstrap-5')); ?>

                    </div>
                </div>
            </div>
        </div>
    </div>
</div>

<script>
    document.getElementById('btnUpdate<?php echo e($donhang->id ?? 0); ?>').addEventListener('click', function() {
        var formUpdate = document.getElementById('formUpdate<?php echo e($donhang->id ?? 0); ?>');
        var buttonUpdate = document.getElementById('btnUpdate<?php echo e($donhang->id ?? 0); ?>');
        formUpdate.style.display = 'block';
        buttonUpdate.style.display = 'none';
    });
</script>

<?php $__env->stopSection(); ?>

<?php echo $__env->make('admin.layout.layout', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\Users\admin\OneDrive - Đại học FPT- FPT University\Desktop\Duantotnghiep\TechViewShop\resources\views/admin/donhang/donhang.blade.php ENDPATH**/ ?>