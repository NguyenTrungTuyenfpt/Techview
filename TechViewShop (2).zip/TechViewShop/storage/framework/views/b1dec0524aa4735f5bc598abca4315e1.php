

<?php $__env->startSection('title', 'Khách hàng'); ?>

<?php $__env->startSection('content'); ?>
<div class="container py-4">
    <div class="row">
        <!-- Sidebar trái: Thông tin khách hàng -->
        <div class="col-md-4">
            <div class="card mb-4 shadow-sm">
                <div class="card-body">
                    <h4 class="card-title">Thông tin khách hàng</h4>
                    <p><strong>Họ tên:</strong> <?php echo e($khachhang->hoten); ?></p>
                    <p><strong>Email:</strong> <?php echo e($khachhang->email); ?></p>
                    <p><strong>SĐT:</strong> <?php echo e($khachhang->sodienthoai); ?></p>
                    <p><strong>Địa chỉ:</strong> <?php echo e($khachhang->diachi); ?></p>
                    <p><strong>Ngày đăng ký:</strong> <?php echo e($khachhang->created_at); ?></p>
                    <p><strong>Trạng thái:</strong>
                        <?php if($khachhang->trangthai == '1'): ?>
                        <span class="badge bg-success">Đang hoạt động</span>
                        <?php else: ?>
                        <span class="badge bg-danger">Đã khóa</span>
                        <?php endif; ?>
                    </p>
                    <hr>
                    <p><strong>Tổng đơn hàng:</strong> <?php echo e($tongDon); ?></p>
                    <p><strong>Tổng tiền đã chi:</strong> <?php echo e(number_format($tongTien, 0, ',', '.')); ?>đ</p>
                    <p><strong>Số đánh giá:</strong> <?php echo e($soDanhGia); ?></p>
                </div>
            </div>
        </div>

        <!-- Nội dung chính: Tabs -->
        <div class="col-md-8">
            <ul class="nav nav-tabs" id="customerTabs" role="tablist">
                <li class="nav-item" role="presentation">
                    <button class="nav-link active" data-bs-toggle="tab" data-bs-target="#orders" type="button" role="tab">Đơn hàng</button>
                </li>
                <li class="nav-item" role="presentation">
                    <button class="nav-link" data-bs-toggle="tab" data-bs-target="#stats" type="button" role="tab">Thống kê</button>
                </li>
                <li class="nav-item" role="presentation">
                    <button class="nav-link" data-bs-toggle="tab" data-bs-target="#top-products" type="button" role="tab">Sản phẩm mua nhiều</button>
                </li>
                <li class="nav-item" role="presentation">
                    <button class="nav-link" data-bs-toggle="tab" data-bs-target="#reviews" type="button" role="tab">Đánh giá</button>
                </li>
                <li class="nav-item" role="presentation">
                    <button class="nav-link" data-bs-toggle="tab" data-bs-target="#actions" type="button" role="tab">Hành động</button>
                </li>
            </ul>
            <div class="tab-content border border-top-0 p-3 bg-white shadow-sm">

                <!-- Đơn hàng -->
                <div class="tab-pane fade show active" id="orders" role="tabpanel">
                    <h5>Lịch sử đơn hàng</h5>
                    <table class="table table-striped">
                        <thead>
                            <tr>
                                <th>Mã</th>
                                <th>Ngày đặt</th>
                                <th>Trạng thái</th>
                                <th>Tổng tiền</th>
                                <th>Thanh toán</th>
                            </tr>
                        </thead>
                        <tbody>
                            <?php $__empty_1 = true; $__currentLoopData = $donHangs; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $don): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>
                            <tr>
                                <td>#<?php echo e($don->id); ?></td>
                                <td><?php echo e($don->created_at->format('d/m/Y')); ?></td>
                                <td>
                                    <?php if($don->trangthai == 'đã giao'): ?>
                                    <span class="badge bg-primary">Đã giao</span>
                                    <?php elseif($don->trangthai == 'đã hủy'): ?>
                                    <span class="badge bg-danger">Đã hủy</span>
                                    <?php else: ?>
                                    <span class="badge bg-secondary"><?php echo e(ucfirst($don->trangthai)); ?></span>
                                    <?php endif; ?>
                                </td>
                                <td><?php echo e(number_format($don->tongtien, 0, ',', '.')); ?>đ</td>
                                <td>
                                    <?php if($don->trangthaithanhtoan): ?>
                                    <span class="badge bg-success">Đã thanh toán</span>
                                    <?php else: ?>
                                    <span class="badge bg-warning text-dark">Chưa thanh toán</span>
                                    <?php endif; ?>
                                </td>
                            </tr>
                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>
                            <tr>
                                <td colspan="5" class="text-center">Không có đơn hàng nào.</td>
                            </tr>
                            <?php endif; ?>
                        </tbody>
                    </table>
                </div>

                <!-- Thống kê -->
                <div class="tab-pane fade" id="stats" role="tabpanel">
                    <h5>Thống kê mua hàng</h5>
                    <ul class="list-group">
                        <li class="list-group-item">Tổng số đơn hàng: <strong><?php echo e($tongDon); ?></strong></li>
                        <li class="list-group-item">Đã thanh toán: <strong><?php echo e($donThanhToan); ?></strong></li>
                        <li class="list-group-item">Đơn bị hủy: <strong><?php echo e($donHuy); ?></strong></li>
                        <li class="list-group-item">Tổng tiền đã chi: <strong><?php echo e(number_format($tongTien, 0, ',', '.')); ?>đ</strong></li>
                    </ul>
                </div>

                <!-- Sản phẩm mua nhiều -->
                <div class="tab-pane fade" id="top-products" role="tabpanel">
                    <h5>Sản phẩm mua nhiều nhất</h5>
                    <table class="table">
                        <thead>
                            <tr>
                                <th>Tên sản phẩm</th>
                                <th>Số lần mua</th>
                                <th>Tổng tiền</th>
                            </tr>
                        </thead>
                        <tbody>
                            <?php $__empty_1 = true; $__currentLoopData = $topSanPham; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $sp): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>
                            <tr>
                                <td><?php echo e($sp->sanpham->tensp); ?></td>
                                <td><?php echo e($sp->tong_so_luong); ?></td>
                                <td><?php echo e(number_format($sp->tong_tien, 0, ',', '.')); ?>đ</td>
                            </tr>
                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>
                            <tr>
                                <td colspan="3" class="text-center">Chưa có sản phẩm nào.</td>
                            </tr>
                            <?php endif; ?>
                        </tbody>
                    </table>
                </div>

                <!-- Đánh giá -->
                <div class="tab-pane fade" id="reviews" role="tabpanel">
                    <h5>Đánh giá của khách hàng</h5>
                    <ul class="list-group">
                        <?php $__empty_1 = true; $__currentLoopData = $danhGias; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $dg): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>
                        <li class="list-group-item">
                            <strong><?php echo e($dg->sanpham->tensp); ?></strong> - ⭐<?php echo e(str_repeat('⭐', $dg->danhgia)); ?><br>
                            <?php echo e($dg->noidung); ?>

                            <div class="text-muted">Đánh giá ngày <?php echo e($dg->created_at->format('d/m/Y')); ?></div>
                        </li>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>
                        <li class="list-group-item text-center">Chưa có đánh giá nào.</li>
                        <?php endif; ?>
                    </ul>
                </div>

                <!-- Hành động -->
                <div class="tab-pane fade" id="actions" role="tabpanel">
                    <h5>Hành động quản trị</h5>

                    <form action="<?php echo e(route('khachhang.lock', $khachhang->id)); ?>" method="POST" class="d-inline">
                        <?php echo csrf_field(); ?>
                        <?php if($khachhang->trangthai == 1): ?>
                        <button class="btn btn-warning me-2" type="submit">Khóa tài khoản</button>
                        <?php else: ?>
                        <button class="btn btn-success me-2" type="submit">Mở khóa tài khoản</button>
                        <?php endif; ?>
                    </form>


                    <hr>
                    <form action="" method="POST">
                        <?php echo csrf_field(); ?>
                        <div class="mb-3">
                            <label for="note" class="form-label">Ghi chú nội bộ</label>
                            <textarea class="form-control" id="note" name="ghichu" rows="3" placeholder="VD: Khách hay hoàn đơn, cần kiểm tra kỹ..."><?php echo e($khachhang->ghichu); ?></textarea>
                        </div>
                        <button type="submit" class="btn btn-primary">Lưu ghi chú</button>
                    </form>

                </div>

            </div>
        </div>
    </div>
</div>

<?php $__env->stopSection(); ?>
<?php echo $__env->make('admin.layout.layout', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\Users\admin\OneDrive - Đại học FPT- FPT University\Desktop\Duantotnghiep\TechViewShop\resources\views/admin/users/chitiettaikhoan_khach.blade.php ENDPATH**/ ?>