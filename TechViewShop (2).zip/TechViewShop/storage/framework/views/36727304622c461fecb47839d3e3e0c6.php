
<?php $__env->startSection('title'); ?>
    Quên mật khẩu
<?php $__env->stopSection(); ?>
<?php $__env->startSection('body'); ?>
    <div class="forgetPass">
        <div class="grid container">
            <div class="row">
                <div class="col l-12 m-12 c-12">
                    <p class="forgetPass-title">Bạn quên mật khẩu? Nhập địa chỉ email để lấy lại mật khẩu qua email.</p>
                    <form class="login-form" method="post">
                        <?php echo csrf_field(); ?>
                        <div class="form-group">
                            <label for="email">Email<span class="required"></span>:</label>
                            <input class="input-field" type="text" name="email" id="email">
                            <?php if($errors->has('email')): ?>
                                <span class="message"><?php echo e($errors->first('email')); ?></span>
                            <?php endif; ?>
                        </div>

                        <?php if(session('message')): ?>
                            <div class="message">
                                <?php echo e(session('message')); ?>

                            </div>
                        <?php endif; ?>

                        <button type="submit" class="btn-reset">Đặt lại mật khẩu</button>
                    </form>
                </div>
            </div>
        </div>
       
    </div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('client.layout.layout', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\Users\admin\OneDrive - Đại học FPT- FPT University\Desktop\Duantotnghiep\TechViewShop\resources\views/client/pages/forget.blade.php ENDPATH**/ ?>