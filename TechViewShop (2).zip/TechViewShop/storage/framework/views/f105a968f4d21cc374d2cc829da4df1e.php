

<?php $__env->startSection('title', 'Khuyen mai'); ?>

<?php $__env->startSection('content'); ?>

<!-- Nội dung chính của trang sẽ nằm ở đây -->
<div class="container">
    <div class="category-list mt-4 d-flex justify-content-between align-items-center">
        <h4 class="fw-bold">DANH SÁCH KHUYẾN MÃI</h4>
        <a href="<?php echo e(route('khuyenmai.create')); ?>"><button class="btn btn-primary"><i class="bi bi-plus-lg"></i> Thêm khuyến mãi</button></a>
    </div>
    <div class="table-responsive border-1">
        <table class="table table-hover align-middle">
            <thead class="table-primary">
                <tr>
                    <th>ID</th>
                    <th>Mã </th>
                    <th>Mô tả</th>
                    <th>Bắt đầu</th>
                    <th>Kết thúc</th>
                    <th>Hệ số giảm</th>
                    <th>Giá trị ĐH tối thiểu</th>
                    <th>Giảm tối đa</th>
                    <th>Giới hạn</th>
                    <th>Đã dùng</th>
                    <th>Hoạt động</th>
                    <th>Thao tác</th>
                </tr>
            </thead>
            <tbody>

                <?php $__currentLoopData = $khuyenmai; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $khuyenmai): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>

                <tr>
                    <td><?php echo e($khuyenmai->id); ?></td>
                    <td><?php echo e($khuyenmai->makm); ?></td>
                    <td><?php echo e($khuyenmai->mota); ?></td>
                    <td><?php echo e($khuyenmai->ngaybatdau); ?></td>
                    <td><?php echo e($khuyenmai->ngayketthuc); ?></td>
                    <td><?php echo e($khuyenmai->hesogiamgia); ?></td>
                    <td><?php echo e($khuyenmai->sotientoithieu); ?></td>
                    <td><?php echo e($khuyenmai->sotiengiamtoida); ?></td>
                    <td><?php echo e($khuyenmai->gioihan); ?></td>
                    <td><?php echo e($khuyenmai->dasudung); ?></td>
                    <td>
                    <span class="badge <?php echo e($khuyenmai->hoatdong == 1 ? 'bg-success bg-opacity-10 text-success' : 'bg-danger bg-opacity-10 text-danger'); ?> p-2">
                            <?php echo e($khuyenmai->hoatdong == 1? 'Hoạt động ' : 'Ngưng hoạt động'); ?>

                        </span>
                    </td>


                    <!-- <td><a href="<?php echo e(route('khuyenmai.edit', $khuyenmai->id)); ?>"><span class="badge bg-success bg-opacity-10 text-success p-2"><i class="bi bi-pencil"></i> Sửa</span></a>  <a href="<?php echo e(route('khuyenmai.destroy', $khuyenmai->id)); ?>"><span class="badge bg-danger bg-opacity-10 text-danger p-2"><i class="bi bi-trash3"></i> Xoá</span></a></td> -->
                    <td>
                        <?php if($khuyenmai->dasudung < 1): ?>
                            <a href="<?php echo e(route('khuyenmai.edit', $khuyenmai->id)); ?>">
                            <span class="badge bg-success bg-opacity-10 text-success p-2">
                                <i class="bi bi-pencil"></i> Sửa
                            </span>
                            </a>
                            <a href="<?php echo e(route('khuyenmai.destroy', $khuyenmai->id)); ?>">
                                <span class="badge bg-danger bg-opacity-10 text-danger p-2">
                                    <i class="bi bi-trash3"></i> Xoá
                                </span>
                            </a>
                            <?php else: ?>
                            <span class="badge bg-primary bg-opacity-10 text-primary p-2">Không khả dụng</span>
                            <?php endif; ?>
                    </td>

                </tr>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>


            </tbody>
        </table>
    </div>
</div>
<nav aria-label="Page navigation example">
    <ul class="pagination justify-content-end">
        <li class="page-item disabled">
            <a class="page-link">Previous</a>
        </li>
        <li class="page-item"><a class="page-link" href="#">1</a></li>
        <li class="page-item"><a class="page-link" href="#">2</a></li>
        <li class="page-item"><a class="page-link" href="#">3</a></li>
        <li class="page-item">
            <a class="page-link" href="#">Next</a>
        </li>
    </ul>
</nav>
</div>

</div>

<?php $__env->stopSection(); ?>
<?php echo $__env->make('admin.layout.layout', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\Users\admin\OneDrive - Đại học FPT- FPT University\Desktop\Duantotnghiep\TechViewShop\resources\views/admin/khuyenmai/khuyenmai.blade.php ENDPATH**/ ?>