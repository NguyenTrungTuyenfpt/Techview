<?php

use Illuminate\Http\Request;
use Illuminate\Support\Facades\Route;
use App\Mail\VerifyEmailMail;
use App\Http\Controllers\Api_admin\BinhLuanController;

use App\Http\Controllers\API\AuthAPIController;
use App\Http\Controllers\API\ContactAPIController;
use App\Http\Controllers\API\FavoriteAPIController;
use App\Http\Controllers\API\GoogleAPIController;




Route::post('/register', [AuthAPIController::class, 'register']);
Route::post('/verify-email/{token}', [AuthAPIController::class, 'verifyEmail']);
Route::post('/login', [AuthAPIController::class, 'login']);


Route::middleware('auth:sanctum')->group(function () {
    Route::get('/binhluan/{id_baiviet}', [BinhLuanController::class, 'index']); // Lấy bình luận gốc
    Route::get('/binhluan/replies/{id_binhluan}', [BinhLuanController::class, 'getReplies']); // Lấy phản hồi
    Route::post('/binhluan', [BinhLuanController::class, 'store']); // Thêm bình luận/phản hồi
    Route::put('/binhluan/{id}', [BinhLuanController::class, 'update']); // Sửa bình luận
    Route::delete('/binhluan/{id}', [BinhLuanController::class, 'destroy']); // Xóa bình luận
});

Route::middleware('auth:sanctum')->group(function () {
    Route::post('/logout', [AuthAPIController::class, 'logout']);
    Route::put('/change-password', [AuthAPIController::class, 'changePassword']);
    Route::get('/get-user-info', [AuthAPIController::class, 'getUserInfo']);
    
    Route::post('/favorite/add', [FavoriteAPIController::class, 'add']);
    Route::delete('/favorite/remove', [FavoriteAPIController::class, 'remove']);
    Route::get('/favorite/list', [FavoriteAPIController::class, 'list']);
});

Route::get('/auth/google', [GoogleAPIController::class, 'redirectToGoogle']);
Route::post('/auth/google/callback', [GoogleAPIController::class, 'handleGoogleLogin']);

Route::post('/forgot-password', [AuthAPIController::class, 'forgotPassword']);
Route::post('/reset-password', [AuthAPIController::class, 'resetPassword']);

Route::post('/contact', [ContactAPIController::class, 'SendContactEmail']);

