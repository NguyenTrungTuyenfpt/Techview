<?php

use Illuminate\Support\Facades\Route;
use App\Http\Controllers\admin\IndexController;
use App\Http\Controllers\admin\AuthThenController;
use App\Http\Controllers\admin\UserController;
use App\Http\Controllers\admin\DanhMucController;
use App\Http\Controllers\admin\DanhMucBaiVietController;
use App\Http\Controllers\admin\SanPhamController;
use App\Http\Controllers\admin\BaiVietController;
use App\Http\Controllers\admin\BinhLuanBaiVietController;
use App\Http\Controllers\admin\DanhGiaController;
use App\Http\Controllers\admin\DonHangController;
use App\Http\Controllers\admin\KhuyenMaiController;
use App\Http\Controllers\admin\NhaCungCapController;
use App\Http\Controllers\admin\BannerController;
use App\Http\Controllers\admin\DoanhThuController;
use App\Http\Controllers\admin\ThongKeController;
use App\Http\Controllers\admin\UploadController;

// +++++++++++++++++++++++++++++++++++++++++++++++++//
use App\Http\Controllers\clients\CheckoutController;
use App\Http\Controllers\clients\AuthController;
use App\Http\Controllers\clients\CartController;
use App\Http\Controllers\clients\CategoryController;
use App\Http\Controllers\clients\CouponController;
use App\Http\Controllers\clients\GoogleController;
use App\Http\Controllers\clients\HomeController;
use App\Http\Controllers\clients\PaymentController;
use App\Http\Controllers\clients\ProductController;
use App\Http\Controllers\clients\FavoriteController;



// Authentication Routes
Route::prefix('auth')->group(function () {
    Route::get('/register', [AuthThenController::class, 'register'])->name('auth.register');
    Route::post('/register', [AuthThenController::class, 'postRegister'])->name('auth.pregister');
    Route::get('/verify-email/{id}', [AuthThenController::class, 'verifyEmail'])->name('auth.verifyemail');
    Route::get('/login', [AuthThenController::class, 'login'])->name('auth.login');
    Route::post('/login', [AuthThenController::class, 'postLogin'])->name('auth.plogin');
    Route::post('/logout', [AuthThenController::class, 'logout'])->name('auth.logout');
});

//Phan quyen
Route::prefix('admin')->group(function () {
    Route::get('/thongke', [ThongKeController::class, 'index'])
        ->name('thongke.index')
        ->middleware(['auth:sanctum', 'check.permission:1']);
});

// Routes yêu cầu đăng nhập
Route::middleware(['auth:sanctum'])->group(function () {
    // Trang chủ
    Route::get('/admin', [IndexController::class, 'index'])->name('admin.index');

    // Quản lý đơn hàng
    Route::get('/admin/donhang', [DonHangController::class, 'index'])->name('donhang');
    Route::get('/admin/donhang/{id}', [DonHangController::class, 'show'])->name('donhang.show');
    Route::put('/admin/donhang/{id}', [DonHangController::class, 'updateTrangThai'])->name('donhang.update');
    Route::delete('/admin/donhang/{id}', [DonHangController::class, 'huyDon'])->name('donhang.huy');
    Route::get('/admin/xacnhan/{id}', [DonHangController::class, 'daNhanHang'])->name('donhang.xacnhan');
    
    // Quản lý sản phẩm
    Route::get('/admin/sanpham', [SanPhamController::class, 'index'])->name('sanpham');
    
    // Quản lý đánh giá
    Route::get('/admin/danhgia/quanlydanhgia', [DanhGiaController::class, 'manageReviews'])->name('admin.danhgia.manage');
    Route::post('/admin/danhgia/anhien/{id}', [DanhGiaController::class, 'anhien'])->name('danhgia.anhien');
});

Route::post('/admin/danhgia/phanhoi/{id}', [DanhGiaController::class, 'phanhoi'])->name('danhgia.phanhoi')->withoutMiddleware('check.permission');
// User Routes
Route::prefix('admin')->group(function () {
    // Khách hàng
    Route::get('/khachhang', [UserController::class, 'khachhang'])->name('khachhang');
    Route::get('/khachhang/{id}', [UserController::class, 'kh_show'])->name('khachhang.show');
    Route::post('/khachhang/{id}', [UserController::class, 'kh_lock'])->name('khachhang.lock');
    Route::get('/khachhang_sua/{id}', [UserController::class, 'edit'])->name('khachhang.edit');
    Route::delete('/khachhang_xoa/{id}', [UserController::class, 'destroy'])->name('khachhang.destroy');

    // Nhân viên
    Route::get('/nhanvien', [UserController::class, 'nhanvien'])->name('nhanvien')->middleware(['auth:sanctum', 'check.permission:1']);
    Route::get('/nhanvien/{id}', [UserController::class, 'nv_show'])->name('nhanvien.show');
    Route::put('/nhanvien/{id}/lock', [UserController::class, 'nv_lock'])->name('nhanvien.lock');
    Route::put('/nhanvien/{id}/phanquyen', [UserController::class, 'updatePhanquyen'])->name('nhanvien.phanquyen');

    // Hồ sơ người dùng
    Route::get('/profile', [UserController::class, 'showProfile'])->name('user.profile');
    Route::post('/profile', [UserController::class, 'updateProfile'])->name('user.updateProfile');
});



Route::prefix('admin')->group(function () {

    // Danh mục sản phẩm
    Route::get('/danhmuc', [DanhMucController::class, 'index'])->name('danhmuc');
    Route::get('/danhmuc/chitietdm/{id}', [DanhMucController::class, 'show'])->name('danhmuc.show');
    Route::get('/danhmuc/themdanhmuc', [DanhMucController::class, 'create'])->name('danhmuc.create');
    Route::post('/danhmuc/luudm', [DanhMucController::class, 'store'])->name('danhmuc.store');
    Route::get('/danhmuc/suadm/{id}', [DanhMucController::class, 'edit'])->name('danhmuc.edit');
    Route::put('/danhmuc/capnhat/{id}', [DanhMucController::class, 'update'])->name('danhmuc.update');
    Route::delete('/danhmuc/xoadm/{id}', [DanhMucController::class, 'destroy'])->name('danhmuc.destroy');
    // Danh mục bài viết
    Route::get('/danhmucbaiviet', [DanhMucBaiVietController::class, 'index'])->name('danhmucbaiviet.index');
    Route::get('/danhmucbaiviet/tao', [DanhMucBaiVietController::class, 'create'])->name('danhmucbaiviet.create');
    Route::post('/danhmucbaiviet/them', [DanhMucBaiVietController::class, 'store'])->name('danhmucbaiviet.store');
    Route::get('/danhmucbaiviet/chitiet/{id}', [DanhMucBaiVietController::class, 'show'])->name('danhmucbaiviet.show');
    Route::get('/danhmucbaiviet/sua/{id}', [DanhMucBaiVietController::class, 'edit'])->name('danhmucbaiviet.edit');
    Route::put('/danhmucbaiviet/capnhat/{id}', [DanhMucBaiVietController::class, 'update'])->name('danhmucbaiviet.update');
    Route::delete('/danhmucbaiviet/xoa/{id}', [DanhMucBaiVietController::class, 'destroy'])->name('danhmucbaiviet.destroy');


    
    // Upload hình ảnh
    Route::post('/upload-image', [UploadController::class, 'uploadImage'])->name('upload.image');
    
    // Sản phẩm
    
    Route::get('/sanpham/chiTietSanPham/{id}', [SanPhamController::class, 'show'])->name('sanpham.show');
    Route::get('/sanpham/themsanpham', [SanPhamController::class, 'create'])->name('sanpham.create');
    Route::post('/sanpham/luusp', [SanPhamController::class, 'store'])->name('sanpham.store');
    Route::get('/sanpham/suasp/{id}', [SanPhamController::class, 'edit'])->name('sanpham.edit');
    Route::put('/sanpham/capnhatsp/{id}', [SanPhamController::class, 'update'])->name('sanpham.update');
    Route::delete('/sanpham/sanphamxoasp/{id}', [SanPhamController::class, 'destroy'])->name('sanpham.destroy');

    // Bài viết
    Route::get('/baiviet', [BaiVietController::class, 'index'])->name('baiviet');
    Route::middleware(['auth'])->group(function () {
        Route::get('/baiviet/create', [BaiVietController::class, 'create'])->name('baiviet.create');
        Route::post('/baiviet', [BaiVietController::class, 'store'])->name('baiviet.store');
        Route::get('/baiviet/{id}/edit', [BaiVietController::class, 'edit'])->name('baiviet.edit');
        Route::put('/baiviet/{id}', [BaiVietController::class, 'update'])->name('baiviet.update');
        Route::delete('/baiviet/{id}', [BaiVietController::class, 'destroy'])->name('baiviet.destroy');
    });

    // Bình luận bài viết
    
    Route::get('/binhluan', [BinhLuanBaiVietController::class, 'binhluan'])->name('binhluan');
    Route::put('/binhluan/anhien/{id}', [BinhLuanBaiVietController::class, 'anhien'])->name('binhluan.anhien');
    
    // Đánh giá
    Route::get('/danhgia', [DanhGiaController::class, 'index'])->name('danhgia');
    // Route::post('/danhgia/phanhoi/{id}', [DanhGiaController::class, 'phanhoi'])->name('danhgia.phanhoi');
    
    Route::post('/danhgia/{id_sanpham}/danh-gia', [DanhGiaController::class, 'addDanhGia'])->name('danhgia.add')->middleware('auth');
    
    // Đơn hàng
    Route::get('/donhang', [DonHangController::class, 'index'])->name('donhang');
    
    // Khuyến mãi
    Route::get('/khuyenmai', [KhuyenMaiController::class, 'index'])->name('khuyenmai');
    Route::get('/khuyenmai/them', [KhuyenMaiController::class, 'create'])->name('khuyenmai.create');
    Route::post('/khuyenmai/luu', [KhuyenMaiController::class, 'store'])->name('khuyenmai.store');
    Route::get('/khuyenmai/sua/{id}', [KhuyenMaiController::class, 'edit'])->name('khuyenmai.edit');
    Route::put('/khuyenmai/capnhat/{id}', [KhuyenMaiController::class, 'update'])->name('khuyenmai.update');
    Route::delete('/khuyenmai/xoa/{id}', [KhuyenMaiController::class, 'destroy'])->name('khuyenmai.destroy');
    
    // Nhà cung cấp
    Route::get('/nhacungcap', [NhaCungCapController::class, 'index'])->name('nhacungcap');
    Route::get('/nhacungcap/them', [NhaCungCapController::class, 'create'])->name('nhacungcap.create');
    Route::post('/nhacungcap/luu', [NhaCungCapController::class, 'store'])->name('nhacungcap.store');
    Route::get('/nhacungcap/sua/{id}', [NhaCungCapController::class, 'edit'])->name('nhacungcap.edit');
    Route::put('/nhacungcap/capnhat/{id}', [NhaCungCapController::class, 'update'])->name('nhacungcap.update');
    
    // Banner
    Route::get('/banner', [BannerController::class, 'index'])->name('banner');
    Route::get('/banner/them', [BannerController::class, 'create'])->name('banner.create');
    Route::post('/banner/luu', [BannerController::class, 'store'])->name('banner.store');
    Route::get('/banner/sua/{id}', [BannerController::class, 'edit'])->name('banner.edit');
    Route::put('/banner/capnhat/{id}', [BannerController::class, 'update'])->name('banner.update');
    Route::delete('/banner/xoa/{id}', [BannerController::class, 'destroy'])->name('banner.destroy');
    
    // Thống kê
    Route::get('/thongke', [ThongKeController::class, 'index'])->name('thongke.index');
    // // Doanh thu
    // Route::get('/doanhthu', [DoanhThuController::class, 'index'])->name('doanhthu');
});



// +++++++++++++++++++++++++++++++++++++++++++++//
// +++++++++++++++++++++++++++++++++++++++++++++//
Route::get('/', [HomeController::class, 'index'])->name('index');
Route::get('/search', [ProductController::class, 'search'])->name('search');
Route::get('/email', [HomeController::class, 'email']);


Route::prefix('favorite')->group(function () {
    Route::get('/', [FavoriteController::class, 'index'])->name('favorite');
    Route::post('/add', [FavoriteController::class, 'add'])->name('favorite.add');
    Route::post('/delete/{id}', [FavoriteController::class, 'delete'])->name('favorite.delete');
});


Route::group(['prefix' => 'checkout', 'middleware' => 'auth'], function () { 
    Route::get('/', [CheckoutController::class, 'index'])->name('checkout'); 
    Route::post('/create', [CheckoutController::class, 'create'])->name('checkout.create'); 
    Route::post('/apply-coupon', [CouponController::class, 'apply'])->name('checkout.apply-coupon');
    Route::post('/paymen-create', [PaymentController::class, 'createPay'])->name('checkout.payment.create'); 
    Route::get('/result', [PaymentController::class, 'result'])->name('checkout.result'); 
    Route::get('/success', [CheckoutController::class, 'success'])->name('checkout.success'); 
});


Route::prefix('cart')->group(function () {
    Route::get('/', [CartController::class, 'index'])->name('cart');
    Route::post('/add', [CartController::class, 'add'])->name('cart.add');
    Route::post('/delete/{id}', [CartController::class, 'delete'])->name('cart.delete');
    Route::patch('/update/{id}', [CartController::class, 'update'])->name('cart.update');
});

Route::prefix('category')->group(function () {
    Route::get('/{slug}', [CategoryController::class, 'index']);
    Route::get('/{parent}/{slug}', [CategoryController::class, 'index']);
});

Route::prefix('product')->group(function () {
    Route::get('/', [ProductController::class, 'index'])->name('product');
    Route::get('/{slug}', [ProductController::class, 'index'])->name('product.byType');
    Route::get('/detail/{slug}', [ProductController::class, 'detail'])->name('product.detail');
    Route::get('/search', [ProductController::class, 'search'])->name('product.search');
    Route::post('/detail/danhgia/{id}', [DanhGiaController::class, 'addDanhGia'])->name('danhgia.sp');
});

Route::group(['prefix' => 'account', 'middleware' => 'auth'], function () {
    Route::get('/profile', [AuthController::class, 'profile'])->name('account.profile');
    Route::post('/profile/change-password', [AuthController::class, 'changePassword'])->name('account.changepassword');
    Route::post('/profile/change-avatar', [AuthController::class, 'changeAvatar'])->name('account.changeavatar');
    Route::post('/profile/update-profile', [AuthController::class, 'updateProfile'])->name('account.updateprofile');
    Route::get('/logout', [AuthController::class, 'logout'])->name('account.logout');
});

Route::group(['prefix' => 'account'], function () {
    Route::get('/register', [AuthController::class, 'register'])->name('account.register');
    Route::post('/register', [AuthController::class, 'postRegister']);
    Route::get('/verify-email/{id}', [AuthController::class, 'verifyEmail'])->name('account.verifyemail');
    Route::get('/login', [AuthController::class, 'login'])->name('account.login');
    Route::post('/login', [AuthController::class, 'postLogin']);
    Route::get('/forget-password', [AuthController::class, 'forget_password'])->name('account.forget_password');
    Route::post('/forget-password', [AuthController::class, 'check_forget_password']);
    Route::get('/reset-password/{token}', [AuthController::class, 'reset_password'])->name('account.reset_password');
    Route::post('/reset-password', [AuthController::class, 'check_reset_password'])->name('account.update_password');
});




Route::get('auth/google', [GoogleController::class, 'redirectToGoogle'])->name('auth.google');
Route::get('auth/google/callback', [GoogleController::class, 'handleGoogleCallback']);
