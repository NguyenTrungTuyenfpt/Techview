<?php

use Illuminate\Database\Migrations\Migration;
use Illuminate\Database\Schema\Blueprint;
use Illuminate\Support\Facades\Schema;

return new class extends Migration
{
    public function up(): void
    {
        Schema::create('users', function (Blueprint $table) {
            $table->id();
            $table->string('hoten');
            $table->string('sodienthoai')->nullable()->unique();
            $table->string('email')->unique();
            $table->string('matkhau');
            $table->timestamp('email_verified_at')->nullable();
            $table->string('remember_token')->nullable();
            $table->string('diachi')->nullable();
            $table->enum('gioitinh', ['nam', 'nữ', 'khác'])->nullable();
            $table->date('ngaysinh')->nullable();
            $table->string('hinh')->nullable();
            $table->boolean('trangthai')->default(1);
            $table->boolean('vaitro')->default(0);
            $table->integer('phanquyen')->nullable();
            $table->string('google_id')->nullable();
            $table->timestamps(); 
        });
    }
    public function down(): void
    {
        Schema::dropIfExists('users');
    }
};
