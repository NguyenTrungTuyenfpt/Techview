<?php

use Illuminate\Database\Migrations\Migration;
use Illuminate\Database\Schema\Blueprint;
use Illuminate\Support\Facades\Schema;

return new class extends Migration
{
    /**
     * Run the migrations.
     */
    public function up(): void
    {
        Schema::create('danhgiasanpham', function (Blueprint $table) {
            $table->id();
            $table->integer('danhgia')->nullable(); 
            $table->text('noidung')->nullable();
            $table->boolean('anhien')->default(1);
            $table->unsignedBigInteger('id_sanpham');
            $table->unsignedBigInteger('id_user'); 
            $table->unsignedBigInteger('id_danhgia')->nullable()->unique(); // Giữ unique() để đảm bảo 1-1 cho phản hồi
            $table->unsignedBigInteger('id_donhang'); 
            $table->timestamps();
            

            // Ràng buộc khóa ngoại
            $table->foreign('id_user')->references('id')->on('users')->onDelete('cascade');
            $table->foreign('id_sanpham')->references('id')->on('sanpham')->onDelete('cascade');
            $table->foreign('id_danhgia')->references('id')->on('danhgiasanpham')->onDelete('set null');
            $table->foreign('id_donhang')->references('id')->on('donhang')->onDelete('cascade'); // Thêm ràng buộc cho id_donhang

            // Ràng buộc UNIQUE trên cặp (id_user, id_donhang, id_sanpham)
            $table->unique(['id_user', 'id_donhang', 'id_sanpham'], 'unique_user_donhang_sanpham');
        });
    }
    public function down(): void
    {
        Schema::dropIfExists('danhgiasanpham');
    }
};
