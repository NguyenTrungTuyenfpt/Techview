<?php

use Illuminate\Database\Migrations\Migration;
use Illuminate\Database\Schema\Blueprint;
use Illuminate\Support\Facades\Schema;

return new class extends Migration
{
    /**
     * Run the migrations.
     */
    public function up(): void
    {
        Schema::create('chitietdonhang', function (Blueprint $table) {
            $table->unsignedBigInteger('id_donhang');
            $table->unsignedBigInteger('id_sanpham');
            $table->integer('gia');
            $table->integer('soluong');
            
            $table->primary(['id_donhang', 'id_sanpham']);
            $table->foreign('id_donhang')->references('id')->on('donhang')->onDelete('cascade');
            $table->foreign('id_sanpham')->references('id')->on('sanpham')->onDelete('cascade');
        });
    }
    public function down(): void
    {
        Schema::dropIfExists('chitietdonhang');
    }
};
