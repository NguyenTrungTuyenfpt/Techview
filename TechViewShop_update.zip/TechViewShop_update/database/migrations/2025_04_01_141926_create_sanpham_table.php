<?php

use Illuminate\Database\Migrations\Migration;
use Illuminate\Database\Schema\Blueprint;
use Illuminate\Support\Facades\Schema;

return new class extends Migration
{
    /**
     * Run the migrations.
     */
    public function up(): void
    {
        Schema::create('sanpham', function (Blueprint $table) {
            $table->id(); 
            $table->string('tensp');
            $table->string('slug')->unique();
            $table->string('thuonghieu')->nullable(); 
            $table->text('mota')->nullable();
            $table->string('hinh')->nullable();
            $table->integer('gia'); 
            $table->integer('giamgia')->default(0); 
            $table->integer('soluong')->default(1); 
            $table->integer('tonkho')->default(1); 
            $table->integer('luotxem')->default(1);
            $table->boolean('anhien')->default(1);
            $table->boolean('noibat')->default(0); 
            $table->unsignedBigInteger('id_danhmuc'); 
            $table->unsignedBigInteger('id_nhacungcap')->nullable(); 
            $table->unsignedBigInteger('id_user'); 
            $table->timestamps();

            $table->foreign('id_user')->references('id')->on('users')->onDelete('cascade');
            $table->foreign('id_danhmuc')->references('id')->on('danhmuc')->onDelete('cascade');
            $table->foreign('id_nhacungcap')->references('id')->on('nhacungcap')->onDelete('set null');
        });
    }
    public function down(): void
    {
        Schema::dropIfExists('sanpham');
    }
};
