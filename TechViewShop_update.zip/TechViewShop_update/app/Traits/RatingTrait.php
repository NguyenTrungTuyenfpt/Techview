<?php

namespace App\Traits;

use App\Models\Rating;
use Illuminate\Support\Facades\DB;

trait RatingTrait
{
    public function getProductRatings()
    {
        return DB::select("
 SELECT id_sanpham,
       ROUND(COALESCE(AVG(danhgia), 0)) AS tb_sao,
       COUNT(id) AS dem
FROM danhgiasanpham
WHERE id_danhgia IS NULL
GROUP BY id_sanpham

");
    }
}
