<?php

namespace App\Http\Controllers\Admin;

use App\Http\Controllers\Controller;
use Illuminate\Http\Request;
use App\Models\Models_2\NhaCungCap;

class NhaCungCapController extends Controller
{
    public function index()
    {
        $nhacungcap = NhaCungCap::orderBy('id')->get();
        return view('admin.nhacungcap.nhacungcap', compact('nhacungcap'));
    }

    public function create()
    {
        return view('admin.nhacungcap.nhacungcap_add');
    }

    public function store(Request $request)
    {
        $request->validate([
            'tenncc' => 'required|string|max:255',
            'email' => 'nullable|email|unique:nhacungcap',
            'mota' => 'nullable|string',
            'sodienthoai' => 'nullable|string',
            'diachi' => 'nullable|string',
            'hinh' => 'nullable|image|mimes:jpeg,png,jpg,webp|max:2048',
            'thutu' => 'nullable|integer',
            'anhien' => 'required|boolean',
        ]);


        // Xử lý ảnh 
        $hinhanh = null;
        if ($request->hasFile('hinh')) {
            $file = $request->file('hinh');
            $filename = $file->getClientOriginalName();
            $file->move(public_path('uploads/nhacungcap'), $filename);
            $hinhanh = $filename;
        }
       $id_user_tao = auth()->id();

        // dd($request->all());

        NhaCungCap::create([
            'tenncc' => $request->tenncc,
            'mota' => $request->mota,
            'hinh' => $hinhanh,
            'thutu' => $request->thutu,
            'anhien' => $request->anhien,
            'email' => $request->email,
            'sodienthoai' => $request->sodienthoai,
            'diachi' => $request->diachi,
        ]);


        return redirect()->back()
        ->with('popup', true)
        ->with('message', 'Thêm nhà cung cấp mới thành công!')
        ->with('route', route('nhacungcap')); // Truyền route vào session
    }

    public function edit($id)
    {
        $nhacungcap = NhaCungCap::find($id);
        return view('admin.nhacungcap.nhacungcap_edit', compact('nhacungcap'));
    }

    public function update(Request $request, $id)
    {
        $request->validate([
            'tenncc' => 'required|string|max:255',
            'email' => 'nullable|email|unique:nhacungcap,email,' . $id,
            'mota' => 'nullable|string',
            'sodienthoai' => 'nullable|string',
            'diachi' => 'nullable|string',
            'hinh' => 'nullable|image|mimes:jpeg,png,jpg,webp|max:2048',
            'thutu' => 'nullable|integer',
            'anhien' => 'required|boolean',
        ]);

        $nhacungcap = NhaCungCap::findOrFail($id);

        if ($request->hasFile('hinh')) {
            // Remove old image if exists
            if ($nhacungcap->hinh) {
                unlink(public_path('uploads/nhacungcap/' . $nhacungcap->hinh)); // Xóa ảnh cũ
            }

            // Validate và xử lý ảnh
            $file = $request->file('hinh');
            $filename = $file->getClientOriginalName();
            $file->move(public_path('uploads/nhacungcap'), $filename);
            $nhacungcap->hinh = $filename; // Update with new image
        }
        $id_user_capnhat = auth()->id();

        $nhacungcap->update([
            'tenncc' => $request->tenncc,
            'mota' => $request->mota,
            'hinh' => $nhacungcap->hinh,
            'thutu' => $request->thutu,
            'anhien' => $request->anhien,
            'email' => $request->email,
            'sodienthoai' => $request->sodienthoai,
            'diachi' => $request->diachi,
        ]);
        return redirect()->back()
        ->with('popup', true)
        ->with('message', 'Cập nhật thành công!')
        ->with('route', route('nhacungcap')); // Truyền route vào session
    
    }
}
