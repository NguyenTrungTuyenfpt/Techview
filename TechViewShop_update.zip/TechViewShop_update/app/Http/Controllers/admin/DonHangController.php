<?php

namespace App\Http\Controllers\Admin;

use App\Http\Controllers\Controller;
use Illuminate\Http\Request;
use App\Models\Models_2\DonHang;
use App\Models\Models_2\User;
use Carbon\Carbon;
use App\Mail\MailDHHoanThanh;
use Illuminate\Support\Facades\Mail;


class DonHangController extends Controller
{
    public function index()
    {
        $donhangs = DonHang::orderBy('created_at', 'desc')->paginate(10);
        return view('admin.donhang.donhang', compact('donhangs'));
    }
    public function show($id)
    {
        $donhang = DonHang::with('chitietdonhang.sanpham')->findOrFail($id);

        return view('admin.donhang.chitietdonhang', compact('donhang'));
    }
    public function updateTrangThai(Request $request, $id)
    {
        $donhang = DonHang::findOrFail($id);
        $trangthai = $request->input('trangthai');
        $donhang->trangthai = $trangthai;
        $donhang->save();
        if ($trangthai == 'hoàn thành') {
            Mail::to($donhang->user->email)->send(new MailDHHoanThanh($donhang));
        }
        return redirect()->route('donhang')->with('message', 'Đơn hàng đã được cập nhật .');
    }


public function daNhanHang($id) {
   

    // Lấy đơn hàng từ id
    $donhang = DonHang::findOrFail($id);
    // Kiểm tra nếu đơn hàng đã có trạng thái "đã giao" rồi thì không cần thay đổi
    if ($donhang->trangthai == 'đã giao') {
        return redirect()->route('donhang')->with('message', 'Đơn hàng đã được giao!');
    }
     // Cập nhật trạng thái đơn hàng
     $donhang->trangthai = 'đã giao';
     $donhang->save();

    return redirect()->route('donhang')->with('message', 'cảm ơn bạn đã xác nhận!');


   
}
}

