<?php

namespace App\Http\Controllers\Admin;

use App\Http\Controllers\Controller;
use Illuminate\Http\Request;
use App\Models\Models_2\DonHang;
use App\Models\Models_2\User;
use App\Models\Models_2\DanhGiaSanPham;
use App\Models\Models_2\SanPham;
use App\Models\Models_2\BaiViet;
use App\Models\Models_2\KhuyenMai;
use Illuminate\Support\Facades\DB;
use Carbon\Carbon;

class ThongKeController extends Controller
{
    public function index(Request $request)
    {
        $filter = $request->query('filter', 'month'); 
      
        $dateRange = now();
        if ($filter == 'today') {
            $dateRange = now()->startOfDay();
        } elseif ($filter == 'week') {
            $dateRange = now()->startOfWeek();
        } elseif ($filter == 'month') {
            $dateRange = now()->startOfMonth();
        } elseif ($filter == 'year') {
            $dateRange = now()->startOfYear();
        }

       
        $doanhThu = DonHang::where('trangthai', 'hoàn thành')
            ->where('created_at', '>=', $dateRange)
            ->sum('tongtien');

       
        $soDonHang = DonHang::where('created_at', '>=', $dateRange)
            ->count();

       
        $soKhachHang = User::where('created_at', '>=', $dateRange)
            ->count();

            
        $soDanhGia = DanhGiaSanPham::where('created_at', '>=', $dateRange)
            ->where('anhien', 1)
            ->count();

        // Số bài viết mới
        $soBaiVietMoi = BaiViet::where('created_at', '>=', $dateRange)
            ->where('anhien', 1)
            ->count();

        // Số sản phẩm nổi bật
        $soSanPhamNoiBat = SanPham::where('noibat', 1)
            ->where('anhien', 1)
            ->count();

        // Số khuyến mãi đang hoạt động
        $soKhuyenMaiHoatDong = KhuyenMai::where('ngaybatdau', '<=', now())
            ->where('ngayketthuc', '>=', now())
            ->count();

        // Sản phẩm bán chạy
        $sanPhamBanChay = SanPham::select('sanpham.*')
            ->join('chitietdonhang', 'sanpham.id', '=', 'chitietdonhang.id_sanpham')
            ->join('donhang', 'chitietdonhang.id_donhang', '=', 'donhang.id')
            ->where('donhang.trangthai', 'hoàn thành')
            ->where('donhang.created_at', '>=', $dateRange)
            ->groupBy('sanpham.id', 'sanpham.tensp')
            ->selectRaw('SUM(chitietdonhang.soluong) as soLuongBan')
            ->selectRaw('SUM(chitietdonhang.soluong * chitietdonhang.gia) as doanhThu')
            ->orderBy('soLuongBan', 'desc')
            ->take(5)
            ->get();

        // Sản phẩm sắp hết
        $sanPhamSapHet = SanPham::where('soluong', '<', 10)
            ->where('soluong', '>', 0)
            ->where('anhien', 1)
            ->orderBy('soluong', 'asc')
            ->take(5)
            ->get(['id', 'tensp', 'soluong']);

        // Bài viết mới
        $baiVietMoi = BaiViet::with(['danhMucBaiViet', 'nguoiTao'])
            ->where('created_at', '>=', $dateRange)
            ->where('anhien', 1)
            ->orderBy('created_at', 'desc')
            ->take(5)
            ->get();

        // Đánh giá mới
        $danhGiaMoi = DanhGiaSanPham::with(['sanpham', 'user'])
            ->where('created_at', '>=', $dateRange)
            ->where('anhien', 1)
            ->orderBy('created_at', 'desc')
            ->take(5)
            ->get();

        // Dữ liệu cho biểu đồ doanh thu
        $revenueData = [];
        $revenueLabels = [];
        if ($filter == 'today') {
            // Doanh thu theo giờ trong ngày
            $hours = range(0, 23);
            foreach ($hours as $hour) {
                $revenueLabels[] = "$hour:00";
                $revenueData[] = DonHang::where('trangthai', 'Đã thanh toán')
                    ->whereDate('created_at', now()->toDateString())
                    ->whereRaw('HOUR(created_at) = ?', [$hour])
                    ->sum('tongtien');
            }
        } elseif ($filter == 'week') {
            // Doanh thu theo ngày trong tuần
            $days = now()->startOfWeek()->daysUntil(now()->endOfWeek());
            foreach ($days as $day) {
                $revenueLabels[] = $day->format('d/m');
                $revenueData[] = DonHang::where('trangthai', 'hoàn thành')
                    ->whereDate('created_at', $day->toDateString())
                    ->sum('tongtien');
            }
        } elseif ($filter == 'month') {
            // Doanh thu theo ngày trong tháng
            $days = now()->startOfMonth()->daysUntil(now()->endOfMonth());
            foreach ($days as $day) {
                $revenueLabels[] = $day->format('d/m');
                $revenueData[] = DonHang::where('trangthai', 'hoàn thành')
                    ->whereDate('created_at', $day->toDateString())
                    ->sum('tongtien');
            }
        } else {
            // Doanh thu theo tháng trong năm
            $months = range(1, 12);
            foreach ($months as $month) {
                $revenueLabels[] = "Tháng $month";
                $revenueData[] = DonHang::where('trangthai', 'hoàn thành')
                    ->whereYear('created_at', now()->year)
                    ->whereMonth('created_at', $month)
                    ->sum('tongtien');
            }
        }

        return view('admin.thongke.thongke', compact(
            'doanhThu',
            'soDonHang',
            'soKhachHang',
            'soDanhGia',
            'soBaiVietMoi',
            'soSanPhamNoiBat',
            'soKhuyenMaiHoatDong',
            'sanPhamBanChay',
            'sanPhamSapHet',
            'baiVietMoi',
            'danhGiaMoi',
            'revenueLabels',
            'revenueData'
        ));
    }
}
