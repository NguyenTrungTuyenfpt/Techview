<?php

namespace App\Http\Controllers\Admin;

use App\Http\Controllers\Controller;
use Illuminate\Http\Request;

class UploadController extends Controller
{
    public function uploadImage(Request $request)
    {
        try {
            if (!$request->hasFile('upload')) {
                return response()->json([
                    'error' => [
                        'message' => 'Không có file được upload'
                    ]
                ], 400);
            }

            $file = $request->file('upload');
            if (!$file->isValid()) {
                return response()->json([
                    'error' => [
                        'message' => 'File không hợp lệ'
                    ]
                ], 400);
            }

            $filename = $file->getClientOriginalName();
            $path = public_path('uploads/baiviet');
            
            // Kiểm tra thư mục tồn tại
            if (!file_exists($path)) {
                mkdir($path, 0755, true);
            }

            $file->move($path, $filename);
            $url = asset('uploads/baiviet/' . $filename);

            return response()->json([
                'url' => $url
            ], 200);
        } catch (\Exception $e) {
            \Log::error('Upload image error: ' . $e->getMessage());
            return response()->json([
                'error' => [
                    'message' => 'Lỗi khi upload file: ' . $e->getMessage()
                ]
            ], 500);
        }
    }
}