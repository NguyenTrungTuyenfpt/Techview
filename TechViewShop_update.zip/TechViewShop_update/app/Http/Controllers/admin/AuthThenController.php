<?php

namespace App\Http\Controllers\Admin;

use App\Http\Controllers\Controller;
use Illuminate\Support\Facades\Hash;
use Illuminate\Auth\Notifications\VerifyEmail;
use Illuminate\Support\Facades\Mail;
use App\Mail\VerifyEmailMail_admin;
use Illuminate\Http\Request;
use Carbon\Carbon;
use App\Models\Models_2\User;

use Illuminate\Support\Facades\Auth;


class AuthThenController extends Controller
{
    public function register() {
        return view('admin.auth.register');
    }

    public function postRegister(Request $req) {
       
        $validated = $req->validate([
            'name' => 'required|string|min:2|max:100',
            'email' => 'required|email|unique:users',
            'password' => [
                'required',
                'min:8',
                'regex:/[A-Z]/',
                'regex:/[a-z]/',
                'regex:/[0-9]/',
                'regex:/[\W]/'
            ],
            'confirm_password' => 'required|same:password'
        ]);

        $user = User::where('email', $req->email)->first();
        if(isset($user)) {
            return redirect()->back()->with('message', 'Email đã tồn tại, không thể đăng ký!');
        }

        $user = User::create([
            'hoten' => $validated['name'],
            'email' => $validated['email'],
            'matkhau' => Hash::make($validated['password']),
            'email_verified_at' => null,
            'vaitro' => 1
        ]);

        if ($user) {
            // Gửi email xác thực
            Mail::to($user->email)->send(new VerifyEmailMail_admin($user));
             return redirect()->route('auth.login')->with('message', 'Đăng ký thành công! Vui lòng kiểm tra email để xác thực tài khoản.');
        }
        
        return back()->with('message', 'Đăng ký thất bại, vui lòng thử lại.');

    }


    public function verifyEmail($id) {
        $user = User::where('id', $id)->first();
        if (!$user) {
            return redirect()->route('auth.login')->with('message', 'Tài khoản không tồn tại!');
        }
        if ($user->email_verified_at) {
            return redirect()->route('auth.login')->with('message', 'Tài khoản đã được xác thực trước đó!');
        }
        $user->update(['email_verified_at' => Carbon::now()]);
        return redirect()->route('auth.login')->with('message', 'Xác thực tài khoản thành công, Bạn có thể đăng nhập!');
    }


    public function login() {
        return view('admin.auth.login');
    }


    public function postLogin(Request $req) {
        $email = $req->email;
        $password = $req->password;
        $remember = $req->remember;
        $user = User::where('email', $email)->first();

        // dd($email, $password);

        if (!$user || !Hash::check($password, $user->matkhau) ) {
            return back()->with(['message' => 'Email hoặc mật khẩu không đúng!', 'status' => 'error']);
        }

        if($user['vaitro'] != 1){
            return back()->with('message', 'Tài khoản của bạn không có quyền truy cập!');
        }
        if (!$user->email_verified_at) {
            return back()->with('message', 'Bạn cần xác thực email trước khi đăng nhập.');
        }
        // dd($req->all());
        // Đăng nhập người dùng
        Auth::login($user, $remember);

        return redirect('/admin')->with([
            'messages' => 'Chào mừng ' . $user->hoten . ' trở lại!',
            'status' => 'success'
        ]);
     
    }


    public function logout(Request $req) {
        $user = Auth::user();
        if ($user) {
            $user->update(['remember_token' => null]);
        }
        Auth::logout();
        $req->session()->forget('user');
        $req->session()->regenerateToken();
        return redirect()->route('auth.login');
    }




}
