<?php

namespace App\Http\Controllers\clients;
use App\Http\Controllers\Controller;
use App\Models\Blog;
use App\Models\Category;
use App\Models\Coupon;
use App\Models\Favorite;
use App\Models\OrderDetail;
use App\Models\Product;
use App\Traits\RatingTrait;
use Illuminate\Http\Request;
use Illuminate\Support\Facades\Auth;
use Illuminate\Support\Facades\DB;

class HomeController extends Controller
{
    use RatingTrait;
    public function __construct() {
        $this->updateSoldQuantities();
    }
    public function index() {
        $coupon = Coupon::orderBy('id', 'DESC')->first();
        $countdown = $coupon ? $coupon->getCountdown() : null;
        $productHot = Product::where('noibat', 1)->orderBy('id', 'DESC')->limit(8)->get();
        $productList = Product::orderBy('id', 'DESC')->limit(10)->get();
        $topCategory = Category::whereNull('id_danhmuc_cha')->withCount('product')->orderBy('product_count', 'DESC')->limit(6)->get();
        $rating = $this->getProductRatings();  
        $wishlistCount = Favorite::where('id_user', Auth::id())->count();
        $productHotSaller = Product::bestSellers()->get();
        $productSaller = Product::where('giamgia', '>', 0)->orderBy('id','DESC')->limit(5)->get();
        $productID = $productHotSaller->pluck('id')->toArray();
        $sold_quantity = OrderDetail::soldQuantity($productID);
        $blogs = Blog::orderBy('id', 'DESC')->with('user')->withCount('comments')->get();
        $data = [
            'productSaller' => $productSaller,
            'countdown' => $countdown,
            'coupon' => $coupon,
            'topCategory' => $topCategory,
            'productHot' => $productHot,
            'productList' => $productList,
            'wishlistCount' => $wishlistCount,
            'rating' => $rating,
            'productHotSaller' => $productHotSaller,
            'sold_quantity' => $sold_quantity,
            'blogs' => $blogs
        ];
        return view('client.pages.home', $data);
    }
    public function updateSoldQuantities()
    {
        $sold = DB::table('chitietdonhang')
            ->join('donhang', 'donhang.id', '=', 'chitietdonhang.id_donhang')
            ->where('donhang.trangthai', 3) // trạng thái "Hoàn thành"
            ->select('chitietdonhang.id_sanpham', DB::raw('SUM(chitietdonhang.soluong) as total_sold'))
            ->groupBy('chitietdonhang.id_sanpham')
            ->get();
        foreach ($sold as $item) {
            $product = Product::where('id', $item->id_sanpham)->first();
            if ($product) {
                $newStock = max(0, $product->soluong - $item->total_sold);
                $product->update([
                    'tonkho' => $newStock
                ]);
            }
        }
    }
}
