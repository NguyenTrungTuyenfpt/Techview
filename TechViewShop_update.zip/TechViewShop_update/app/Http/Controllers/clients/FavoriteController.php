<?php

namespace App\Http\Controllers\clients;

use App\Http\Controllers\Controller;
use App\Models\Favorite;
use App\Models\Product;
use Carbon\Carbon;
use Illuminate\Http\Request;
use Illuminate\Support\Facades\Auth;
use Illuminate\Support\Facades\Session;

class FavoriteController extends Controller
{
    public function index() {
        if (auth()->check()) {
            $favoriteList = Favorite::where('id_user', auth()->id())->with('product')->orderBy('id', 'DESC')->get();     
        } else {
            $favoriteList = [];
            $FavoriteSession = Session::get('favorite', []);
            foreach ($FavoriteSession as $item) {
                $product = Product::find($item['id']);
                if ($product) {
                    $favoriteList[] = (object) [
                        'id' => $product->id,
                        'ngaythem' => Carbon::now(),
                        'product' => $product 
                    ];
                }
            }
        }
        
        $data = [
            'favoriteList' => $favoriteList
        ];
       
        return view('client.pages.favorite', $data);
    }

    public function add(Request $req) {
        // dd($req);
        $product = Product::find($req->id);
        if(auth()->check()) {
            // Nếu user đã đăng nhập, lưu vào database
            $user = auth()->id();
            $favoriteItem = Favorite::where('id_user',  $user)->where('id_sanpham', $product->id)->first();
            if (!$favoriteItem) {
                Favorite::create([
                    'id_user' => $user,
                    'id_sanpham' => $product->id,
                    'ngaythem' => Carbon::now()
                ]);
            }
        }  else {
            // Nếu chưa đăng nhập, lưu vào session
            $favorite = Session::get('favorite', []);
           // Kiểm tra xem sản phẩm đã có trong session chưa
            if (!in_array($req->id, array_column($favorite, 'id'))) {
                $favorite[] = ['id' => $req->id]; // Thêm sản phẩm vào danh sách yêu thích
                Session::put('favorite', $favorite);
            }
        }

        // dd($favorite);
        return redirect('/favorite');
    }

    public function delete($id) {
        if (auth()->check()) {
            Favorite::where('id_user', auth()->id())->where('id', $id)->delete();
        } else {
            $favorite = session()->get('favorite', []);
            foreach ($favorite as $key => $item) {
                if ($item['id'] == $id) {
                    unset($favorite[$key]);
                    break; 
                }   
            }
            session()->put('favorite', array_values($favorite));
        }
        return redirect()->back();
    }
}
