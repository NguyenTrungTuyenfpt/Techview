<?php

namespace App\Http\Controllers\clients;

use App\Http\Controllers\Controller;
use App\Models\Cart;
use App\Models\Favorite;
use App\Models\Product;
use Illuminate\Http\Request;
use Illuminate\Support\Facades\Auth;
use Illuminate\Support\Facades\Session;

class CartController extends Controller
{
    public function index() {
        if (auth()->check()) {
            $cartList = Cart::where('id_user', auth()->id())->with('product')->orderBy('id', 'DESC')->get();     
        } else {
            $cartList = [];
            $cartSession = Session::get('cart', []);
            foreach ($cartSession as $item) {
                $product = Product::find($item['id']);
                $total = (int)($product->gia * (1 - ($product->giamgia / 100)) * $item['quantity']);
                if ($product) {
                    $cartList[] = (object) [
                        'id' => $product->id,
                        'soluong' => $item['quantity'],
                        'product' => $product, 
                        'total' => $total  
                    ];
                }
            }
            $cartTotal = collect($cartList)->sum('total');
            session(['cartTotal' => $cartTotal]);
        }
        $total = 0;
        foreach ($cartList as $cart) {
            $total += $cart->product->gia * (1 - ($cart->product->giamgia/100)) * $cart->soluong;
        }
        $data = [
            'cartList' => $cartList,
            'total' => $total,
        ];
        return view('client.pages.cart', $data);
    }

    public function add(Request $req) {
        $product = Product::find($req->id);
        if(auth()->check()) {
            // Nếu user đã đăng nhập, lưu vào database
            $user = auth()->id();
            $cartItem = Cart::where('id_user',  $user)->where('id_sanpham', $product->id)->first();
            if($cartItem) {
                $cartItem->soluong += $req->quantity;
                $cartItem->save();
            } else {
                Cart::create([
                    'soluong' => $req->quantity,
                    'gia' => $product->gia,
                    'id_user' => $user,
                    'id_sanpham' => $product->id
                ]);
            }
            $favoriteItem = Favorite::where('id_user', $user)->where('id_sanpham', $product->id)->first();
            if ($favoriteItem) {
                $favoriteItem->delete(); // Xóa đúng ID của sản phẩm trong wishlist
            }

        }  else {
            // Nếu chưa đăng nhập, lưu vào session
            if(!Session::exists('cart')) {
                Session::put('cart', []);
            }
            $cart = Session::get('cart', []);
            $favorite = Session::get('favorite', []);
            $flag = false;
            // TH1:sản phẩm đã có trong giỏ hàng -> cập nhật số lượng
            foreach($cart as &$item) {
                if($item['id'] == $req->id) {
                    $item['quantity'] += $req->quantity;
                    Session::put('cart', $cart);
                    $flag = true;
                    break;
                } 
            }
            // TH2: chưa có sản phẩm trong giỏ hàng -> THêm 
            if(!$flag) {
                Session::push('cart', [
                    'id' => $req->id,
                    'quantity' => $req->quantity
                ]);
            }
            $favorite = array_filter($favorite, function ($item) use ($product) {
                return $item['id'] != $product->id;
            });
            Session::put('favorite', array_values($favorite)); // Cập nhật lại session
        }

        return redirect()->back()->with('success', 'Sản phẩm đã được thêm vào giỏ hàng');
    }

    public function update(Request $req, string $id) {
        // Kiểm tra xem người dùng có đăng nhập hay không
        if (auth()->check()) {
            $user = auth()->user()->id;
            // Lấy giỏ hàng từ cơ sở dữ liệu nếu người dùng đã đăng nhập
            $cart = Cart::where('id_user', $user)->get();
            // Duyệt qua giỏ hàng để cập nhật số lượng
            $flag = false;
            foreach ($cart as $cartItem) {
                if ($cartItem->id_sanpham == $id) {
                    $cartItem->soluong = (int) $req->quantity; // Cập nhật số lượng
                    $cartItem->save(); // Lưu lại giỏ hàng vào cơ sở dữ liệu
                    $flag = true;
                    break;
                }
            }

            // // Nếu có sự thay đổi, có thể đồng bộ lại giỏ hàng vào session nếu cần thiết
            // if ($flag) {
            //     // Đồng bộ lại giỏ hàng vào session (tuỳ chọn)
            //     Session::put('cart', $cart->toArray());
            // }

        } else {
            // Nếu người dùng chưa đăng nhập, xử lý giỏ hàng trong session
            if (!Session::exists('cart')) {
                Session::put('cart', []);
            }

            $cart = Session::get('cart');
            $flag = false;

            foreach ($cart as $index => $item) {
                if ($item['id'] == $id) {
                    $cart[$index]['quantity'] = (int) $req->quantity; // Cập nhật số lượng sản phẩm
                    $flag = true;
                    break;
                }
            }
            // Lưu lại giỏ hàng vào session nếu có thay đổi
            if ($flag) {
                Session::put('cart', $cart);
            }
        }
    }

    public function delete ($id) {
        if (auth()->check()) {
            Cart::where('id_user', auth()->id())->where('id', $id)->delete();
        } else {
            $cart = session()->get('cart', []);
            foreach ($cart as $key => $item) {
                if ($item['id'] == $id) { // Kiểm tra ID sản phẩm
                    unset($cart[$key]); // Xóa phần tử có ID khớp
                    break; // Thoát khỏi vòng lặp sau khi xóa
                }
            }
            session()->put('cart', array_values($cart));
        }
        return redirect()->back();
    }
}
