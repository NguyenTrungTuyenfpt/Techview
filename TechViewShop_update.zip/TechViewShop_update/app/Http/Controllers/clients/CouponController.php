<?php

namespace App\Http\Controllers\clients;

use App\Http\Controllers\Controller;
use App\Models\Cart;
use App\Models\Coupon;
use Illuminate\Http\Request;

class CouponController extends Controller
{
    public function apply(Request $req) {
        if ($req->form_type === "coupon") {
            $couponCode = $req->input('coupon_code'); // Chỉ lấy coupon_code
            // Xử lý mã giảm giá
        }
        $req->validate([
            'coupon_code' => 'string|max:10'
        ]);

        $couponCode = Coupon::where('makm', $req->coupon_code)->first();
        
        if (!$couponCode) {
            return back()->with('error', 'Mã khuyến mãi không hợp lệ.');
        }

        $today = now();

        if ($couponCode->ngayketthuc < $today) {
            return back()->with('error', 'Mã khuyến mãi đã hết hạn.');
        }

        $cartList = Cart::where('id_user', auth()->id())->with('product')->get();

        $total = 0;
        foreach ($cartList as $cart) {
            $total += $cart->product->gia * (1 - ($cart->product->giamgia / 100)) * $cart->soluong;
        }

        if ($total < $couponCode->tongtientoithieu) {
            return back()->with('error', 'Đơn hàng tối thiểu phải đạt ' . number_format($couponCode->tongtientoithieu) . '₫ để sử dụng mã này.');
        }
        session(['coupon' => $couponCode]);
        return back()->with('success', 'Mã giảm giá áp dụng thành công!');
        // dd($req);
    }
}
