<?php

namespace App\Mail;

use Illuminate\Bus\Queueable;
use Illuminate\Contracts\Queue\ShouldQueue;
use Illuminate\Mail\Mailable;
use Illuminate\Mail\Mailables\Content;
use Illuminate\Mail\Mailables\Envelope;
use Illuminate\Queue\SerializesModels;
use App\Models\DonHang;

class MailDHHoanThanh extends Mailable
{
    use Queueable, SerializesModels;

    public $donhang;
    public function __construct(DonHang $donhang)
    {
        $this->donhang = $donhang;
    }

    public function content() {
        return new Content(
            view: 'admin.donhang.donhanghoanthanh',
        );
    }

    public function build()
    {
         return $this->view('emails.order_completed')
        ->with([
            'madonhang' => $this->donhang->madonhang,
            'ngaytao' => $this->donhang->created_at,
            'tennguoinhan' => $this->donhang->tennguoinhan,
            'tongtien' => number_format($this->donhang->tongtien, 0, ',', '.') . ' VNĐ',
            'chitietdonhang' => $this->donhang->chitietdonhang, // Nếu cần lấy chi tiết đơn hàng
        ]);
    }
}
