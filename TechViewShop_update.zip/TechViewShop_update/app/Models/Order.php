<?php

namespace App\Models;

use Carbon\Traits\Timestamp;
use Illuminate\Database\Eloquent\Factories\HasFactory;
use Illuminate\Database\Eloquent\Model;

class Order extends Model
{
    use HasFactory;
    protected $table = 'donhang';
    protected $fillable = [
        'tennguoinhan',
        'sodienthoai',
        'diachi',
        'ghichu',
        'tongtien',
        'trangthai',
        'phuongthucthanhtoan',
        'phuongthucgiaohang',
        'ngaytao',
        'id_user',
        'id_khuyenmai'
    ];
    public function khachHang()
    {
        return $this->belongsTo(User::class, 'id_user');
    }
    public function orderDetail() {
        return $this->hasMany(OrderDetail::class, 'id_donhang');
    }
    public function coupon()
    {
        return $this->belongsTo(Coupon::class, 'id_khuyenmai');
    }
    
    public $timestamps  = false;
}
