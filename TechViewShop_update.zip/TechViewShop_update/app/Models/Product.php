<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Factories\HasFactory;
use Illuminate\Database\Eloquent\Model;
use Illuminate\Support\Facades\DB;

class Product extends Model
{
    use HasFactory;
    protected $table = 'sanpham';
    protected $fillable = [
        'tensp',
        'slug',
        'hinh',
        'mota',
        'gia',
        'giamgia',
        'soluong',
        'tonkho',
        'luotxem',
        'anhien',
        'noibat',
        'id_danhmuc',
        'id_nhacungcap'
    ];

    public function giohang() {
        return $this->hasMany(Cart::class, 'id_sanpham');
    }
    public function category() {
        return $this->belongsTo(Category::class, 'id_danhmuc');
    }

    public function images() {
        return $this->hasMany(ImageProduct::class, 'id_sanpham');
    } 
    public function specs() {
        return $this->hasMany(Specs::class, 'id_sanpham');
    } 

    public function scopeBestSellers($query, $limit = 2)
    {
        return $query->where('giamgia', '>', 0)
                     ->orderBy('giamgia', 'DESC')
                     ->orderBy('id', 'DESC')
                     ->limit($limit);
    }
    public function danhGiaSanPham()
    {
        return $this->hasMany(DanhGiaSanPham::class, 'id_sanpham', 'id');
    }
}
