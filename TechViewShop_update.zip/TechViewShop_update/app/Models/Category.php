<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Factories\HasFactory;
use Illuminate\Database\Eloquent\Model;

class Category extends Model
{
    use HasFactory;
    protected $table = 'danhmuc';
    protected $fillable = [
        'tendm', 
        'mota', 
        'id_danhmuc_cha', 
        'hinh', 
        'thutu', 
        'anhien'
    ];
    // Một danh mục có nhiều sản phẩm
    public function product()
    {
        return $this->hasMany(Product::class, 'id_danhmuc', 'id');
    }
    public function parent()
    {
        return $this->belongsTo(Category::class, 'id_danhmuc_cha');
    }
    public function children()
    {
        return $this->hasMany(Category::class, 'id_danhmuc_cha');
    }
}
