<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Factories\HasFactory;
use Illuminate\Database\Eloquent\Model;

class DanhGiaSanPham extends Model
{
    use HasFactory;
    protected $table = 'danhgiasanpham';

    protected $fillable = [
        'id_user',
        'id_sanpham',
        'danhgia',
        'noidung',
        'anhien',
    ];
    
    public $timestamps = true;

    public function product()
    {
        return $this->belongsTo(SanPham::class, 'id_sanpham', 'id');
    }

    // Quan hệ với User
    public function user()
    {
        return $this->belongsTo(User::class, 'id_user', 'id');
    }

     // một phản hồi chỉ thuộc về một đánh giá gốc.
     public function phanHoi()
     {
         return $this->hasOne(DanhgiaSanpham::class, 'id_danhgia');
     }

     // Mối quan hệ với đánh giá gốc (nếu có phản hồi)
    public function danhGiaGoc()
    {
        return $this->hasOne(DanhgiaSanpham::class, 'id_danhgia');
    }


}
