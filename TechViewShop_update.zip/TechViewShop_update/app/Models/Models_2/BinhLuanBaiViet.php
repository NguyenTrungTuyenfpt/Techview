<?php

namespace App\Models\Models_2;

use Illuminate\Database\Eloquent\Factories\HasFactory;
use Illuminate\Database\Eloquent\Model;

class BinhLuanBaiViet extends Model
{
    use HasFactory;

    protected $table = 'binhluanbaiviet';
    protected $fillable = [
         'noidung','anhien','id_user','id_baiviet','id_binhluan'
    ];
    public $timestamps = true;


    // Mối quan hệ với bảng users (người dùng)
    public function user() {
        return $this->belongsTo(User::class, 'id_user');
    }

    // Mối quan hệ với bảng posts (bài viết)
    public function baiviet() {
        return $this->belongsTo(Baiviet::class, 'id_baiviet');
    }
     
    // Một bình luận có thể có nhiều phản hồi
    public function replies()
    {
        return $this->hasMany(BinhLuanBaiviet::class, 'id_binhluan');
    }

    // Một bình luận có thể là phản hồi của một bình luận khác
    public function parent()
    {
        return $this->belongsTo(BinhLuanBaiviet::class, 'id_binhluan');
    }

}
