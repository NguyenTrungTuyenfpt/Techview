<?php

namespace App\Models\Models_2;

use Illuminate\Database\Eloquent\Factories\HasFactory;
use Illuminate\Database\Eloquent\Model;

class BaiViet extends Model
{
    use HasFactory;
    protected $table = 'baiviet';
    protected $fillable = [
        'tieude',
        'noidung',
        'hinh',
        'anhien',
        'id_danhmucbaiviet',
        'id_user',
    ];
    public $timestamps = true;


    // 'id_user',
    public function nguoiTao()
    {
        return $this->belongsTo(User::class, 'id_user');
    }


    public function danhMucBaiViet() {
        return $this->belongsTo(DanhMucBaiViet::class, 'id_danhmucbaiviet');
    }
}
