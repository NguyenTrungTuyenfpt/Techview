<?php

namespace App\Models\Models_2;

use Illuminate\Database\Eloquent\Factories\HasFactory;
use Illuminate\Database\Eloquent\Model;

class YeuThichSanPham extends Model
{
    use HasFactory;
    protected $table = 'yeuthichsanpham';

    protected $fillable = [
        'id_user',
        'id_sanpham',
        'ngaythem',
    ];

    public $timestamps = true;

    // Chỉ định cột created_at, bỏ updated_at
    const CREATED_AT = 'ngaythem';
    const UPDATED_AT = null;

    // Quan hệ với user
    public function user()
    {
        return $this->belongsTo(User::class, 'id_user');
    }

    // Quan hệ với sản phẩm
    public function sanpham()
    {
        return $this->belongsTo(SanPham::class, 'id_sanpham');
    }
}