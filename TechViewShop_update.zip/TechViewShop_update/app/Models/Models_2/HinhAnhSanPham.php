<?php

namespace App\Models\Models_2;

use Illuminate\Database\Eloquent\Factories\HasFactory;
use Illuminate\Database\Eloquent\Model;

class HinhAnhSanPham extends Model
{
    protected $table = 'hinhanhsanpham'; 

    protected $fillable = ['src', 'anhien', 'id_sanpham','id_user'];

    // Quan hệ ngược lại với sản phẩm (nếu cần dùng)
    public function sanpham()
    {
        return $this->belongsTo(SanPham::class, 'id_sanpham');
    }

    // Quan hệ ngược lại với user (nếu cần dùng)
    public function nguoiTao() {
        return $this->belongsTo(User::class, 'id_user');
    }
    
    
}
