<?php

namespace App\Models\Models_2;

use Illuminate\Database\Eloquent\Factories\HasFactory;
use Illuminate\Database\Eloquent\Model;

class ChiTietDonHang extends Model
{
    use HasFactory;
    protected $table = 'chitietdonhang';
    public $timestamps = false;

    protected $fillable = [
        'id_donhang',
        'id_sanpham',
        'gia',
        'soluong',
    ];

    // Quan hệ: Chi tiết đơn hàng thuộc về một đơn hàng
    public function donhang()
    {
        return $this->belongsTo(DonHang::class, 'id_donhang');
    }

    // Quan hệ: Chi tiết đơn hàng thuộc về một sản phẩm
    public function sanpham()
    {
        return $this->belongsTo(SanPham::class, 'id_sanpham');
    }

    




}
