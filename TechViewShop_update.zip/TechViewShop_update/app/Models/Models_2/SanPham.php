<?php

namespace App\Models\Models_2;

use Illuminate\Database\Eloquent\Factories\HasFactory;
use Illuminate\Database\Eloquent\Model;

class SanPham extends Model
{
    use HasFactory;

    protected $table = 'sanpham';
    protected $fillable = [
        'tensp',
        'slug',
        'thuonghieu',
        'mota',
        'hinh',
        'gia',
        'giagiam',
        'soluong',
        'tonkho',
        'luotxem',
        'anhien',
        'noibat',
        'id_danhmuc',
        'id_nhacungcap',
        'id_user',
    ];
    public $timestamps = true;

    public function danhmuc()
    {
        return $this->belongsTo(DanhMuc::class, 'id_danhmuc');
    }

    public function nhacungcap()
    {
        return $this->belongsTo(NhaCungCap::class, 'id_nhacungcap');
    }

    public function anhsanpham()
    {
        return $this->hasMany(HinhAnhSanPham::class, 'id_sanpham');
    }

    public function donHangChiTiet()
    {
        return $this->hasMany(ChiTietDonHang::class, 'id_sanpham', 'id');
    }

    public function nguoiTao() {
        return $this->belongsTo(User::class, 'id_user');
    }

}
