<?php

namespace App\Models\Models_2;
use Illuminate\Database\Eloquent\Factories\HasFactory;
use Illuminate\Database\Eloquent\Model;

class Banner extends Model
{
    use HasFactory;

    protected $table = 'banners';
    protected $fillable = [
        'hinh',
        'ten',
        'mota',
        'vitri',
        'anhien',
        'thutu',
        'link',
        'id_user',
    ];
    public $timestamps = true;


     // 'id_user',
     public function nguoiTao() {
        return $this->belongsTo(User::class, 'id_user');
    }
    
   
    
}
