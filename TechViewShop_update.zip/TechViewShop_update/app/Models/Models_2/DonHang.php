<?php

namespace App\Models\Models_2;

use Illuminate\Database\Eloquent\Factories\HasFactory;
use Illuminate\Database\Eloquent\Model;

class DonHang extends Model
{
    use HasFactory;
    protected $table = 'donhang';

    public $timestamps = true; 

    protected $fillable = [
        'madonhang',
        'tennguoinhan',
        'sodienthoai',
        'diachi',
        'ghichu',
        'tongtien',
        'trangthai',
        'phuongthucgiaohang',
        'phuongthucthanhtoan',
        'id_user',
        'id_khuyenmai',
    ];

    // Quan hệ: 1 đơn hàng có nhiều chi tiết
    public function chitietdonhang()
    {
        return $this->hasMany(ChiTietDonHang::class, 'id_donhang');
    }

    // Quan hệ với người dùng
    public function user()
    {
        return $this->belongsTo(User::class, 'id_user');
    }

    // Quan hệ với khuyến mãi
    public function khuyenmai()
    {
        return $this->belongsTo(KhuyenMai::class, 'id_khuyenmai');
    }
}
