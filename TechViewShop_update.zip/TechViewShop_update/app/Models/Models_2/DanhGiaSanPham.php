<?php

namespace App\Models\Models_2;
use Illuminate\Database\Eloquent\Factories\HasFactory;
use Illuminate\Database\Eloquent\Model;

class DanhGiaSanPham extends Model
{
    use HasFactory;
    protected $table = 'danhgiasanpham';

    protected $fillable = [
        'id_user',
        'id_sanpham',
        'id_donhang', 
        'id_danhgia',
        'danhgia',
        'noidung',
        'anhien',
    ];
    
    public $timestamps = true;

    // Quan hệ với user
    public function user()
    {
        return $this->belongsTo(User::class, 'id_user');
    }

    // Quan hệ với sản phẩm
    public function sanpham()
    {
        return $this->belongsTo(SanPham::class, 'id_sanpham');
    }

    // Quan hệ với đơn hàng
    public function donhang()
    {
        return $this->belongsTo(DonHang::class, 'id_donhang');
    }

    // Một đánh giá có thể có một phản hồi (quan hệ one-to-one)
    public function phanHoi()
    {
        return $this->hasOne(DanhGiaSanPham::class, 'id_danhgia', 'id');
    }

    // Một phản hồi thuộc về một đánh giá gốc (quan hệ ngược lại)
    public function danhGiaGoc()
    {
        return $this->belongsTo(DanhGiaSanPham::class, 'id_danhgia', 'id');
    }
}