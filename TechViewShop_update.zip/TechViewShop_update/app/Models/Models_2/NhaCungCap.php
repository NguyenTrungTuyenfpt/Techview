<?php

namespace App\Models\Models_2;

use Illuminate\Database\Eloquent\Factories\HasFactory;
use Illuminate\Database\Eloquent\Model;

class NhaCungCap extends Model
{
    protected $table = 'nhacungcap';
    protected $fillable = [
        'tenncc',
        'email',
        'mota',
        'sodienthoai',
        'diachi',
        'hinh',
        'thutu',
        'anhien',
        'id_user',
    ];

    
    public $timestamps = true;

    public function sanphams()
    {
        return $this->hasMany(SanPham::class, 'id_nhacungcap');
    }

    public function nguoiTao() {
        return $this->belongsTo(User::class, 'id_user');
    }
    
}
