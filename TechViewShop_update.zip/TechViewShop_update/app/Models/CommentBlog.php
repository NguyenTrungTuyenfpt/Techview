<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Factories\HasFactory;
use Illuminate\Database\Eloquent\Model;

class CommentBlog extends Model
{
    use HasFactory;

    protected $table = 'binhluanbaiviet';
    protected $fillable = [
        'noidung',
        'anhien',
        'id_user',
        'id_baiviet'
    ];
    public $timestamps = true;

}
