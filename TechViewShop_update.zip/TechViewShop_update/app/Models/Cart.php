<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Factories\HasFactory;
use Illuminate\Database\Eloquent\Model;

class Cart extends Model
{
    use HasFactory;
    protected $table = 'giohang';
    protected $fillable = [
        'gia',
        'soluong',
        'id_user',
        'id_sanpham'
    ]; 
    public function product() {
        return $this->belongsTo(Product::class, 'id_sanpham', 'id');
    }
    //  1 giỏ hàng thuộc về 1 user
    public function user() {
        return $this->belongsTo(User::class, 'id_user');
    }

   
}

