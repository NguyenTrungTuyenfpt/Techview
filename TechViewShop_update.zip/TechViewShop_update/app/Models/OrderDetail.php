<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Factories\HasFactory;
use Illuminate\Database\Eloquent\Model;
use Illuminate\Support\Facades\DB;

class OrderDetail extends Model
{
    use HasFactory;

    protected $table = 'chitietdonhang';

    protected $fillable = ['id_donhang', 'id_sanpham', 'gia', 'soluong'];
    public function scopeSoldQuantity($query, $productID)
    {
        return $query->join('donhang', 'donhang.id', '=', 'chitietdonhang.id_donhang')
                     ->whereIn('chitietdonhang.id_sanpham', $productID)
                     ->where('donhang.trangthai', 3)
                     ->select('chitietdonhang.id_sanpham', DB::raw('SUM(chitietdonhang.soluong) as total_sold'))
                     ->groupBy('chitietdonhang.id_sanpham')
                     ->pluck('total_sold', 'chitietdonhang.id_sanpham');
    }
    public function order() {
        return $this->belongsTo(Order::class, 'id_donhang');
    }
    public $timestamps = false;
}
