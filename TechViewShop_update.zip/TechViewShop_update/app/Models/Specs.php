<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Factories\HasFactory;
use Illuminate\Database\Eloquent\Model;

class Specs extends Model
{
    use HasFactory;
    protected $table = 'thuoctinhsanpham';
    protected $fillable = ['tenthuoctinh', 'giatri'];
    public function product() {
        return $this->belongsTo(Product::class, 'id_sanpham');
    }
}
