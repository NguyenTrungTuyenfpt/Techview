@extends('admin.layout.layout')

@section('title', 'Edit Product Category')

@section('content')
<!-- Nội dung chính của trang sẽ nằm ở đây -->

<form action="{{ route('danhmuc.update', $danhmuc->id) }}" method="POST" enctype="multipart/form-data">
    @csrf
    @method('PUT')

    <div class="container">
        <h4 class="fw-bold mt-4">Sửa danh mục</h4>
        <p><a href="/">Trang chủ</a> / <span class="text-primary">Sửa danh mục</span></p>

        <div class="border rounded p-3 shadow-sm bg-light">
            <h5 class="fw-bold">Thông tin danh mục</h5>
            <div class="row">
                <div class="col-md-4 mt-3">
                    <label class="form-label">Tên danh mục cũ: {{$danhmuc->tendm}}</label> <br>
                    <label class="form-label">Tên mới</label>
                    <input type="text" name="tendm" value="{{ old('tendm', $danhmuc->tendm) }}" class="form-control" required>
                </div>

                <div class="col-md-4 mt-3">
                    <label class="form-label">Mô tả cũ: {{$danhmuc->mota}}</label> <br>
                    <label class="form-label">Mô tả mới</label>
                    <input type="text" name="mota" value="{{ old('mota', $danhmuc->mota) }}" class="form-control">
                </div>

                <div class="col-md-4 mt-3">
                    <label class="form-label">Thứ tự cũ: {{$danhmuc->thutu}}</label> <br>
                    <label class="form-label">Thứ tự mới</label>
                    <input type="number" name="thutu" value="{{ old('thutu', $danhmuc->thutu) }}" class="form-control">
                </div>

                <div class="col-md-4 mt-3">
                    <label class="form-label d-block">Trạng thái hiển thị</label>

                    <div class="form-check form-check-inline">
                        <input class="form-check-input" type="radio" name="anhien" id="hienRadio" value="1"
                            {{ old('anhien', $danhmuc->anhien) == 1 ? 'checked' : '' }}>
                        <label class="form-check-label" for="hienRadio">Hiển thị</label>
                    </div>

                    <div class="form-check form-check-inline">
                        <input class="form-check-input" type="radio" name="anhien" id="anRadio" value="0"
                            {{ old('anhien', $danhmuc->anhien) == 0 ? 'checked' : '' }}>
                        <label class="form-check-label" for="anRadio">Ẩn</label>
                    </div>
                </div>

                <!-- Hình ảnh cũ và mới -->
                <div class="col-md-4 mt-3">
                    <label class="form-label">Hình ảnh cũ</label>
                    <div class="mb-2">
                        @if($danhmuc->hinh)
                        <img src="{{ asset('uploads/danhmuc/' . $danhmuc->hinh) }}" class="img-fluid" width="150" alt="Hình ảnh cũ">
                        @else
                        <p>Chưa có hình ảnh</p>
                        @endif
                    </div>
                    <label class="form-label">Hình ảnh mới</label>
                    <input type="file" name="hinh" class="form-control">
                </div>
                <!-- Chọn danh mục cha -->
                <div class="col-md-4 mt-3">
                    <label class="form-label">Danh mục cha</label>
                    <select name="id_danhmuc_cha" class="form-control">
                        <!-- Kiểm tra nếu có danh mục cha thì hiển thị tên, nếu không thì hiển thị 'Không có' -->
                       <option value="">Chọn danh mục cha </option>

                        @foreach($danhmucAll as $dm)
                        <option value="{{ $dm->id }}" {{ $danhmuc->id_danhmuc_cha == $dm->id ? 'selected' : '' }}>
                            {{ $dm->tendm }}
                        </option>
                        @endforeach
                    </select>
                </div>

            </div>
        </div>

        <div class="d-flex justify-content-end mt-3">
            <button type="submit" class="btn btn-success me-2">Cập nhật</button>
            <a href="{{ route('danhmuc') }}" class="btn btn-secondary">Hủy</a>
        </div>
    </div>
</form>

@if(session('popup'))
<script>
    document.addEventListener("DOMContentLoaded", function() {
        // Hiển thị hộp thoại confirm
        Swal.fire({
            icon: "{{ session('status', 'info') }}", // Loại thông báo
            title: '', // Tiêu đề có thể để trống hoặc chỉnh lại
            text: "{{ session('message') }}", // Nội dung thông báo
            showCancelButton: false, // Ẩn nút Cancel (nếu bạn chỉ muốn "OK")
            confirmButtonText: 'OK', // Nút xác nhận "OK"
        }).then((result) => {
            // Chỉ khi người dùng nhấn OK mới chuyển trang
            if (result.isConfirmed) {
                window.location.href = "{{ session('route') }}"; // Chuyển hướng
            }
        });
    });
</script>
@endif
</div>
</div>

@endsection