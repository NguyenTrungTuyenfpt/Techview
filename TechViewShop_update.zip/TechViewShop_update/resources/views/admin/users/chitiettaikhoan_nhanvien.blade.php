@extends('admin.layout.layout')

@section('title', 'Thành viên')

@section('content')

<div class="container my-4">
    @if(session('success'))
    <div class="alert alert-success">
        {{ session('success') }}
    </div>
    @endif
    <h2 class="mb-4">Chi tiết nhân viên</h2>
    <div class="row">
        <!-- Cột trái: Thông tin cá nhân -->
        <div class="col-md-4 mb-3">
            <div class="card">
                <div class="card-body text-center">
                    <img src="{{  asset('uploads/Users/' . $nhanvien->hinh) ?? 'https://via.placeholder.com/100' }}" class="rounded-circle mb-3 w-75" alt="Avatar">
                    <h5 class="card-title">{{ $nhanvien->hoten }}</h5>
                    <p class="text-muted mb-1"><i class="bi bi-envelope"></i> {{ $nhanvien->email }}</p>
                    <p class="text-muted mb-1"><i class="bi bi-telephone"></i> {{ $nhanvien->sodienthoai ?? 'Chưa cập nhật' }}</p>
                    <p class="text-muted mb-1">Vai trò:
                        <span class="badge bg-primary">
                            @if($nhanvien->phanquyen == 1)
                            Quản trị
                            @elseif($nhanvien->phanquyen == 2)
                            Cộng tác viên 1
                            @elseif($nhanvien->phanquyen == 3)
                            Cộng tác viên 2
                            @else
                            Chưa cập nhật
                            @endif
                        </span>
                    </p>

                    <p class="text-muted mb-1">Trạng thái:
                        <span class="badge {{ $nhanvien->trangthai ? 'bg-success' : 'bg-danger' }}">
                            {{ $nhanvien->trangthai ? 'Hoạt động' : 'Khóa' }}
                        </span>
                    </p>
                    <p class="text-muted">Ngày tạo: {{ $nhanvien->created_at->format('d/m/Y') }}</p>
                    <!-- Nút khóa/mở tài khoản -->
                    <div class="d-grid gap-2 mt-3">
                        <button class="btn btn-{{ $nhanvien->trangthai == 1 ? 'danger' : 'success' }} btn-sm" data-bs-toggle="modal" data-bs-target="#lockAccountModal">
                            {{ $nhanvien->trangthai == 1 ? 'Khóa tài khoản' : 'Mở tài khoản' }}
                        </button>
                    </div>
                </div>
            </div>
        </div>

        <!-- Cột phải: Tabs chi tiết -->
        <div class="col-md-8">
            <ul class="nav nav-tabs mb-3" id="memberTab" role="tablist">
                <li class="nav-item" role="presentation">
                    <button class="nav-link active" id="role-tab" data-bs-toggle="tab" data-bs-target="#role" type="button" role="tab">Nhật ký hoạt động</button>
                </li>
                <li class="nav-item" role="presentation">
                    <button class="nav-link" id="activity-tab" data-bs-toggle="tab" data-bs-target="#activity" type="button" role="tab">Quyền hạn</button>
                </li>
            </ul>
            <div class="tab-content" id="memberTabContent">
                <!-- Nhật ký hoạt động -->
                <div class="tab-pane fade show active" id="role" role="tabpanel">
                    <ul class="list-group">
                        @forelse($activities as $activity)
                        <li class="list-group-item">
                            <i class="bi {{ $activity['icon'] }} me-2 {{ $activity['color'] }}"></i>{{ $activity['message'] }}
                        </li>
                        @empty
                        <li class="list-group-item">Chưa có hoạt động nào được ghi nhận.</li>
                        @endforelse
                    </ul>
                    <div class="mt-4">
                        {{ $activities->appends(request()->query())->links('pagination::bootstrap-5') }}
                    </div>
                </div>

                <!-- Phân quyền -->
                <div class="tab-pane fade" id="activity" role="tabpanel">
                    <h5>
                        <p class="text-muted mb-1">Vai trò:
                            <span class="badge bg-primary">
                                @if($nhanvien->phanquyen == 1)
                                Quản trị
                                @elseif($nhanvien->phanquyen == 2)
                                Cộng tác viên 1
                                @elseif($nhanvien->phanquyen == 3)
                                Cộng tác viên 2
                                @else
                                Chưa cập nhật
                                @endif
                            </span>
                        </p>
                    </h5>
                    <ul class="list-group list-group-flush mb-3">
                        @if($nhanvien->phanquyen == 1)
                        <li class="list-group-item"><i class="bi bi-box-seam me-2 text-primary"></i>Quản lý sản phẩm</li>
                        <li class="list-group-item"><i class="bi bi-cart-check me-2 text-primary"></i>Quản lý đơn hàng</li>
                        @elseif($nhanvien->phanquyen == 2)
                        <li class="list-group-item"><i class="bi bi-journal-text me-2 text-primary"></i>Quản lý bài viết</li>
                        <li class="list-group-item"><i class="bi bi-folder-plus me-2 text-primary"></i>Quản lý danh mục</li>
                        @elseif($nhanvien->phanquyen == 3)
                        <li class="list-group-item"><i class="bi bi-gift me-2 text-primary"></i>Quản lý khuyến mãi</li>
                        @else
                        <li class="list-group-item">Chưa phân quyền cụ thể</li>
                        @endif
                    </ul>

                    <!-- Form chỉnh sửa quyền -->
                    <form action="{{ route('nhanvien.phanquyen', $nhanvien->id) }}" method="POST">
                        @csrf
                        @method('PUT')

                        <div class="form-check">
                            <input class="form-check-input" type="radio" name="phanquyen" id="phanquyen1" value="1" {{ $nhanvien->phanquyen == 1 ? 'checked' : '' }}>
                            <label class="form-check-label" for="phanquyen1">
                                Quản trị 1 (Quản lý tất cả)
                            </label>
                        </div>
                        <div class="form-check">
                            <input class="form-check-input" type="radio" name="phanquyen" id="phanquyen2" value="2" {{ $nhanvien->phanquyen == 2 ? 'checked' : '' }}>
                            <label class="form-check-label" for="phanquyen2">
                                Cộng tác 1 (Quản lý bài viết và danh mục)
                            </label>
                        </div>
                        <div class="form-check">
                            <input class="form-check-input" type="radio" name="phanquyen" id="phanquyen3" value="3" {{ $nhanvien->phanquyen == 3 ? 'checked' : '' }}>
                            <label class="form-check-label" for="phanquyen3">
                                Cộng tác 2 (Quản lý khuyến mãi)
                            </label>
                        </div>

                        <button type="submit" class="btn btn-primary mt-3">Cập nhật quyền hạn</button>
                    </form>
                </div>
            </div>

        </div>
    </div>
</div>


<!-- Modal: Khóa / Mở tài khoản -->
<div class="modal fade" id="lockAccountModal" tabindex="-1" aria-labelledby="lockAccountModalLabel" aria-hidden="true">
    <div class="modal-dialog">
        <div class="modal-content">
            <div class="modal-header">
                <h5 class="modal-title" id="lockAccountModalLabel">{{ $nhanvien->trangthai == 1 ? 'Khóa tài khoản' : 'Mở tài khoản' }}</h5>
                <button type="button" class="btn-close" data-bs-dismiss="modal" aria-label="Close"></button>
            </div>
            <div class="modal-body">
                Bạn có chắc chắn muốn {{ $nhanvien->trangthai == 1 ? 'khóa' : 'mở' }} tài khoản của <strong>{{ $nhanvien->hoten }}</strong>?
            </div>
            <div class="modal-footer">
                <form action="{{ route('nhanvien.lock', $nhanvien->id) }}" method="POST">
                    @csrf
                    @method('PUT')
                    <button type="button" class="btn btn-secondary" data-bs-dismiss="modal">Hủy</button>
                    <button type="submit" class="btn btn-{{ $nhanvien->trangthai == 1 ? 'danger' : 'success' }}">
                        {{ $nhanvien->trangthai == 1 ? 'Khóa tài khoản' : 'Mở tài khoản' }}
                    </button>
                </form>
            </div>
        </div>
    </div>
</div>



<script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.3/dist/js/bootstrap.bundle.min.js"></script>



@endsection