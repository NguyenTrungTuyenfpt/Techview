@extends('admin.layout.layout')

@section('title', 'Khách hàng')

@section('content')
<div class="container py-4">
    <div class="row">
        <!-- Sidebar trái: Thông tin khách hàng -->
        <div class="col-md-4">
            <div class="card mb-4 shadow-sm">
                <div class="card-body">
                    <h4 class="card-title">Thông tin khách hàng</h4>
                    <p><strong>Họ tên:</strong> {{ $khachhang->hoten }}</p>
                    <p><strong>Email:</strong> {{ $khachhang->email }}</p>
                    <p><strong>SĐT:</strong> {{ $khachhang->sodienthoai }}</p>
                    <p><strong>Địa chỉ:</strong> {{ $khachhang->diachi }}</p>
                    <p><strong>Ngày đăng ký:</strong> {{ $khachhang->created_at}}</p>
                    <p><strong>Trạng thái:</strong>
                        @if ($khachhang->trangthai == '1')
                        <span class="badge bg-success">Đang hoạt động</span>
                        @else
                        <span class="badge bg-danger">Đã khóa</span>
                        @endif
                    </p>
                    <hr>
                    <p><strong>Tổng đơn hàng:</strong> {{ $tongDon }}</p>
                    <p><strong>Tổng tiền đã chi:</strong> {{ number_format($tongTien, 0, ',', '.') }}đ</p>
                    <p><strong>Số đánh giá:</strong> {{ $soDanhGia }}</p>
                </div>
            </div>
        </div>

        <!-- Nội dung chính: Tabs -->
        <div class="col-md-8">
            <ul class="nav nav-tabs" id="customerTabs" role="tablist">
                <li class="nav-item" role="presentation">
                    <button class="nav-link active" data-bs-toggle="tab" data-bs-target="#orders" type="button" role="tab">Đơn hàng</button>
                </li>
                <li class="nav-item" role="presentation">
                    <button class="nav-link" data-bs-toggle="tab" data-bs-target="#stats" type="button" role="tab">Thống kê</button>
                </li>
                <li class="nav-item" role="presentation">
                    <button class="nav-link" data-bs-toggle="tab" data-bs-target="#top-products" type="button" role="tab">Sản phẩm mua nhiều</button>
                </li>
                <li class="nav-item" role="presentation">
                    <button class="nav-link" data-bs-toggle="tab" data-bs-target="#reviews" type="button" role="tab">Đánh giá</button>
                </li>
                <li class="nav-item" role="presentation">
                    <button class="nav-link" data-bs-toggle="tab" data-bs-target="#actions" type="button" role="tab">Hành động</button>
                </li>
            </ul>
            <div class="tab-content border border-top-0 p-3 bg-white shadow-sm">

                <!-- Đơn hàng -->
                <div class="tab-pane fade show active" id="orders" role="tabpanel">
                    <h5>Lịch sử đơn hàng</h5>
                    <table class="table table-striped">
                        <thead>
                            <tr>
                                <th>Mã</th>
                                <th>Ngày đặt</th>
                                <th>Trạng thái</th>
                                <th>Tổng tiền</th>
                                <th>Thanh toán</th>
                            </tr>
                        </thead>
                        <tbody>
                            @forelse ($donHangs as $don)
                            <tr>
                                <td>#{{ $don->id }}</td>
                                <td>{{ $don->created_at->format('d/m/Y') }}</td>
                                <td>
                                    @if ($don->trangthai == 'đã giao')
                                    <span class="badge bg-primary">Đã giao</span>
                                    @elseif ($don->trangthai == 'đã hủy')
                                    <span class="badge bg-danger">Đã hủy</span>
                                    @else
                                    <span class="badge bg-secondary">{{ ucfirst($don->trangthai) }}</span>
                                    @endif
                                </td>
                                <td>{{ number_format($don->tongtien, 0, ',', '.') }}đ</td>
                                <td>
                                    @if ($don->trangthaithanhtoan)
                                    <span class="badge bg-success">Đã thanh toán</span>
                                    @else
                                    <span class="badge bg-warning text-dark">Chưa thanh toán</span>
                                    @endif
                                </td>
                            </tr>
                            @empty
                            <tr>
                                <td colspan="5" class="text-center">Không có đơn hàng nào.</td>
                            </tr>
                            @endforelse
                        </tbody>
                    </table>
                </div>

                <!-- Thống kê -->
                <div class="tab-pane fade" id="stats" role="tabpanel">
                    <h5>Thống kê mua hàng</h5>
                    <ul class="list-group">
                        <li class="list-group-item">Tổng số đơn hàng: <strong>{{ $tongDon }}</strong></li>
                        <li class="list-group-item">Đã thanh toán: <strong>{{ $donThanhToan }}</strong></li>
                        <li class="list-group-item">Đơn bị hủy: <strong>{{ $donHuy }}</strong></li>
                        <li class="list-group-item">Tổng tiền đã chi: <strong>{{ number_format($tongTien, 0, ',', '.') }}đ</strong></li>
                    </ul>
                </div>

                <!-- Sản phẩm mua nhiều -->
                <div class="tab-pane fade" id="top-products" role="tabpanel">
                    <h5>Sản phẩm mua nhiều nhất</h5>
                    <table class="table">
                        <thead>
                            <tr>
                                <th>Tên sản phẩm</th>
                                <th>Số lần mua</th>
                                <th>Tổng tiền</th>
                            </tr>
                        </thead>
                        <tbody>
                            @forelse ($topSanPham as $sp)
                            <tr>
                                <td>{{ $sp->sanpham->tensp }}</td>
                                <td>{{ $sp->tong_so_luong }}</td>
                                <td>{{ number_format($sp->tong_tien, 0, ',', '.') }}đ</td>
                            </tr>
                            @empty
                            <tr>
                                <td colspan="3" class="text-center">Chưa có sản phẩm nào.</td>
                            </tr>
                            @endforelse
                        </tbody>
                    </table>
                </div>

                <!-- Đánh giá -->
                <div class="tab-pane fade" id="reviews" role="tabpanel">
                    <h5>Đánh giá của khách hàng</h5>
                    <ul class="list-group">
                        @forelse ($danhGias as $dg)
                        <li class="list-group-item">
                            <strong>{{ $dg->sanpham->tensp }}</strong> - ⭐{{ str_repeat('⭐', $dg->danhgia) }}<br>
                            {{ $dg->noidung }}
                            <div class="text-muted">Đánh giá ngày {{ $dg->created_at->format('d/m/Y') }}</div>
                        </li>
                        @empty
                        <li class="list-group-item text-center">Chưa có đánh giá nào.</li>
                        @endforelse
                    </ul>
                </div>

                <!-- Hành động -->
                <div class="tab-pane fade" id="actions" role="tabpanel">
                    <h5>Hành động quản trị</h5>

                    <form action="{{ route('khachhang.lock', $khachhang->id) }}" method="POST" class="d-inline">
                        @csrf
                        @if ($khachhang->trangthai == 1)
                        <button class="btn btn-warning me-2" type="submit">Khóa tài khoản</button>
                        @else
                        <button class="btn btn-success me-2" type="submit">Mở khóa tài khoản</button>
                        @endif
                    </form>


                    <hr>
                    <form action="" method="POST">
                        @csrf
                        <div class="mb-3">
                            <label for="note" class="form-label">Ghi chú nội bộ</label>
                            <textarea class="form-control" id="note" name="ghichu" rows="3" placeholder="VD: Khách hay hoàn đơn, cần kiểm tra kỹ...">{{ $khachhang->ghichu }}</textarea>
                        </div>
                        <button type="submit" class="btn btn-primary">Lưu ghi chú</button>
                    </form>

                </div>

            </div>
        </div>
    </div>
</div>

@endsection