@extends('admin.layout.layout')

@section('title', 'Sửa bài viết')

@section('content')
<div class="container mt-3 mb-3">
    <div class="row justify-content-center">
        <div class="col-lg-11">
            <!-- Header -->
            <div class="d-flex justify-content-between align-items-center mb-4">
                <h2 class="fw-bold text-primary">Sửa bài viết</h2>
                <a href="{{ route('baiviet') }}" class="btn btn-outline-secondary">
                    <i class="bi bi-arrow-left"></i> Quay lại
                </a>
            </div>

            <!-- Card chính -->
            <div class="card border-0 shadow-lg rounded-3">
                <div class="card-body p-4">
                    <form action="{{ route('baiviet.update', $baiViet->id) }}" method="POST" enctype="multipart/form-data">
                        @csrf
                        @method('PUT')

                        <!-- Tiêu đề -->
                        <div class="mb-3">
                            <label for="tieude" class="form-label fw-semibold">Tiêu đề</label>
                            <input type="text" name="tieude" id="tieude" class="form-control" value="{{ old('tieude', $baiViet->tieude) }}" required>
                            @error('tieude')
                                <span class="text-danger">{{ $message }}</span>
                            @enderror
                        </div>

                        <!-- Danh mục -->
                        <div class="mb-3">
                            <label for="id_danhmuc" class="form-label fw-semibold">Danh mục</label>
                            <select name="id_danhmuc" id="id_danhmuc" class="form-select" required>
                                <option value="">Chọn danh mục</option>
                                @foreach($danhMucs as $dm)
                                    <option value="{{ $dm->id }}" {{ old('id_danhmuc', $baiViet->id_danhmuc) == $dm->id ? 'selected' : '' }}>
                                        {{ $dm->tendm }}
                                    </option>
                                @endforeach
                            </select>
                            @error('id_danhmuc')
                                <span class="text-danger">{{ $message }}</span>
                            @enderror
                        </div>

                        <!-- Nội dung -->
                        <div class="mb-3">
                            <label for="noidung" class="form-label fw-semibold">Nội dung</label>
                            <textarea name="noidung" id="noidung" class="form-control" rows="5">{{ old('noidung', $baiViet->noidung) }}</textarea>
                            @error('noidung')
                                <span class="text-danger">{{ $message }}</span>
                            @enderror
                        </div>

                        <!-- Hình ảnh -->
                        <div class="mb-3">
                            <label for="hinh" class="form-label fw-semibold">Hình ảnh</label>
                            @if($baiViet->hinh)
                                <div class="mb-2">
                                <img src="{{ asset('uploads/baiviet/' . $baiViet->hinh) }}" alt="Hình ảnh bài viết" class="img-thumbnail" style="max-width: 150px;">

                                </div>
                            @endif
                            <input type="file" name="hinh" id="hinh" class="form-control">
                            @error('hinh')
                                <span class="text-danger">{{ $message }}</span>
                            @enderror
                        </div>

                        <!-- Ẩn/Hiện -->
                        <div class="mb-3">
                            <label class="form-label fw-semibold">Trạng thái</label>
                            <div class="form-check">
                                <input type="checkbox" name="anhien" id="anhien" class="form-check-input" value="1" {{ old('anhien', $baiViet->anhien) ? 'checked' : '' }}>
                                <label for="anhien" class="form-check-label">Hiển thị</label>
                            </div>
                        </div>

                        <!-- Nút submit -->
                        <button type="submit" class="btn btn-primary w-100">Cập nhật bài viết</button>
                    </form>
                </div>
            </div>
        </div>
    </div>
</div>

<style>
    .card {
        transition: transform 0.3s ease, box-shadow 0.3s ease;
    }
    .card:hover {
        transform: translateY(-5px);
        box-shadow: 0 10px 20px rgba(0, 0, 0, 0.1) !important;
    }
    .form-control:focus, .form-select:focus {
        border-color: #0d6efd;
        box-shadow: 0 0 5px rgba(13, 110, 253, 0.2);
    }
</style>
@endsection