@extends('admin.layout.layout')

@section('title', 'Thêm bài viết')

@section('content')

<div class="container-fluid mt-5">
    <form action="{{ route('baiviet.store') }}" method="POST" style="max-width: 98%; margin: auto;">
        @csrf
        <div class="row w-100">
            <div class="col-xl-8 col-lg-8 col-sm-12 col-12 m-auto">
                @if(Session::has('success'))
                <div class="alert alert-success alert-dismissible">
                    <button type="button" class="close" data-dismiss="alert">×</button>
                    {{ Session::get('success') }}
                </div>
                @elseif(Session::has('failed'))
                <div class="alert alert-danger alert-dismissible">
                    <button type="button" class="close" data-dismiss="alert">×</button>
                    {{ Session::get('failed') }}
                </div>
                @endif
                <div class="card shadow">
                    <div class="card-header d-flex justify-content-between align-items-center mb-4">
                        <h4 class="card-title fw-bold text-primary mb-0">Thêm bài viết</h4>
                        <a href="{{ route('baiviet') }}" class="btn btn-outline-secondary">
                            <i class="bi bi-arrow-left"></i> Quay lại
                        </a>
                    </div>
                    <div class="card-body">
                        <div class="form-group">
                            <label>Tiêu đề</label>
                            <input type="text" class="form-control" name="tieude" placeholder="Nhập tiêu đề" value="{{ old('tieude') }}">
                            @error('tieude')
                                <span class="text-danger">{{ $message }}</span>
                            @enderror
                        </div>
                        <div class="form-group">
                            <label>Nội dung</label>
                            <textarea class="form-control" id="noidung" placeholder="Nhập nội dung" name="noidung">{{ old('noidung') }}</textarea>
                            @error('noidung')
                                <span class="text-danger">{{ $message }}</span>
                            @enderror
                        </div>
                    </div>

                    <div class="card-body">
                        <!-- Ẩn/Hiện -->
                        <div class="mb-3">
                            <label class="form-label fw-semibold">Trạng thái</label>
                            <div class="form-check">
                                <input type="checkbox" name="anhien" id="anhien" class="form-check-input" value="1" {{ old('anhien', 1) ? 'checked' : '' }}>
                                <label for="anhien" class="form-check-label">Hiển thị</label>
                            </div>
                        </div>

                        <!-- Danh mục -->
                        <div class="mb-3">
                            <label for="id_danhmuc" class="form-label fw-semibold">Danh mục</label>
                            <select name="id_danhmuc" id="id_danhmuc" class="form-select" required>
                                <option value="">Chọn danh mục</option>
                                @foreach($danhMucs as $dm)
                                    <option value="{{ $dm->id }}" {{ old('id_danhmuc') == $dm->id ? 'selected' : '' }}>
                                        {{ $dm->tendm }}
                                    </option>
                                @endforeach
                            </select>
                            @error('id_danhmuc')
                                <span class="text-danger">{{ $message }}</span>
                            @enderror
                        </div>
                    </div>

                    <div class="card-footer">
                        <button type="submit" class="btn btn-success">Lưu</button>
                    </div>
                </div>
            </div>
        </div>
    </form>
</div>

<!-- CKEditor CDN -->
<script src="https://cdn.ckeditor.com/ckeditor5/41.3.1/classic/ckeditor.js"></script>
<!-- Thêm các plugin cần thiết -->
<script src="https://cdn.ckeditor.com/ckeditor5/41.3.1/classic/translations/vi.js"></script>
<script>
    ClassicEditor
        .create(document.querySelector('#noidung'), {
            language: 'vi', // Ngôn ngữ tiếng Việt
            extraPlugins: [MyUploadAdapterPlugin],
            toolbar: {
                items: [
                    'heading', '|',
                    'fontFamily', 'fontSize', 'fontColor', 'fontBackgroundColor', '|',
                    'bold', 'italic', 'underline', 'strikethrough', 'highlight', '|',
                    'alignment', '|',
                    'bulletedList', 'numberedList', 'outdent', 'indent', '|',
                    'link', 'imageUpload', 'imageStyle:alignLeft', 'imageStyle:alignCenter', 'imageStyle:alignRight', 'blockQuote', 'insertTable', 'mediaEmbed', '|',
                    'undo', 'redo'
                ]
            },
            image: {
                toolbar: [
                    'imageTextAlternative', 'toggleImageCaption', '|',
                    'imageStyle:alignLeft', 'imageStyle:alignCenter', 'imageStyle:alignRight'
                ],
                styles: [
                    'alignLeft', 'alignCenter', 'alignRight'
                ],
                resizeOptions: [
                    {
                        name: 'resizeImage:original',
                        value: null,
                        label: 'Kích thước gốc'
                    },
                    {
                        name: 'resizeImage:50',
                        value: '50',
                        label: '50%'
                    },
                    {
                        name: 'resizeImage:75',
                        value: '75',
                        label: '75%'
                    }
                ]
            },
            fontFamily: {
                options: [
                    'default',
                    'Arial, Helvetica, sans-serif',
                    'Courier New, Courier, monospace',
                    'Georgia, serif',
                    'Times New Roman, Times, serif',
                    'Verdana, Geneva, sans-serif'
                ]
            },
            fontSize: {
                options: [9, 11, 13, 'default', 17, 19, 21]
            }
        })
        .then(editor => {
            console.log('Editor đã khởi tạo');
        })
        .catch(error => {
            console.error(error);
        });

    function MyUploadAdapterPlugin(editor) {
        editor.plugins.get('FileRepository').createUploadAdapter = (loader) => {
            return new MyUploadAdapter(loader);
        };
    }

    class MyUploadAdapter {
        constructor(loader) {
            this.loader = loader;
        }

        upload() {
            return this.loader.file.then(file => {
                return new Promise((resolve, reject) => {
                    const data = new FormData();
                    data.append('upload', file);

                    fetch('{{ route('upload.image') }}', {
                        method: 'POST',
                        body: data,
                        headers: {
                            'Accept': 'application/json'
                        }
                    })
                    .then(response => {
                        if (!response.ok) {
                            throw new Error(`HTTP error! status: ${response.status}`);
                        }
                        return response.json();
                    })
                    .then(result => {
                        if (result.url) {
                            resolve({ default: result.url });
                        } else {
                            reject(result.error ? result.error.message : 'Lỗi không xác định');
                        }
                    })
                    .catch(error => {
                        console.error('Upload error:', error);
                        reject(error.message);
                    });
                });
            });
        }

        abort() {
            // Xử lý hủy upload nếu cần
        }
    }
</script>

<script src="https://ajax.googleapis.com/ajax/libs/jquery/3.6.4/jquery.min.js"></script>
<script src="https://cdn.jsdelivr.net/npm/bootstrap@5.2.3/dist/js/bootstrap.bundle.min.js"></script>
@endsection