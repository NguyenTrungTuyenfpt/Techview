@extends('admin.layout.layout')

@section('title', 'Banner')

@section('content')

<!-- Nội dung chính của trang sẽ nằm ở đây -->
<div class="container">
    <div class="category-list mt-4 d-flex justify-content-between align-items-center">
        <h4 class="fw-bold">DANH SÁCH BANNER</h4>
        <a href="{{ route('banner.create') }}"><button class="btn btn-primary"><i class="bi bi-plus-lg"></i> Thêm sản banner</button></a>
    </div>
    <div class="table-responsive border-1">
        <table class="table table-hover align-middle">
            <thead class="table-primary">
                <tr>
                    <th>ID</th>
                    <th>Tên </th>
                    <th>Hình </th>
                    <th>Mô tả </th>
                    <th>Link </th>
                    <th>Vị trí</th>
                    <th>Ẩn/hiện</th>
                    <th>Thứ tự</th>
                    <th>Thao tác</th>
                </tr>
            </thead>
            <tbody>

                @foreach($banners as $bn)

                <tr>
                    <td>{{ $bn->id }}</td>
                    <td>
                        <a class="text-dark text-decoration-none" href="">
                            {{ $bn->ten }}
                        </a>
                    </td>

                 
                    <td style="width: 15%">
                    <img src="{{ asset('uploads/banner/' . $bn->hinh) }}" class="img-thumbnail" style="width: 100%;">
                    </td>
                    <td>{{ $bn->mota }}</td>
                    <td>{{ $bn->link }}</td>
                    <td>{{ $bn->vitri}}</td>
                 
                    <td>
                        <span class="badge {{ $bn->anhien == 1 ? 'bg-success bg-opacity-10 text-success' : 'bg-danger bg-opacity-10 text-danger' }} p-2">
                            {{ $bn->anhien == 1? 'Hiện' : 'Ẩn' }}
                        </span>
                    </td>

                    <td>{{ $bn->thutu}}</td>

            
                    <td>
                        <div class="d-flex align-items-center gap-2">
                            <a href="{{ route('banner.edit', $bn->id) }}">
                                <span class="badge bg-success bg-opacity-10 text-success p-2">
                                    <i class="bi bi-pencil"></i> Sửa
                                </span>
                            </a>

                            <form action="{{ route('banner.destroy', $bn->id) }}" method="POST" onsubmit="return confirm('Bạn có chắc muốn xoá?')">
                                @csrf
                                @method('DELETE')
                                <button type="submit" class="badge bg-danger bg-opacity-10 text-danger p-2 border-0"> <i class="bi bi-trash3"></i>Xoá</button>
                            </form>
                        </div>

                    </td>
                </tr>
                @endforeach


            </tbody>
        </table>
    </div>
</div>
<!-- <nav aria-label="Page navigation example">
    <ul class="pagination justify-content-end">
        <li class="page-item disabled">
            <a class="page-link">Previous</a>
        </li>
        <li class="page-item"><a class="page-link" href="#">1</a></li>
        <li class="page-item"><a class="page-link" href="#">2</a></li>
        <li class="page-item"><a class="page-link" href="#">3</a></li>
        <li class="page-item">
            <a class="page-link" href="#">Next</a>
        </li>
    </ul>
</nav> -->

<!-- Phân trang động với Bootstrap 5 -->
<div class="d-flex justify-content-end mt-3">
        {{ $banners->links('pagination::bootstrap-5') }}
    </div>
</div>

</div>

@endsection