@extends('admin.layout.layout')

@section('title', 'Chi tiết đơn hàng')

@section('content')
<div class="container">
    <h4 class="fw-bold mt-4">Chi tiết đơn hàng #{{ $donhang->madonhang }}</h4>

    <div class="border rounded p-3 shadow-sm bg-light">
        <h5 class="fw-bold">Thông tin đơn hàng</h5>
        <p><strong>Người nhận:</strong> {{ $donhang->tennguoinhan }}</p>
        <p><strong>Số điện thoại:</strong> {{ $donhang->sodienthoai }}</p>
        <p><strong>Địa chỉ:</strong> {{ $donhang->diachi }}</p>
        <p><strong>Tổng tiền:</strong> {{ number_format($donhang->tongtien, 0, ',', '.') }} VNĐ</p>
        <p><strong>Trạng thái:</strong> {{ $donhang->trangthai }}</p>
        <p><strong>Trạng thái thanh toán:</strong> {{ $donhang->trangthaithanhtoan }}</p>
        <p><strong>Ngày tạo:</strong> {{ date('d/m/Y H:i', strtotime($donhang->ngaytao)) }}</p>
    </div>

    <div class="border rounded p-3 shadow-sm bg-light mt-3">
        <h5 class="fw-bold">Danh sách sản phẩm trong đơn hàng này</h5>
        <table class="table">
            <thead>
                <tr>
                    <th>#</th>
                    <th>Sản phẩm</th>
                    <th>Giá</th>
                    <th>Số lượng</th>
                    <th>Thành tiền</th>
                </tr>
            </thead>
            <tbody>
                @foreach ($donhang->chitietdonhang as $index => $chitiet)
                <tr>
                    <td>{{ $index + 1 }}</td>
                    <td>{{ $chitiet->sanpham->tensp ?? 'Sản phẩm đã bị xóa' }}</td>
                    <td>{{ number_format($chitiet->gia, 0, ',', '.') }} VNĐ</td>
                    <td>{{ $chitiet->soluong }}</td>
                    <td>{{ number_format($chitiet->gia * $chitiet->soluong, 0, ',', '.') }} VNĐ</td>
                </tr>
                @endforeach
            </tbody>
        </table>
    </div>

    <div class="d-flex justify-content-end mt-3">
        <a href="{{ route('donhang') }}" class="btn btn-secondary">Quay lại</a>
    </div>
</div>
@endsection
