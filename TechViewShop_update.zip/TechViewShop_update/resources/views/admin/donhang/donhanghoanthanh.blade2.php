<!DOCTYPE html>
<html lang="vi">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Thông báo đơn hàng hoàn thành</title>
</head>
<body>
    <p>Xin chào {{ $tennguoinhan }},</p>
    <p>Đơn hàng <strong>{{ $madonhang }}</strong> của bạn đã được giao thành công ngày <strong>{{ date('d/m/Y', strtotime($ngaytao)) }}</strong>.</p>
    <p>Vui lòng đăng nhập TechView để xác nhận bạn đã nhận hàng và hài lòng với sản phẩm. Sau khi bạn xác nhận, rất mong bạn để lại đanh đánh giá cho dịch vụ và sản phẩm của chúng tôi.</p>
    <p>Đã nhận hàng</p>

    <h3>THÔNG TIN ĐƠN HÀNG - DÀNH CHO NGƯỜI MUA</h3>
    <ul>
        <li><strong>Mã đơn hàng:</strong> {{ $madonhang }}</li>
        <li><strong>Ngày đặt hàng:</strong> {{ date('d/m/Y H:i:s', strtotime($ngaytao)) }}</li>
        <li><strong>Người bán:</strong> snailey</li>
    </ul>

    <h3>Sản phẩm</h3>
    <ul>
        @foreach ($chitietdonhang as $chitiet)
            <li>{{ $chitiet->sanpham->ten }} | Số lượng: {{ $chitiet->soluong }} | Giá: ₫{{ number_format($chitiet->gia, 0, ',', '.') }}</li>
        @endforeach
    </ul>

    <p><strong>Tổng tiền:</strong> {{ $tongtien }}</p>
    <p><strong>Mã giảm giá của Shop:</strong> SNAI2K</p>
    <p><strong>Phí vận chuyển:</strong> ₫0</p>
    <p><strong>Tổng thanh toán:</strong> ₫131,560</p>

    <h3>BƯỚC TIẾP THEO</h3>
    <p>Bạn không hài lòng về sản phẩm? Bạn có thể gửi yêu cầu trả hàng trên trang website của chúng tôi.</p>
    

    <p>Trân trọng,</p>
    <p>Đội ngũ TechView</p>
</body>
</html>



