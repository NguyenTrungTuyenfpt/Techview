@extends('admin.layout.layout')

@section('title', 'Nha cung cap')

@section('content')

            <!-- Nội dung chính của trang sẽ nằm ở đây -->
            <div class="container">
                <div class="category-list mt-4 d-flex justify-content-between align-items-center">
                    <h4 class="fw-bold">DANH SÁCH NHÀ CUNG CẤP</h4>
                    <a href="{{route('nhacungcap.create')}}"><button class="btn btn-primary"><i class="bi bi-plus-lg"></i> Thêm nhà cung cấp</button></a>
                </div>
                <div class="table-responsive border-1">
                    <table class="table table-hover align-middle">
                        <thead class="table-primary">
                            <tr>
                                <th>ID</th>
                                <th>Tên nhà cung câp</th>
                                <th>Email</th>
                                <th>SDT</th>
                                <th>Địa chỉ</th>
                                <!-- <th>Tình trạng</th> -->
                                <th>Mô tả</th>
                                <th>Thao tác</th>
                            </tr>
                        </thead>
                        <tbody>

                        @foreach($nhacungcap as $nhacungcap)   
                    
                        <tr>
                            <td>{{ $nhacungcap->id }}</td>
                            <td>{{ $nhacungcap->tenncc }}</td>
                            <td>{{ $nhacungcap->email }}</td>
                            <td>{{ $nhacungcap->sodienthoai }}</td>
                            <td>{{ $nhacungcap->diachi }}</td>
                            <td>{{ $nhacungcap->mota }}</td>
                         
                           
                            <td><a href="{{ route('nhacungcap.edit', $nhacungcap->id) }}"><span class="badge bg-success bg-opacity-10 text-success p-2"><i class="bi bi-pencil"></i> Cập nhật</span></a> - <a href="#"><span class="badge bg-danger bg-opacity-10 text-danger p-2"><i class="bi bi-trash3"></i> Xoá</span></a></td>
                        </tr>
                        @endforeach
                    
                           
                        </tbody>
                    </table>
                </div>
            </div>
            <nav aria-label="Page navigation example">
                <ul class="pagination justify-content-end">
                  <li class="page-item disabled">
                    <a class="page-link">Previous</a>
                  </li>
                  <li class="page-item"><a class="page-link" href="#">1</a></li>
                  <li class="page-item"><a class="page-link" href="#">2</a></li>
                  <li class="page-item"><a class="page-link" href="#">3</a></li>
                  <li class="page-item">
                    <a class="page-link" href="#">Next</a>
                  </li>
                </ul>
              </nav>
        </div>
        
    </div>

   @endsection