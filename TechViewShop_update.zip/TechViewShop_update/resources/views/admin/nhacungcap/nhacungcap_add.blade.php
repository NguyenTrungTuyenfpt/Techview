@extends('admin.layout.layout')

@section('title', 'Thêm nhà cung cấp')

@section('content')
<!-- Nội dung chính của trang sẽ nằm ở đây -->

<form action="{{ route('nhacungcap.store') }}" method="POST" enctype="multipart/form-data">
    @csrf


    @if ($errors->any())
    <div class="alert alert-danger">
        <ul class="mb-0">
            @foreach ($errors->all() as $error)
            <li>{{ $error }}</li>
            @endforeach
        </ul>
    </div>
    @endif

    <div class="container">
        <h4 class="fw-bold mt-4">Thêm nhà cung cấp </h4>
        <p><a href="/">Trang chủ</a> / <span class="text-primary">Thêm nhà cung cấp </span></p>
        <div class="add-product">
            <div class="row">
                <!-- Thông tin sản phẩm -->
                <div class="col-md-12">
                    <div class="border rounded p-3">
                        <h5 class="fw-bold">Thông tin </h5>
                        <div class="row">
                            <div class="col-md-4 mt-3">
                                <label class="form-label">Tên nhà cung cấp </label>
                                <input type="text" name="tenncc" class="form-control" placeholder="Nhập tại đây" required>
                            </div>
                            <div class="col-md-4 mt-3">
                                <label class="form-label">Email</label>
                                <input type="email" name="email" class="form-control" placeholder="Nhập tại đây">
                            </div>
                            <div class="col-md-4 mt-3">
                                <label class="form-label">Số điện thoại</label>
                                <input type="text" name="sodienthoai" class="form-control" placeholder="Nhập tại đây">
                            </div>

                            <div class="col-md-4 mt-3">
                                <label class="form-label">Địa chỉ</label>
                                <input type="text" name="diachi" class="form-control" placeholder="Nhập tại đây">
                            </div>

                            <div class="col-md-4 mt-3">
                                <label class="form-label">Mô tả</label>
                                <input type="text" name="mota" class="form-control" placeholder="Nhập tại đây">
                            </div>

                            <div class="col-md-4 mt-3">
                                <label class="form-label">Thứ tự</label>
                                <input type="number" name="thutu" class="form-control" placeholder="Nhập tại đây">
                            </div>
                            

                            <div class="col-md-4 mt-3">
                                <label class="form-label">Trạng thái hiển thị</label>
                                <div class="form-check">
                                    <input class="form-check-input" type="radio" name="anhien" id="hien" value="1" checked>
                                    <label class="form-check-label" for="hien">Hiển thị</label>
                                </div>
                                <div class="form-check">
                                    <input class="form-check-input" type="radio" name="anhien" id="an" value="0">
                                    <label class="form-check-label" for="an">Ẩn</label>
                                </div>
                            </div>

                            <div class="border rounded p-4 text-center mt-2">
                                <i class="bi bi-image" style="font-size: 60px; color: #ccc;"></i>
                                <p class="text-muted">Ảnh </p>
                                <input type="file" name="hinh" class="form-control mt-2">
                            </div>

                            @if ($errors->has('hinh'))
                            <div class="alert alert-danger mt-2">
                                {{ $errors->first('hinh') }}
                            </div>
                            @endif

                        </div>
                    </div>
                </div>



            </div>

            <!-- Buttons -->
            <div class="d-flex justify-content-end mt-2">
                <button class="btn btn-primary me-2">Thêm</button>
                <button class="btn btn-danger">Hủy</button>
            </div>
        </div>
    </div>

</form>

</div>
</div>


<script>
    const fileInput = document.querySelector('input[name="hinh"]');
    fileInput.addEventListener('change', function (e) {
        const previewContainer = document.querySelector('.border.rounded.p-4.text-center.mt-2');
        const files = e.target.files;
        previewContainer.innerHTML = ''; // Clear any previous image preview

        for (let i = 0; i < files.length; i++) {
            const reader = new FileReader();
            reader.onload = function (e) {
                const img = document.createElement('img');
                img.src = e.target.result;
                img.classList.add('img-thumbnail', 'mt-2');
                previewContainer.appendChild(img);
            };
            reader.readAsDataURL(files[i]);
        }
    });
</script>


@if(session('popup'))
    <script>
        document.addEventListener("DOMContentLoaded", function() {
            // Hiển thị hộp thoại confirm
            Swal.fire({
                icon: "{{ session('status', 'info') }}", // Loại thông báo
                title: '',  // Tiêu đề có thể để trống hoặc chỉnh lại
                text: "{{ session('message') }}",  // Nội dung thông báo
                showCancelButton: false, // Ẩn nút Cancel (nếu bạn chỉ muốn "OK")
                confirmButtonText: 'OK', // Nút xác nhận "OK"
            }).then((result) => {
                // Chỉ khi người dùng nhấn OK mới chuyển trang
                if (result.isConfirmed) {
                    window.location.href = "{{ session('route') }}"; // Chuyển hướng
                }
            });
        });
    </script>
@endif
@endsection