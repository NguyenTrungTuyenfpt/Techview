@extends('admin.layout.layout')

@section('title', 'Home page')

@section('content')
<div class="container">
    <div class="card-info mt-4">
        <div class="row">
            <!-- Card 1 -->
            <div class="col-md-3">
                <div class="card shadow-sm p-3 text-center">
                    <div class="icon bg-light-green">
                        <i class="bi bi-cash-coin"></i>
                    </div>
                    <p class="text-muted">Doanh thu</p>
                    <h4>654.120.121đ</h4>
                    <p class="text-success"><i class="bi bi-arrow-up"></i> +16%</p>
                    <a href="#" class="details">Xem chi tiết</a>
                </div>
            </div>

            <!-- Card 2 -->
            <div class="col-md-3">
                <div class="card shadow-sm p-3 text-center">
                    <div class="icon bg-light-red">
                        <i class="bi bi-check"></i>
                    </div>
                    <p class="text-muted">Tổng đơn hàng</p>
                    <h4>129</h4>
                    <p class="text-danger"><i class="bi bi-arrow-down"></i> +80%</p>
                    <a href="#" class="details">Xem chi tiết</a>
                </div>
            </div>

            <!-- Card 3 -->
            <div class="col-md-3">
                <div class="card shadow-sm p-3 text-center">
                    <div class="icon bg-light-blue">
                        <i class="bi bi-people"></i>
                    </div>
                    <p class="text-muted">Lượt xem website</p>
                    <h4>987M</h4>
                    <p class="text-primary"><i class="bi bi-arrow-up"></i> +80%</p>
                    <a href="#" class="details">Xem chi tiết</a>
                </div>
            </div>

            <!-- Card 4 -->
            <div class="col-md-3">
                <div class="card shadow-sm p-3 text-center">
                    <div class="icon bg-light-yellow">
                        <i class="bi bi-people"></i>
                    </div>
                    <p class="text-muted">Tổng khách hàng</p>
                    <h4>808</h4>
                    <p class="text-warning"><i class="bi bi-arrow-up"></i> +13%</p>
                    <a href="#" class="details">Xem chi tiết</a>
                </div>
            </div>
        </div>
    </div>
    <div class="oder-list mt-4">
        <h4 class="fw-bold">Đơn hàng mới cần xử lý</h4>
        <div class="table-responsive border-1">
        <table class="table">
            @forelse ($donhangs as $index => $donhang)
            <thead>
                <tr>
                    <th>#</th>
                    <th>Mã đơn hàng</th>
                    <th>Người nhận</th>
                    <th>SĐT</th>
                    <th>Tổng tiền</th>
                    <th>Trạng thái</th>
                    <th>Ngày tạo</th>
                    <th>Thao tác</th>
                </tr>
            </thead>
            <tbody>
        <tr>
            <td>{{ $index + 1 }}</td>
            <td>{{ $donhang->madonhang }}</td>
            <td>{{ $donhang->tennguoinhan }}</td>
            <td>{{ $donhang->sodienthoai }}</td>
            <td>{{ number_format($donhang->tongtien, 0, ',', '.') }} VNĐ</td>
            <td>
                @if ($donhang->trangthai == 'pending')
                <span class="badge bg-warning">Chờ xử lý</span>
                @elseif ($donhang->trangthai == 'completed')
                <span class="badge bg-success">Hoàn thành</span>
                @elseif ($donhang->trangthai == 'canceled')
                <span class="badge bg-danger">Đã hủy</span>
                @else
                <span class="badge bg-secondary">{{ $donhang->trangthai }}</span>
                @endif
            </td>
            <td>{{ date('d/m/Y H:i', strtotime($donhang->ngaytao)) }}</td>
            <td>
                <a href="{{ route('donhang.show', $donhang->id) }}" class="btn btn-info btn-sm">Chi tiết</a>
                <a href="{{ route('donhang.update', $donhang->id) }}" class="btn btn-primary btn-sm">Cập nhật</a>
                <form action="" method="POST" style="display:inline;">
                    @csrf
                    @method('DELETE')
                    <button type="submit" class="btn btn-danger btn-sm" onclick="return confirm('Bạn có chắc muốn xóa đơn hàng này?')">Hủy</button>
                </form>
            </td>
        </tr>
        @empty
        <tr>
            <td colspan="8" class="text-center">Không có đơn hàng mới nào!</td>
        </tr>
        @endforelse
            </tbody>
        </table>
        </div>
    </div>
    <div class="best-seller mt-4">
        <h4 class="fw-bold">Sản phẩm bán chạy</h4>
        <div class="row">
            <div class="col-md-3">
                <div class="product-card">
                    <img src="{{ asset('img/product-1.png')}}" class="product-img img-fluid" alt="Sản phẩm">
                    <div class="product-name">Kính thiên văn Skywatcher</div>
                    <div class="product-price">31.000.000 đ</div>
                </div>
            </div>
            <div class="col-md-3">
                <div class="product-card">
                    <img src="{{ asset('img/product-2.png')}}" class="product-img img-fluid" alt="Sản phẩm">
                    <div class="product-name">Kính thiên văn Meade</div>
                    <div class="product-price">1.500.000 đ</div>
                </div>
            </div>
            <div class="col-md-3">
                <div class="product-card">
                    <img src="{{ asset('img/product-3.png')}}" class="product-img img-fluid" alt="Sản phẩm">
                    <div class="product-name">Kính thiên văn Polaris</div>
                    <div class="product-price">8.000.000 đ</div>
                </div>
            </div>
            <div class="col-md-3">
                <div class="product-card">
                    <img src="{{ asset('img/product-4.png')}}" class="product-img img-fluid" alt="Sản phẩm">
                    <div class="product-name">Ống nhòm Apollo 10x50</div>
                    <div class="product-price">2.850.000 đ</div>
                </div>
            </div>
        </div>
    </div>
</div>
<!-- copy 2 div dưới vào content -->
</div>

</div>

@endsection