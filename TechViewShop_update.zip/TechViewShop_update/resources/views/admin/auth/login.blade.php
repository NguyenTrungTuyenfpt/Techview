<!DOCTYPE html>
<html lang="vi">

<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Đăng nhập</title>
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.3/dist/css/bootstrap.min.css" rel="stylesheet">
    <script src="https://cdn.jsdelivr.net/npm/sweetalert2@11"></script>
    <style>
        /* CSS tùy chỉnh */
        body {
            background-color: #f8f9fa;
            height: 100vh;
            display: flex;
            align-items: center;
            justify-content: center;
        }

        .container {
            max-width: 400px; /* Giới hạn chiều rộng form */
            background: #ffffff;
            padding: 2rem;
            border-radius: 10px;
            box-shadow: 0 4px 8px rgba(0, 0, 0, 0.1);
        }

        h2 {
            font-weight: 600;
            color: #343a40;
        }

        .form-control {
            border-radius: 8px;
            padding: 10px;
            border: 1px solid #ced4da;
            transition: border-color 0.3s ease;
        }

        .form-control:focus {
            border-color: #0d6efd;
            box-shadow: 0 0 5px rgba(13, 110, 253, 0.25);
        }

        .btn-primary {
            border-radius: 8px;
            padding: 12px;
            font-weight: 500;
            background-color: #0d6efd;
            border: none;
            transition: background-color 0.3s ease;
        }

        .btn-primary:hover {
            background-color: #0056b3;
        }

        .form-check-label {
            font-size: 0.9rem;
            color: #6c757d;
        }

        .forget-password {
            float: right;
            font-size: 0.9rem;
            color: #0d6efd;
            text-decoration: none;
        }

        .forget-password:hover {
            text-decoration: underline;
            color: #0056b3;
        }

        .alert-danger {
            border-radius: 8px;
            font-size: 0.9rem;
        }

        p a {
            color: #0d6efd;
            text-decoration: none;
            font-weight: 500;
        }

        p a:hover {
            text-decoration: underline;
            color: #0056b3;
        }
    </style>
</head>

<body>
    <div class="container mt-5">
        @if ($errors->any())
        <div class="alert alert-danger">
            <ul class="mb-0">
                @foreach ($errors->all() as $error)
                <li>{{ $error }}</li>
                @endforeach
            </ul>
        </div>
        @endif

        <h2 class="mb-4 text-center">Đăng nhập Admin</h2>
        <form action="{{ route('auth.plogin') }}" method="POST">
            @csrf

            <div class="mb-3">
                <label for="email" class="form-label">Email</label>
                <input type="email" name="email" id="email" class="form-control" required>
            </div>

            <div class="mb-3">
                <label for="matkhau" class="form-label">Mật khẩu</label>
                <input type="password" name="password" id="matkhau" class="form-control" required>
            </div>

            <div class="mb-3">
                <div class="form-check">
                    <input type="checkbox" id="remember-check" name="remember" class="form-check-input">
                    <label class="form-check-label" for="remember-check">Lưu mật khẩu</label>
                </div>
                <a href="#" class="forget-password">Quên mật khẩu?</a>
            </div>

            <button type="submit" class="btn btn-primary w-100">Đăng nhập</button>
            <p class="mt-3 text-center">Chưa có tài khoản? <a href="{{route('auth.register')}}">Đăng ký</a></p>
        </form>
    </div>

    @if(session('message'))
    <script>
        let status = "{{ session('status', 'warning') }}"; 
        let message = "{{ session('message') }}";

        Swal.fire({
            icon: status, 
            title: 'Thông báo',
            text: message,
            confirmButtonText: 'OK'
        });
    </script>
    @endif
</body>

</html>