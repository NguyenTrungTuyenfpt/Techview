<!DOCTYPE html>
<html lang="vi">

<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Đăng ký</title>
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.3/dist/css/bootstrap.min.css" rel="stylesheet">
</head>

<body>


        @if ($errors->any())
        <div class="alert alert-danger">
            <ul class="mb-0">
                @foreach ($errors->all() as $error)
                <li>{{ $error }}</li>
                @endforeach
            </ul>
        </div>
        @endif

        


        <!-- Begin page -->
        <div class="account-page bg-primary-subtle">
            <div class="container-fluid p-0">
                <div class="row align-items-center g-0">

                    <div class="col-xl-5">
                        <div class="row">
                            <div class="col-md-8 mx-auto">
                                <div class="card p-3">
                                    <div class="card-body">

                                        <div class="mb-0 border-0 p-md-5 p-lg-0 p-4">
                                            <!-- <div class="mb-4 p-0 text-center">
                                                <a class='auth-logo' href='index.html'>
                                                    <img src="{{ asset('img/logo.png') }}" alt="logo-dark" class="mx-auto" width="100%"/>
                                                </a>
                                            </div> -->

                                            <div class="auth-title-section mb-3 text-center">
                                                <h3 class="text-dark fs-20 fw-medium mb-2">Chào mừng</h3>
                                                <p class="text-dark text-capitalize fs-14 mb-0">Đăng ký thành viên</p>
                                            </div>

                                            <div class="row">

                                                <a class="btn text-dark border fw-normal d-flex align-items-center justify-content-center">
                                                    <svg xmlns="http://www.w3.org/2000/svg" width="24" height="24" viewBox="0 0 48 48" class="me-2">
                                                        <path fill="#ffc107" d="M43.611 20.083H42V20H24v8h11.303c-1.649 4.657-6.08 8-11.303 8c-6.627 0-12-5.373-12-12s5.373-12 12-12c3.059 0 5.842 1.154 7.961 3.039l5.657-5.657C34.046 6.053 29.268 4 24 4C12.955 4 4 12.955 4 24s8.955 20 20 20s20-8.955 20-20c0-1.341-.138-2.65-.389-3.917" />
                                                        <path fill="#ff3d00" d="m6.306 14.691l6.571 4.819C14.655 15.108 18.961 12 24 12c3.059 0 5.842 1.154 7.961 3.039l5.657-5.657C34.046 6.053 29.268 4 24 4C16.318 4 9.656 8.337 6.306 14.691" />
                                                        <path fill="#4caf50" d="M24 44c5.166 0 9.86-1.977 13.409-5.192l-6.19-5.238A11.91 11.91 0 0 1 24 36c-5.202 0-9.619-3.317-11.283-7.946l-6.522 5.025C9.505 39.556 16.227 44 24 44" />
                                                        <path fill="#1976d2" d="M43.611 20.083H42V20H24v8h11.303a12.04 12.04 0 0 1-4.087 5.571l.003-.002l6.19 5.238C36.971 39.205 44 34 44 24c0-1.341-.138-2.65-.389-3.917" />
                                                    </svg>
                                                    <span>Google</span>
                                                </a>



                                            </div>

                                            <div class="row justify-center items-center">
                                                <span class="text-center">--- Tiếp tục với email ---</span>
                                            </div>


                                            <div class="pt-0">
                                                <form action="{{route('auth.pregister')}}" method="POST" class="my-4">
                                                @csrf 
                                                    <div class="form-group mb-3">
                                                        <label for="username" class="form-label">Họ và tên</label>
                                                        <input class="form-control" name="name" type="text" id="username" required="" placeholder="Tên của bạn">
                                                    </div>

                                                    <div class="form-group mb-3">
                                                        <label for="emailaddress" class="form-label">Email </label>
                                                        <input class="form-control" name="email" type="email" id="emailaddress" required="" placeholder="NHập email ">
                                                    </div>

                                                    <div class="form-group mb-3">
                                                        <label for="password" class="form-label">Mật khẩu</label>
                                                        <input class="form-control" name="password" type="password" required="" id="password" placeholder="Nhập mật khẩu ">
                                                    </div>

                                                    <div class="form-group mb-3">
                                                        <label for="password" class="form-label">Nhập lại mật khẩu</label>
                                                        <input class="form-control" name="confirm_password" type="password" required="" id="password" placeholder="Nhập lại mật khẩu ">
                                                    </div>

                                                   

                                                    <div class="form-group mb-0 row">
                                                        <div class="col-12">
                                                            <div class="d-grid">
                                                                <button class="btn btn-primary" type="submit"> Đăng ký</button>
                                                            </div>
                                                        </div>
                                                    </div>
                                                </form>

                                                <div class="text-center text-muted mb-4">
                                                    <p class="mb-0">Đã có tài khoản ?<a class='text-primary ms-2 fw-medium' href="{{route('auth.login')}}">Đăng nhập</a></p>
                                                </div>

                                            </div>
                                        </div>
                                    </div>
                                </div>

                            </div>
                        </div>
                    </div>

                    <div class="col-xl-7">
                        <div class="account-page-bg p-md-5 p-4">
                            <div class="text-center">
                                <div class="auth-image">
                                    <img src="{{ asset('img/auth-images.svg') }}" class="mx-auto img-fluid" alt="images">
                                </div>
                            </div>
                        </div>
                    </div>

                </div>
            </div>
        </div>
        <!-- END wrapper -->
</body>

</html>



