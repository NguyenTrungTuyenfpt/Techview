@extends('client.layout.layout')
@section('title')
    Trang thanh toán
@endsection

@section('body')
    <form action="" class="checkout" id="checkoutForm" method="POST">  
        @csrf 
        <div class="gird">
            <div class="row">
                <div class="col l-8 m-7 c-12">
                    <h2 class="checkout-title">Thông tin nhận hàng</h2>
                    <div class="checkout-form ">
                        <div class="address-item address-item-gap">
                            <label class="payment-lable" for="name" class="">Họ và tên<span class="required"></span>:</label>
                            <input type="text" class="input-address" name="name" id="name" value="{{ $user->hoten }}">
                        </div>
                        @if ($errors->has('name'))
                            <div class="message">
                                {{ $errors->first('name') }}
                            </div>
                        @endif
                        <div class="address-item address-item-gap">
                            <label class="payment-lable" for="phone">Số điện thoại<span class="required"></span>:</label>
                            <input type="text" class="input-address" name="phone" id="phone" value="{{ $user->sodienthoai ?? "" }}">
                        </div>
                        @if ($errors->has('phone'))
                            <div class="message">
                                {{ $errors->first('phone') }}
                            </div>
                        @endif
                        <div class="address-item">
                            <label class="payment-lable" for="address">Địa chỉ<span class="required"></span>:</label>
                            <input type="text" class="input-address" name="address" id=""  value="{{ $user->diachi ?? "" }}">
                        </div>
                        @if ($errors->has('address'))
                            <div class="message">
                                {{ $errors->first('address') }}
                            </div>
                        @endif
                        <div class="address-item">
                            <label class="payment-lable" for="description">Ghi chú:</label>
                            <textarea rows="4" class="textarea-lable" id="description" name="description" value="{{ old('description') }}"></textarea>
                        </div>
                    </div>
                    
                </div>
                <div class="col l-4 m-5 c-12">
                    <div class="chechout-totals">
                        <h2 class="checkout-title">Đơn hàng của bạn</h2>
                        <table class="table-checkout">
                            <thead>
                                <tr class="table-th">
                                    <th>Sản phẩm</th>
                                    <th>Tổng cộng</th>
                                </tr>
                            </thead>
                            <tbody>
                                @foreach ($cartList as $cart)
                                    <tr>
                                        <td class="table-name"> {{ $cart->product->tensp }} <span class="payment-bold">x{{ $cart->soluong}}</span></td>
                                        <td class="table-name"> {{ number_format($cart->product->gia * (1 - ($cart->product->giamgia/100)) * $cart->soluong) }}₫</td>
                                    </tr>
                                @endforeach
                            </tbody>
                            <tfoot>
                                <tr> 
                                    <th class="table-th">Tạm tính</th>
                                    <td>{{ number_format($total) }}₫</td>
                                </tr>
                                <tr>
                                    <th class="table-th">Phí vận chuyển</th>
                                    <td>30,000₫</td>
                                </tr>
                                <tr>
                                    <td colspan="2">
                                        <div class="coupont-group">
                                            <input type="text" class="input-coupon" name="coupon_code" placeholder="Nhập mã giảm giá">
                                            <button class="btn-apply">Áp dụng</button>
                                        </div>
                                        @if (session('error'))
                                            <div class="message"> {{ session('error') }} </div>
                                        @endif
                                        @if (session('success'))
                                            <div class="success"> {{ session('success') }} </div>
                                        @endif
                                    </td>
                                </tr>
                                <tr>
                                    <th class="table-th">Giảm giá</th>
                                    @if ($discount > 0)
                                        <td>{{ number_format($discountAmount) }}₫</td>
                                    @else 
                                        <td>0</td>
                                    @endif
                                </tr>

                                <tr>
                                    <th class="table-th">Tổng cộng</th>
                                    @if ($newTotal)
                                        <td class="table-total">{{ number_format($newTotal) }}₫</td>
                                    @else
                                        <td class="table-total">{{ number_format($result) }}₫</td>                                   
                                    @endif
                                </tr>
                            </tfoot>
                        </table>
                        <div class="payment">
                            <ul class="payment__list">
                                <li>
                                    <div class="payment-group">
                                        <input type="radio" class="payment-group__input" id="bank-transfer" name="payment" value="1" data-target="details-bank-transfer">
                                        <label for="bank-transfer" class="payment-label">Chuyển khoản ngân hàng</label>
                                    </div>
                                    <div class="payment-details" id="details-bank-transfer">
                                        <img src="{{ asset('/img/maqrvcb.jpg') }}" class="payment-details__img" alt="QR Code chuyển khoản">
                                        <div class="payment-message">
                                            <p class="payment-desc">Thông tin chuyển khoản:</p>
                                            <div class="payment-item">
                                                <strong class="payment-desc">Ngân hàng:</strong>
                                                <span  class="payment-bold">Vietcombank</span>
                                            </div>
                                            <div class="payment-item">
                                                <strong class="payment-desc">Số tài khoản:</strong>
                                                <span  class="payment-bold">1017207000</span>
                                            </div>
                                            <div class="payment-item">
                                                <strong class="payment-desc">Chủ tài khoản:</strong>
                                                <span  class="payment-bold">Nguyen Ngoc Khuyen</span>
                                            </div>
                                            <div class="payment-item">
                                                <strong class="payment-desc">Nội dung chuyển khoản:</strong>
                                                <span  class="payment-bold">Thanh toán đơn hàng #12345</span>
                                            </div>
                                        </div>
                                    </div>
                                </li>
                                <li>
                                    <div class="payment-group">
                                        <input type="radio" class="payment-group__input" id="vnpay" name="payment" value="2" data-target="details-vnpay">
                                        <label for="vnpay" class="payment-label">Thanh toán qua VNPay</label>
                                    </div>
                                    <div class="payment-details" id="details-vnpay">          
                                        @if ($newTotal)
                                            <input type="hidden" class="table-total" name="amount" value="{{ $newTotal }}"></input>
                                        @else
                                            <input type="hidden" class="table-total" name="amount" value="{{ $result }}"></input>                                
                                        @endif
                                        <input type="hidden" Checked="True" id="bankCode" name="bankCode" checked>
                                        <input type="hidden" id="language" Checked="True" name="language" value="vn">
                                        <button type="submit" class="btn-vnpay">Thanh toán qua VNPay</button>
                                    </div>
                                </li>
                                <li>
                                    <div class="payment-group">
                                        <input type="radio" class="payment-group__input" id="cod" name="payment" value="3" data-target="details-cod">
                                        <label for="cod" class="payment-label">Thanh toán khi nhận hàng</label>
                                    </div>
                                    <div class="payment-details" id="details-cod">
                                        <p class="payment-desc">Bạn chỉ phải thanh toán khi nhận hàng</p>
                                    </div>
                                </li>
                            </ul>
                            @error('payment')
                                <div class="message">
                                    {{ $message }}
                                </div>
                            @enderror
                        </div>
                        @if (session('message'))
                            <div class="message">
                                {{ session('message') }}
                            </div>
                        @endif
                        <button class="checkout-btn">Đặt hàng</button>
                    </div>
                </div>
            </div>
        </div>
    </form>

    <script>
        document.addEventListener("DOMContentLoaded", function () {
            document.querySelectorAll(".checkout-btn, .btn-apply, .btn-vnpay").forEach(button => {
                button.addEventListener("click", function (event) {
                    event.preventDefault(); // Ngăn chặn hành động mặc định

                    let form = document.getElementById("checkoutForm"); // Lấy form chính
                    let hiddenInput = document.createElement("input"); // Tạo input ẩn
                    hiddenInput.type = "hidden";
                    hiddenInput.name = "form_type"; 

                    // Xác định route theo nút được bấm
                    if (this.classList.contains("checkout-btn")) {
                        form.action = "{{ route('checkout.create') }}"; // Route đặt hàng
                    } else if (this.classList.contains("btn-apply")) {
                        form.action = "{{ route('checkout.apply-coupon') }}"; // Route áp dụng mã giảm giá
                        hiddenInput.value = "coupon";
                    } else if (this.classList.contains("btn-vnpay")) {
                        form.action = "{{ route('checkout.payment.create') }}"; // Route thanh toán VNPay
                    }

                    // Thêm input ẩn vào form
                    form.appendChild(hiddenInput);
                    form.submit(); // Gửi form theo action mới
                });
            });
        });


        document.addEventListener("DOMContentLoaded", function () {
            const radioInputs = document.querySelectorAll(".payment-group__input");
            radioInputs.forEach(input => {
                input.addEventListener("change", function () {
                    // Ẩn tất cả payment-details trước khi hiển thị cái mới
                    document.querySelectorAll(".payment-details").forEach(detail => {
                        detail.style.display = "none";
                    });
                    // Lấy đúng `data-target` từ radio button
                    const targetId = this.getAttribute("data-target");
                    const targetDiv = document.getElementById(targetId);
                    if (targetDiv) {
                        targetDiv.style.display = "block";
                    }
                });
            }); 
        })
    </script>
@endsection