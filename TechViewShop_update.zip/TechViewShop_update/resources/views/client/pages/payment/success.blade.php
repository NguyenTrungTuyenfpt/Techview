@extends('client.layout.layout')
@section('title')
    Trạng thái thanh toán
@endsection

@section('body')
    <div class="success-content">
        <i class="fa-solid fa-check icon-pay-success"></i>
        <h2 class="btn-pay-title">Thanh toán thành công</h2>
        <p class="btn-pay-desc">Đơn hàng sẽ được chuẩn bị và chuyển đi trong thời gian sớm nhất</p>
        <div class="btn-pay-success">
            <a href="{{ route('account.profile') }}" class="btn-pay-success__link">Theo dõi đơn hàng</a>
        </div>
    </div>
@endsection