<!DOCTYPE html>
<html>
<head>
    <title>Liên hệ</title>
    <link rel="stylesheet" href="{{asset('/css/email.css')}}">
</head>
<body>
    <div class="email">
        <h2 class="email-title">TechView Shop</h2>
        <div class="email-content">
            <h4 class="email-desc">Xin chào, {{ $hoten }}</h4>
            <div class="contact">
                <strong>Email:</strong>
                <a href="#" class="contact-link">{{ $chude }}</a>
            </div>
            <div class="contact">
                <strong>Nội dung liên hệ:</strong>
                <span class="contact-content">{{ $noidung }}</span>
            </div>
        </div>
    </div>
</body>
</html>
