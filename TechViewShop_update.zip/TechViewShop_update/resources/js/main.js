document.addEventListener("DOMContentLoaded", function () {
    const productContainer = document.querySelector(".product-container");
    const dots = document.querySelectorAll(".dot");
    const product = document.querySelector(".product");

    const productWidth = product.getBoundingClientRect().width; // Chiều rộng SP (cả padding, border)
    const paddingOffset = 20; // Padding trái phải tổng cộng 12px + 12px
    const adjustedWidth = productWidth + paddingOffset;

    let currentIndex = 0;

    function updateSlidePosition() {
        productContainer.style.transform = `translateX(${-currentIndex * adjustedWidth}px)`;
    }

    function moveSlide(index) {
        currentIndex = index;
        updateSlidePosition();
        updateActiveDot();
    }

    function updateActiveDot() {
        dots.forEach((dot, index) => {
            dot.classList.toggle("active", index === currentIndex);
        });
    }

    dots.forEach((dot, index) => {
        dot.addEventListener("click", function () {
            moveSlide(index);
        });
    });

    updateSlidePosition();
});
// menu category
document.querySelector(".header__menu-category").addEventListener("click", function () {
    document.querySelector(".header__list").classList.toggle("active");
});

// slider 
let slideIndex = 0;
showSlides();
function showSlides() {
    let i;
    let slides = document.getElementsByClassName("mySlides");
    if (slides.length === 0) return; 
    for (i = 0; i < slides.length; i++) {
        slides[i].style.display = "none";
    }
    slideIndex++;
    if (slideIndex > slides.length) {slideIndex = 1}
    slides[slideIndex-1].style.display = "block";
    setTimeout(showSlides, 3000); // Change image every 2 seconds
}

// hidden password
document.addEventListener("DOMContentLoaded", function () {
    document.querySelectorAll(".toggle-password").forEach(icon => {
        icon.addEventListener("click", function () {
            let input = document.getElementById(this.getAttribute("data-target"));
            if (input) {
                input.type = input.type === "password" ? "text" : "password";
                this.classList.toggle("fa-eye-slash");
                this.classList.toggle("fa-eye");
            }
        });
    });
});

// Register vs login
const currentPage = window.location.pathname;
document.querySelectorAll(".auth-link").forEach(link => {
    // Lấy pathname của link (bỏ phần domain)
    const linkPath = new URL(link.href).pathname;

    if (currentPage === linkPath) {
        link.classList.add("active-login");
    }
});

// 
document.addEventListener("DOMContentLoaded", function () {
    const tabs = document.querySelectorAll(".title-info");
    const sections = document.querySelectorAll(".content-section");

    // Kiểm tra xem có tab nào đã lưu trong localStorage không
    let activeTab = localStorage.getItem("activeTab") || 0;
    // Đặt tab đã lưu là active
    tabs.forEach(t => t.classList.remove("section-active"));
    sections.forEach(s => s.classList.remove("section-active"));
    tabs[activeTab].classList.add("section-active");
    sections[activeTab].classList.add("section-active");

    tabs.forEach((tab, index) => {
        tab.addEventListener("click", function () {
            // Xóa class section-active khỏi tất cả
            tabs.forEach(t => t.classList.remove("section-active"));
            sections.forEach(s => s.classList.remove("section-active"));

            // Thêm class section-active vào phần tử được click
            this.classList.add("section-active");
            sections[index].classList.add("section-active");

            // Lưu index của tab vào localStorage
            localStorage.setItem("activeTab", index);
        });
    });
});

// modal avatar
document.addEventListener("DOMContentLoaded", function () {
    const modal = document.getElementById("modal_avatar");
    const overlay = document.querySelector(".modal_overlay2");
    const btnClose = document.querySelectorAll(".close-modal-avatar");
    const btnAdd = document.querySelector(".change-icon__pen");
    const btnSubmit = document.getElementById("openAvatar");

    function openModal() {
        modal.style.display = "block";
        overlay.style.display = "block";
        localStorage.setItem("modalOpenAvatar", "true"); // Lưu trạng thái modal
    }

    function closeModal() {
        modal.style.display = "none";
        overlay.style.display = "none";
        localStorage.removeItem("modalOpenAvatar"); // Xóa trạng thái modal
    }

    // Kiểm tra nếu modal trước đó đã mở
    if (localStorage.getItem("modalOpenAvatar") === "true") {
        openModal();
    }

    btnAdd.addEventListener("click", openModal);
    btnClose.forEach(btn => btn.addEventListener("click", closeModal));
    overlay.addEventListener("click", closeModal);

    // Giữ modal mở sau khi submit form
    btnSubmit.addEventListener("click", function () {
        localStorage.setItem("modalOpenAvatar", "true");
    });

});

// modal
document.addEventListener("DOMContentLoaded", function () {
    const modal = document.getElementById("modal_address");
    const overlay = document.querySelector(".modal_overlay");
    const btnAdd = document.querySelector(".btn-address");
    const btnClose = document.querySelectorAll(".close-modal");
    const btnSubmit = document.getElementById("openModal");

    function openModal() {
        modal.style.display = "block";
        overlay.style.display = "block";
        localStorage.setItem("modalOpen", "true"); // Lưu trạng thái modal
    }

    function closeModal() {
        modal.style.display = "none";
        overlay.style.display = "none";
        localStorage.removeItem("modalOpen"); // Xóa trạng thái modal
    }

    // Kiểm tra nếu modal trước đó đã mở
    if (localStorage.getItem("modalOpen") === "true") {
        openModal();
    }

    btnAdd.addEventListener("click", openModal);
    btnClose.forEach(btn => btn.addEventListener("click", closeModal));
    overlay.addEventListener("click", closeModal);

    // Giữ modal mở sau khi submit form
    btnSubmit.addEventListener("click", function () {
        localStorage.setItem("modalOpen", "true");
    });
});

document.addEventListener("DOMContentLoaded", function () {
    let countdownElem = document.getElementById("countdown");
    if (!countdownElem) return;

    let endTime = parseInt(countdownElem.dataset.time);
    function updateCountdown() {
        let now = new Date().getTime();
        let timeLeft = endTime - now;

        if (timeLeft <= 0) {
            countdownElem.innerHTML = "<p>Hết khuyến mãi!</p>";
            return;
        }

        let hours = Math.floor(timeLeft / (1000 * 60 * 60)) % 24;
        let minutes = Math.floor((timeLeft % (1000 * 60 * 60)) / (1000 * 60));
        let seconds = Math.floor((timeLeft % (1000 * 60)) / 1000);

        document.getElementById("hours").textContent = String(hours).padStart(2, '0');
        document.getElementById("minutes").textContent = String(minutes).padStart(2, '0');
        document.getElementById("seconds").textContent = String(seconds).padStart(2, '0');
    }

    updateCountdown();
    setInterval(updateCountdown, 1000);
});

//  Hiếu Product-detail
document.querySelectorAll('form .stars i').forEach(star => {
    star.addEventListener('click', function() {
        let rating = this.getAttribute('data-value');

        // Cập nhật giá trị vào input hidden
        document.getElementById('danhgia').value = rating;

        // Xóa class active khỏi tất cả các sao
        document.querySelectorAll('form .stars i').forEach(s => s.classList.remove('active'));

        // Gán class active cho sao được chọn và các sao trước nó
        this.classList.add('active');
        let previousSibling = this.previousElementSibling;
        while (previousSibling) {
            previousSibling.classList.add('active');
            previousSibling = previousSibling.previousElementSibling;
        }
    });
});


function submitReview() {
    const rating = document.getElementById('ratingValue').value;
    const name = document.getElementById('name').value;
    const email = document.getElementById('email').value;
    const review = document.getElementById('review').value;
    
    if (!rating || !name || !email || !review) {
        alert('Vui lòng điền đầy đủ thông tin và đánh giá!');
        return;
    }
    
    alert(`Cảm ơn ${name} đã đánh giá ${rating} sao!`);
    
    document.getElementById('ratingValue').value = 0;
    document.querySelectorAll('.stars i').forEach(s => s.classList.remove('active'));
    document.getElementById('name').value = '';
    document.getElementById('email').value = '';
    document.getElementById('review').value = '';
}


document.addEventListener("DOMContentLoaded", function() {
    const tabs = document.querySelectorAll(".tab-item a");
    const contents = document.querySelectorAll(".tab-content");

    tabs.forEach(tab => {
        tab.addEventListener("click", function(event) {
            event.preventDefault();

            tabs.forEach(t => t.parentElement.classList.remove("active"));
            contents.forEach(c => c.classList.remove("active"));

            this.parentElement.classList.add("active");
            document.querySelector(this.getAttribute("href")).classList.add("active");
        });
    });
});


